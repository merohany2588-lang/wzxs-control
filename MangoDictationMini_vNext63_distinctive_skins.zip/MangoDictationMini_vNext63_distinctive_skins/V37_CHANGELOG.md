# V37 - Phonetic Display, MeloTTS Diagnose, StyleTTS2 Tail Fix

- Added Settings -> 提示信息 -> 音标显示类型: auto / uk / us / both / none.
- Kept Kokoro working path unchanged.
- Added stronger underline spacing to prevent IPA/input/sub-hint overlap.
- Added MeloTTS built-in subprocess worker that tries `from melo.api import TTS` if no custom script is configured.
- MeloTTS no longer silently pretends to work; failures write `data/melotts_last_error.log` and `data/melotts_last_error_summary.log`, then normal fallback can use Edge-TTS.
- Tuned StyleTTS2 live defaults for speed: realtime diffusion_steps=4.
- Added safer WAV tail cleanup: trim padding, longer fade-out, optional tail silence to reduce clipped/static endings.
- Did not change main training UI style, Kaikki v2 lookup, or Kokoro call style.
