from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QSpinBox, QCheckBox, QGroupBox, QMessageBox
)
from app.license_manager import FEATURES, make_activation_payload, encode_activation_code


class LicenseKeygen(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MangoDictationMini V59 授权中心 / 设备绑定激活码生成器")
        self.resize(1040, 820)
        root = QVBoxLayout(self)
        form = QGridLayout()
        self.machine = QLineEdit(); self.machine.setPlaceholderText("粘贴用户机器设备码，例如 XXXX-XXXX-...")
        self.user = QLineEdit(); self.user.setPlaceholderText("用户备注，可空")
        self.days = QSpinBox(); self.days.setRange(1, 3650); self.days.setValue(365)
        self.lines = QSpinBox(); self.lines.setRange(20, 400); self.lines.setValue(200)
        form.addWidget(QLabel("用户机器设备码"), 0, 0); form.addWidget(self.machine, 0, 1, 1, 3)
        form.addWidget(QLabel("用户/备注"), 1, 0); form.addWidget(self.user, 1, 1)
        form.addWidget(QLabel("使用时长/天"), 1, 2); form.addWidget(self.days, 1, 3)
        form.addWidget(QLabel("激活码行数"), 2, 0); form.addWidget(self.lines, 2, 1)
        root.addLayout(form)

        group = QGroupBox("授权权限")
        g = QGridLayout(group)
        self.checks = {}
        for i, (key, label) in enumerate(FEATURES.items()):
            cb = QCheckBox(label)
            cb.setChecked(True)
            self.checks[key] = cb
            g.addWidget(cb, i // 3, i % 3)
        root.addWidget(group)

        btns = QHBoxLayout()
        gen = QPushButton("生成激活码")
        gen.clicked.connect(self.generate)
        all_btn = QPushButton("全选")
        all_btn.clicked.connect(lambda: [c.setChecked(True) for c in self.checks.values()])
        none_btn = QPushButton("全不选")
        none_btn.clicked.connect(lambda: [c.setChecked(False) for c in self.checks.values()])
        copy = QPushButton("复制激活码")
        copy.clicked.connect(lambda: QApplication.clipboard().setText(self.output.toPlainText()))
        btns.addWidget(gen); btns.addWidget(all_btn); btns.addWidget(none_btn); btns.addStretch(); btns.addWidget(copy)
        root.addLayout(btns)

        root.addWidget(QLabel("V59 激活码为随机化长码：无序号、无规律明文；复制全部内容给用户。"))
        self.output = QTextEdit()
        self.output.setLineWrapMode(QTextEdit.NoWrap)
        self.output.setStyleSheet("QTextEdit{font-family:Consolas,Menlo,monospace;font-size:12px;background:#020617;color:#D1FAE5;border-radius:12px;padding:10px;}")
        root.addWidget(self.output, 1)

    def generate(self):
        machine = self.machine.text().strip().upper()
        if not machine:
            QMessageBox.warning(self, "注册机", "请先填写用户机器设备码。")
            return
        feats = {k: c.isChecked() for k, c in self.checks.items()}
        payload = make_activation_payload(machine, self.days.value(), feats, self.user.text().strip())
        code = encode_activation_code(payload, long_lines=self.lines.value())
        self.output.setPlainText(code)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = LicenseKeygen()
    w.show()
    sys.exit(app.exec())
