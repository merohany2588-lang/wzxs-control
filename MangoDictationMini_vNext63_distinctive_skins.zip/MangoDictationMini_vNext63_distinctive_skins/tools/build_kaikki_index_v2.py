from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.wordbook import build_kaikki_index_v2
from app.settings import app_settings


def main() -> int:
    jsonl = sys.argv[1] if len(sys.argv) > 1 else str(app_settings.get("kaikki_jsonl_path", ""))
    out = sys.argv[2] if len(sys.argv) > 2 else str(app_settings.get("kaikki_index_v2_path", ""))
    if not jsonl:
        print("ERROR: JSONL path is empty. Pass it as arg1 or set kaikk_jsonl_path in settings.json")
        return 2
    print("Building Kaikki v2 multi-offset index")
    print("JSONL:", jsonl)
    print("OUT  :", out or str(Path(jsonl + ".offset_index_v2.json")))
    def progress(count, words):
        print(f"indexed lines={count:,} unique_words={words:,}", flush=True)
    path = build_kaikki_index_v2(jsonl, out or None, progress_callback=progress)
    print("OK:", path)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
