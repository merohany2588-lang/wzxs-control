@echo off
cd /d "%~dp0"
py -m PyInstaller --onefile --noconsole --clean --name MangoLicenseKeygen tools\license_keygen_ui.py
pause
