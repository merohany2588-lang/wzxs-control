from __future__ import annotations
import csv
import re
from pathlib import Path
from datetime import datetime
from .models import Material
from .settings import app_settings
from .translation_service import translate_text

CHINESE_RE = re.compile(r"[\u4e00-\u9fff]")
LATIN_RE = re.compile(r"[A-Za-z]")
TIME_LINE_RE = re.compile(
    r"(?P<s>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*(?P<e>\d{1,2}:\d{2}:\d{2}[,.]\d{1,3})"
)
ASS_TAG_RE = re.compile(r"\{[^{}]*\}")
HTML_TAG_RE = re.compile(r"<[^>]+>")
MEDIA_EXTS = [".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".mp4", ".mkv", ".mov", ".avi", ".webm"]
AUDIO_EXTS = [".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"]
VIDEO_EXTS = [".mp4", ".mkv", ".mov", ".avi", ".webm"]


def _read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16", "utf-16le", "utf-16be"):
        try:
            text = raw.decode(enc)
            if text.count("\x00") > max(3, len(text) // 20):
                continue
            return text.replace("\x00", "")
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace").replace("\x00", "")


def _time_to_ms(t: str) -> int:
    t = (t or "").replace(",", ".")
    try:
        h, m, rest = t.split(":")
        if "." in rest:
            sec, ms = rest.split(".", 1)
        else:
            sec, ms = rest, "0"
        ms = (ms + "000")[:3]
        return (int(h) * 3600 + int(m) * 60 + int(sec)) * 1000 + int(ms)
    except Exception:
        return -1


def _contains_chinese(s: str) -> bool:
    return bool(CHINESE_RE.search(s or ""))


def _contains_latin(s: str) -> bool:
    return bool(LATIN_RE.search(s or ""))


def _clean_line(line: str) -> str:
    line = (line or "").replace("\\N", "\n").replace("\r", "\n")
    line = ASS_TAG_RE.sub("", line)
    line = HTML_TAG_RE.sub("", line)
    line = line.replace("♪", " ").replace("♫", " ")
    return line.strip()


def _normalize_spaces(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def _extract_english_from_mixed(line: str) -> str:
    if not line:
        return ""
    s = CHINESE_RE.sub(" ", line)
    s = re.sub(r"[，。！？；：“”‘’、【】（）《》…·￥]+", " ", s)
    s = _normalize_spaces(s)
    if not _contains_latin(s):
        return ""
    if re.fullmatch(r"[\d\s.,:;!?\-]+", s):
        return ""
    return s


def _extract_chinese_from_mixed(line: str) -> str:
    if not _contains_chinese(line):
        return ""
    s = re.sub(r"[A-Za-z][A-Za-z0-9'’.,!?;:\-\s()]*", " ", line)
    s = _normalize_spaces(s)
    if not _contains_chinese(s):
        s = line
    return _normalize_spaces(s)


def _same_base_media(path: Path) -> tuple[str, bool]:
    """Return (path, is_segmentable). For SRT/VTT, same-base video/audio can be
    played as current subtitle segment using timecodes. For TXT/CSV, only short
    same-base audio should be bound by default.
    """
    for ext in MEDIA_EXTS:
        p = path.with_suffix(ext)
        if p.exists():
            return str(p), ext.lower() in VIDEO_EXTS or ext.lower() in AUDIO_EXTS
    # Also try parent folder files that start with the subtitle base; common in packs.
    stem = path.stem.lower()
    for p in path.parent.iterdir():
        if p.is_file() and p.suffix.lower() in MEDIA_EXTS and (p.stem.lower() == stem or stem in p.stem.lower() or p.stem.lower() in stem):
            return str(p), True
    return "", False


def _same_base_short_audio(path: Path) -> str:
    for ext in AUDIO_EXTS:
        p = path.with_suffix(ext)
        if p.exists():
            return str(p)
    return ""


def _maybe_translate(en: str, zh: str, allow_translate: bool = False) -> str:
    if zh.strip():
        return zh.strip()
    if not allow_translate:
        return ""
    if not app_settings.get("auto_translate_on_import", False):
        return ""
    return translate_text(en)


def load_file(filepath: str, allow_translate: bool = False) -> list[Material]:
    p = Path(filepath)
    ext = p.suffix.lower()
    if ext == ".csv":
        return _load_csv(p, allow_translate)
    if ext in {".srt", ".vtt"}:
        return _load_srt_like(p, allow_translate)
    return _load_txt(p, allow_translate)


def _make(source: str, en: str, zh: str = "", audio: str = "", allow_translate: bool = False, *, media: str = "", start_ms: int = -1, end_ms: int = -1) -> Material | None:
    en = _normalize_spaces(en)
    zh = _normalize_spaces(zh)
    if not en:
        return None
    if _contains_chinese(en):
        mixed_en = _extract_english_from_mixed(en)
        mixed_zh = zh or _extract_chinese_from_mixed(en)
        en, zh = mixed_en, mixed_zh
    if not en or not _contains_latin(en):
        return None
    return Material(
        source_name=source,
        english=en,
        chinese=_maybe_translate(en, zh, allow_translate),
        audio_path=audio,
        media_path=media,
        start_ms=start_ms,
        end_ms=end_ms,
        created_at=datetime.now().isoformat(timespec="seconds"),
    )


def _split_text_line(line: str) -> tuple[str, str, str]:
    line = _clean_line(line)
    if not line:
        return "", "", ""
    if "\t" in line:
        parts = [x.strip() for x in line.split("\t")]
    elif " || " in line:
        parts = [x.strip() for x in line.split(" || ")]
    elif " -> " in line:
        parts = [x.strip() for x in line.split(" -> ")]
    else:
        parts = [x.strip() for x in re.split(r"\s{2,}", line) if x.strip()]
    if len(parts) >= 2:
        return parts[0], parts[1], parts[2] if len(parts) >= 3 else ""
    if _contains_chinese(line) and _contains_latin(line):
        return _extract_english_from_mixed(line), _extract_chinese_from_mixed(line), ""
    if _contains_chinese(line):
        return "", line, ""
    return line, "", ""


def _load_txt(path: Path, allow_translate: bool = False) -> list[Material]:
    out: list[Material] = []
    source = path.name
    audio_default = _same_base_short_audio(path)
    for raw in _read_text(path).splitlines():
        en, zh, audio = _split_text_line(raw)
        if audio and not Path(audio).exists():
            audio = ""
        m = _make(source, en, zh, audio or audio_default, allow_translate)
        if m:
            out.append(m)
    return out


def _load_csv(path: Path, allow_translate: bool = False) -> list[Material]:
    out: list[Material] = []
    source = path.name
    text = _read_text(path)
    try:
        dialect = csv.Sniffer().sniff("\n".join(text.splitlines()[:5]))
        delimiter = dialect.delimiter
    except Exception:
        first_line = text.splitlines()[0] if text.splitlines() else ""
        delimiter = "\t" if "\t" in first_line else ","
    import io
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    for row in reader:
        low = {str(k).strip().lower(): k for k in row.keys()}
        def get(*keys):
            for k in keys:
                real = low.get(k.lower())
                if real is not None and str(row.get(real, "")).strip():
                    return str(row.get(real, "")).strip()
            return ""
        en = get("en", "english", "英文", "sentence", "text")
        zh = get("zh", "chinese", "中文", "translation", "译文")
        audio = get("audio", "audio_path", "音频", "本地音频") or _same_base_short_audio(path)
        m = _make(source, en, zh, audio, allow_translate)
        if m:
            out.append(m)
    return out


def _subtitle_blocks(text: str) -> list[list[str]]:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"^WEBVTT.*?(\n\n|$)", "", text, flags=re.IGNORECASE | re.DOTALL)
    raw_blocks = re.split(r"\n\s*\n", text.strip())
    blocks: list[list[str]] = []
    for block in raw_blocks:
        lines = [x.strip() for x in block.splitlines() if x.strip()]
        if lines:
            blocks.append(lines)
    if not blocks and text.strip():
        blocks = [[x.strip() for x in text.splitlines() if x.strip()]]
    return blocks



def _sidecar_chinese_lines(path: Path) -> list[str]:
    """Read same-folder translated subtitles made by the production workbench.

    Supported names:
    - original.zh.srt
    - original.bilingual.srt
    - original.zh.vtt
    - original.bilingual.vtt
    """
    if path.stem.endswith(('.zh', '.bilingual')):
        return []
    candidates = [
        path.with_name(path.stem + '.zh' + path.suffix),
        path.with_name(path.stem + '.bilingual' + path.suffix),
        path.with_name(path.stem + '.zh.srt'),
        path.with_name(path.stem + '.bilingual.srt'),
        path.with_name(path.stem + '.zh.vtt'),
        path.with_name(path.stem + '.bilingual.vtt'),
    ]
    for cand in candidates:
        if not cand.exists() or cand.resolve() == path.resolve():
            continue
        out: list[str] = []
        try:
            txt = _read_text(cand)
            for lines in _subtitle_blocks(txt):
                zh_parts: list[str] = []
                any_payload: list[str] = []
                for line in lines:
                    if TIME_LINE_RE.search(line) or line.isdigit() or line.upper().startswith('WEBVTT'):
                        continue
                    cleaned = _clean_line(line)
                    for part in cleaned.split('\n'):
                        part = part.strip()
                        if not part:
                            continue
                        any_payload.append(part)
                        if _contains_chinese(part):
                            zh_parts.append(_extract_chinese_from_mixed(part) if _contains_latin(part) else part)
                zh = _normalize_spaces(' '.join(x for x in zh_parts if x))
                if not zh and cand.stem.endswith('.zh'):
                    zh = _normalize_spaces(' '.join(any_payload))
                out.append(zh)
            if out:
                return out
        except Exception:
            continue
    return []

def _load_srt_like(path: Path, allow_translate: bool = False) -> list[Material]:
    out: list[Material] = []
    source = path.name
    media_path, _ = _same_base_media(path)
    sidecar_zh = _sidecar_chinese_lines(path)
    text = _read_text(path)
    for block_index, lines in enumerate(_subtitle_blocks(text)):
        payload: list[str] = []
        start_ms = -1
        end_ms = -1
        for line in lines:
            mtime = TIME_LINE_RE.search(line)
            if mtime:
                start_ms = _time_to_ms(mtime.group("s"))
                end_ms = _time_to_ms(mtime.group("e"))
                continue
            if line.isdigit() or line.upper().startswith("WEBVTT"):
                continue
            cleaned = _clean_line(line)
            for part in cleaned.split("\n"):
                part = part.strip()
                if part:
                    payload.append(part)
        if not payload:
            continue
        en_parts: list[str] = []
        zh_parts: list[str] = []
        for part in payload:
            if _contains_chinese(part) and _contains_latin(part):
                en = _extract_english_from_mixed(part)
                zh = _extract_chinese_from_mixed(part)
                if en: en_parts.append(en)
                if zh: zh_parts.append(zh)
            elif _contains_chinese(part):
                zh_parts.append(part)
            elif _contains_latin(part):
                en_parts.append(part)
        en = _normalize_spaces(" ".join(en_parts))
        zh = _normalize_spaces(" ".join(zh_parts))
        if not zh and block_index < len(sidecar_zh):
            zh = sidecar_zh[block_index]
        m = _make(source, en, zh, "", allow_translate, media=media_path, start_ms=start_ms, end_ms=end_ms)
        if m:
            out.append(m)
    return out
