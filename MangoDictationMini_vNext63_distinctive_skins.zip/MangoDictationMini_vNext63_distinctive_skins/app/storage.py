from __future__ import annotations
import sqlite3
from pathlib import Path
from datetime import datetime
from .models import Material, WrongItem

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "app_data.db"


def _conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def _ensure_column(c: sqlite3.Connection, table: str, col: str, ddl: str) -> None:
    cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
    if col not in cols:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def init_db() -> None:
    with _conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS materials(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_name TEXT DEFAULT '',
            english TEXT NOT NULL,
            chinese TEXT DEFAULT '',
            audio_path TEXT DEFAULT '',
            media_path TEXT DEFAULT '',
            start_ms INTEGER DEFAULT -1,
            end_ms INTEGER DEFAULT -1,
            favorite INTEGER DEFAULT 0,
            wrong_count INTEGER DEFAULT 0,
            correct_count INTEGER DEFAULT 0,
            created_at TEXT DEFAULT '',
            last_practiced_at TEXT DEFAULT ''
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS wrong_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            material_id INTEGER DEFAULT 0,
            english TEXT NOT NULL,
            chinese TEXT DEFAULT '',
            user_answer TEXT DEFAULT '',
            wrong_count INTEGER DEFAULT 1,
            last_wrong_at TEXT DEFAULT ''
        )""")
        _ensure_column(c, "materials", "audio_path", "audio_path TEXT DEFAULT ''")
        _ensure_column(c, "materials", "media_path", "media_path TEXT DEFAULT ''")
        _ensure_column(c, "materials", "start_ms", "start_ms INTEGER DEFAULT -1")
        _ensure_column(c, "materials", "end_ms", "end_ms INTEGER DEFAULT -1")
        c.commit()


def insert_materials(items: list[Material]) -> int:
    if not items:
        return 0
    with _conn() as c:
        for m in items:
            cur = c.execute(
                """INSERT INTO materials(
                    source_name, english, chinese, audio_path, media_path, start_ms, end_ms,
                    favorite, wrong_count, correct_count, created_at, last_practiced_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    m.source_name, m.english, m.chinese, m.audio_path, m.media_path,
                    int(m.start_ms), int(m.end_ms), int(m.favorite), m.wrong_count,
                    m.correct_count, m.created_at, m.last_practiced_at,
                ),
            )
            try:
                m.id = int(cur.lastrowid)
            except Exception:
                pass
        c.commit()
    return len(items)


def update_material_chinese(material_id: int, chinese: str) -> None:
    if not material_id or not chinese:
        return
    with _conn() as c:
        c.execute("UPDATE materials SET chinese=? WHERE id=?", (chinese, material_id))
        c.commit()


def _row_to_material(r) -> Material:
    keys = set(r.keys())
    return Material(
        id=r["id"],
        source_name=r["source_name"],
        english=r["english"],
        chinese=r["chinese"],
        audio_path=r["audio_path"] if "audio_path" in keys else "",
        media_path=r["media_path"] if "media_path" in keys else "",
        start_ms=int(r["start_ms"] if "start_ms" in keys and r["start_ms"] is not None else -1),
        end_ms=int(r["end_ms"] if "end_ms" in keys and r["end_ms"] is not None else -1),
        favorite=bool(r["favorite"]),
        wrong_count=r["wrong_count"],
        correct_count=r["correct_count"],
        created_at=r["created_at"],
        last_practiced_at=r["last_practiced_at"],
    )


def get_all_materials(source_name: str = "") -> list[Material]:
    with _conn() as c:
        if source_name:
            rows = c.execute("SELECT * FROM materials WHERE source_name=? ORDER BY id", (source_name,)).fetchall()
        else:
            rows = c.execute("SELECT * FROM materials ORDER BY id").fetchall()
    return [_row_to_material(r) for r in rows]


def get_source_names() -> list[str]:
    with _conn() as c:
        rows = c.execute("SELECT DISTINCT source_name FROM materials ORDER BY source_name").fetchall()
    return [r[0] for r in rows]


def update_material_stats(material_id: int, correct: bool) -> None:
    with _conn() as c:
        now = datetime.now().isoformat(timespec="seconds")
        field = "correct_count" if correct else "wrong_count"
        c.execute(f"UPDATE materials SET {field}={field}+1, last_practiced_at=? WHERE id=?", (now, material_id))
        c.commit()


def toggle_favorite(material_id: int, favorite: bool) -> None:
    with _conn() as c:
        c.execute("UPDATE materials SET favorite=? WHERE id=?", (int(favorite), material_id))
        c.commit()


def add_wrong_item(material_id: int, english: str, chinese: str, user_answer: str) -> None:
    with _conn() as c:
        now = datetime.now().isoformat(timespec="seconds")
        row = c.execute("SELECT id FROM wrong_items WHERE material_id=?", (material_id,)).fetchone()
        if row:
            c.execute("UPDATE wrong_items SET user_answer=?, wrong_count=wrong_count+1, last_wrong_at=? WHERE id=?", (user_answer, now, row["id"]))
        else:
            c.execute("INSERT INTO wrong_items(material_id,english,chinese,user_answer,wrong_count,last_wrong_at) VALUES(?,?,?,?,1,?)", (material_id, english, chinese, user_answer, now))
        c.commit()


def get_wrong_items() -> list[WrongItem]:
    with _conn() as c:
        rows = c.execute("SELECT * FROM wrong_items ORDER BY wrong_count DESC,last_wrong_at DESC").fetchall()
    return [WrongItem(id=r["id"], material_id=r["material_id"], english=r["english"], chinese=r["chinese"], user_answer=r["user_answer"], wrong_count=r["wrong_count"], last_wrong_at=r["last_wrong_at"]) for r in rows]


def clear_wrong_items() -> None:
    with _conn() as c:
        c.execute("DELETE FROM wrong_items")
        c.commit()

init_db()
