from __future__ import annotations

import argparse
import contextlib
import gc
import json
import sys
import traceback
from pathlib import Path


def _write(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except Exception:
        pass


def _postprocess_array(wav, sr: int, *, trim: bool = True, threshold: float = 0.004,
                       fade_in_ms: int = 8, fade_out_ms: int = 100, peak: float = 0.88,
                       trim_pad_ms: int = 80, append_silence_ms: int = 80):
    """Small, dependency-light cleanup for TTS output.

    - trims obvious leading/trailing silence/noise floor
    - applies short fades to remove clicks/tail artifacts
    - peak normalizes for consistent volume
    """
    import numpy as np
    x = np.asarray(wav, dtype="float32").squeeze()
    if x.ndim > 1:
        x = x.mean(axis=1).astype("float32")
    if x.size == 0:
        return x
    if trim:
        y = np.abs(x)
        idx = np.where(y > float(threshold))[0]
        if idx.size:
            pad = int(max(0.025, float(trim_pad_ms) / 1000.0) * sr)
            start = max(0, int(idx[0]) - pad)
            end = min(x.size, int(idx[-1]) + pad)
            if end > start:
                x = x[start:end]
    # Avoid generating a completely empty clip after aggressive trim.
    if x.size == 0:
        return x
    fade_in = min(int(sr * max(0, fade_in_ms) / 1000), max(0, x.size // 3))
    fade_out = min(int(sr * max(0, fade_out_ms) / 1000), max(0, x.size // 2))
    if fade_in > 1:
        x[:fade_in] *= np.linspace(0.0, 1.0, fade_in, dtype="float32")
    if fade_out > 1:
        x[-fade_out:] *= np.linspace(1.0, 0.0, fade_out, dtype="float32")
    append = min(int(sr * max(0, int(append_silence_ms)) / 1000), sr)
    if append > 0:
        x = np.concatenate([x, np.zeros(append, dtype="float32")])
    mx = float(np.max(np.abs(x))) if x.size else 0.0
    if mx > 1e-6 and peak and peak > 0:
        x = x * min(float(peak) / mx, 10.0)
    return np.clip(x, -1.0, 1.0).astype("float32")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    args = parser.parse_args()
    data_dir = Path(args.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    log_path = data_dir / "styletts2_daemon_worker.log"

    def log(msg: str) -> None:
        try:
            with log_path.open("a", encoding="utf-8") as f:
                f.write(str(msg) + "\n")
        except Exception:
            pass

    log("daemon_start")
    loaded_key = None
    my_tts = None

    try:
        # Keep stdout reserved for JSON protocol; some libraries print progress.
        with contextlib.redirect_stdout(sys.stderr):
            from styletts2 import tts  # type: ignore
            import soundfile as sf
        log("imports_ok")
    except Exception:
        tb = traceback.format_exc()
        log("IMPORT_FAIL\n" + tb)
        print(json.dumps({"ok": False, "error": "import_failed", "traceback": tb}, ensure_ascii=False), flush=True)
        return 2

    for line in sys.stdin:
        try:
            req = json.loads(line)
            text = str(req.get("text") or "")
            output = Path(str(req.get("output") or ""))
            checkpoint = Path(str(req.get("checkpoint") or ""))
            config = Path(str(req.get("config") or ""))
            model_dir = Path(str(req.get("model_dir") or ""))
            diffusion_steps = int(req.get("diffusion_steps") or 6)
            alpha = float(req.get("alpha") or 0.3)
            beta = float(req.get("beta") or 0.7)
            post = req.get("postprocess") or {}
            if not text.strip():
                print(json.dumps({"ok": False, "error": "empty_text"}, ensure_ascii=False), flush=True)
                continue
            if not checkpoint.exists() or not config.exists():
                print(json.dumps({
                    "ok": False,
                    "error": "checkpoint_or_config_missing",
                    "checkpoint": str(checkpoint),
                    "checkpoint_exists": checkpoint.exists(),
                    "config": str(config),
                    "config_exists": config.exists(),
                }, ensure_ascii=False), flush=True)
                continue
            key = (str(checkpoint.resolve()), str(config.resolve()))
            if loaded_key != key or my_tts is None:
                log(f"load_model checkpoint={checkpoint} config={config} model_dir={model_dir}")
                with contextlib.redirect_stdout(sys.stderr):
                    my_tts = tts.StyleTTS2(
                        model_checkpoint_path=str(checkpoint),
                        config_path=str(config),
                    )
                loaded_key = key
                log("model_ready")
            log(f"synth len={len(text)} diffusion_steps={diffusion_steps} output={output}")
            with contextlib.redirect_stdout(sys.stderr):
                wav = my_tts.inference(
                    text=text,
                    diffusion_steps=diffusion_steps,
                    alpha=alpha,
                    beta=beta,
                    output_wav_file=None,
                )
            wav = _postprocess_array(
                wav, 24000,
                trim=bool(post.get("trim", True)),
                threshold=float(post.get("trim_threshold", 0.004)),
                fade_in_ms=int(post.get("fade_in_ms", 8)),
                fade_out_ms=int(post.get("fade_out_ms", 100)),
                peak=float(post.get("normalize_peak", 0.88)),
                trim_pad_ms=int(post.get("trim_pad_ms", 80)),
                append_silence_ms=int(post.get("append_silence_ms", 80)),
            )
            output.parent.mkdir(parents=True, exist_ok=True)
            sf.write(str(output), wav, 24000)
            try:
                gc.collect()
            except Exception:
                pass
            size = output.stat().st_size if output.exists() else 0
            print(json.dumps({"ok": bool(size > 100), "output": str(output), "size": size, "engine": "styletts2", "diffusion_steps": diffusion_steps}, ensure_ascii=False), flush=True)
        except Exception:
            tb = traceback.format_exc()
            log("REQUEST_FAIL\n" + tb)
            print(json.dumps({"ok": False, "error": "request_failed", "traceback": tb}, ensure_ascii=False), flush=True)
    log("daemon_stop")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
