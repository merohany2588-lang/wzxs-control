from __future__ import annotations

import base64
import os
import zlib
import datetime as _dt
import hashlib
import hmac
import json
import os
import platform
import re
import socket
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
LICENSE_PATH = DATA_DIR / "license.dat"
TRIAL_PATH = DATA_DIR / "trial_state.json"

# V58 local licensing secret. Keep tools/license_keygen_ui.py outside the user-facing build.
_LICENSE_SECRET = b"MangoDictationMini-V58-License-Server-2026-05-14::owner-private"

FEATURES: dict[str, str] = {
    "dictation": "听写训练",
    "blind": "盲听模式",
    "choice": "选词模式",
    "fill_blank": "填空模式",
    "transcript": "全文浏览",
    "intensive": "精听模式",
    "production": "制作台",
    "settings": "设置中心",
    "export": "导出/复制增强",
}

TRIAL_SECONDS = 3600


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, text=True, timeout=2).strip()
    except Exception:
        return ""


def _windows_uuid() -> str:
    if os.name != "nt":
        return ""
    out = _run(["wmic", "csproduct", "get", "uuid"])
    lines = [x.strip() for x in out.splitlines() if x.strip() and "UUID" not in x.upper()]
    return lines[0] if lines else ""


def raw_machine_fingerprint() -> str:
    parts = [
        platform.system(),
        platform.machine(),
        platform.node() or socket.gethostname(),
        _windows_uuid(),
        str(uuid.getnode()),
        os.environ.get("COMPUTERNAME", ""),
        os.environ.get("USERNAME", ""),
        os.environ.get("PROCESSOR_IDENTIFIER", ""),
    ]
    return "|".join(str(x or "").strip().lower() for x in parts)


def machine_code() -> str:
    digest = hashlib.sha256(raw_machine_fingerprint().encode("utf-8", errors="ignore")).hexdigest().upper()
    core = digest[:32]
    return "-".join(core[i:i+4] for i in range(0, len(core), 4))


def _canonical_json(data: dict[str, Any]) -> bytes:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sign(payload: dict[str, Any]) -> str:
    return hmac.new(_LICENSE_SECRET, _canonical_json(payload), hashlib.sha256).hexdigest().upper()


def make_activation_payload(machine: str, days: int, features: dict[str, bool], user: str = "") -> dict[str, Any]:
    now = _dt.datetime.now(_dt.timezone.utc)
    days = max(1, int(days))
    return {
        "product": "MangoDictationMini",
        "version": "V59",
        "machine_code": machine.strip().upper(),
        "user": user.strip(),
        "issued_at": now.isoformat(timespec="seconds"),
        "expires_at": (now + _dt.timedelta(days=days)).isoformat(timespec="seconds"),
        "features": {k: bool(features.get(k, False)) for k in FEATURES},
    }


def _xor_stream(n: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < n:
        out.extend(hmac.new(_LICENSE_SECRET, f"MANGO-V59-LICENSE-STREAM:{counter}".encode(), hashlib.sha256).digest())
        counter += 1
    return bytes(out[:n])


def _xor_bytes(data: bytes) -> bytes:
    ks = _xor_stream(len(data))
    return bytes(a ^ b for a, b in zip(data, ks))


def encode_activation_code(payload: dict[str, Any], long_lines: int = 200) -> str:
    payload = dict(payload)
    payload["signature"] = _sign({k: v for k, v in payload.items() if k != "signature"})
    raw = zlib.compress(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"), 9)
    line_count = max(20, int(long_lines or 200))
    target_bytes = max(len(raw) + 96, line_count * 32)
    packet = len(raw).to_bytes(4, "big") + raw + os.urandom(max(32, target_bytes - len(raw) - 4))
    masked = _xor_bytes(packet)
    b64 = base64.urlsafe_b64encode(masked).decode("ascii").rstrip("=")
    chunks = [b64[i:i+64] for i in range(0, len(b64), 64)]
    while len(chunks) < line_count:
        chunks.append(base64.urlsafe_b64encode(os.urandom(48)).decode("ascii").rstrip("="))
    return "\n".join(["-----BEGIN MANGO-DICTATION-ACTIVATION-----", *chunks[:line_count], "-----END MANGO-DICTATION-ACTIVATION-----"])


def _extract_payload_text(code: str) -> str:
    body: list[str] = []
    for raw in (code or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("-----"):
            continue
        # V59 key has no visible line number; keep old V58 compatibility by removing optional prefix.
        if ":" in line and re.match(r"^\d{1,4}:", line):
            line = line.split(":", 1)[1].strip()
        if line.startswith("#"):
            continue
        body.append(re.sub(r"[^A-Za-z0-9_\-=+/]", "", line))
    return "".join(body)


def decode_activation_code(code: str) -> dict[str, Any]:
    compact = _extract_payload_text(code)
    if not compact:
        raise ValueError("激活码为空或格式不正确。")
    try:
        # Try V59 random-looking masked packet first.
        pad = "=" * ((4 - len(compact) % 4) % 4)
        packet = _xor_bytes(base64.urlsafe_b64decode((compact + pad).encode("ascii")))
        raw_len = int.from_bytes(packet[:4], "big")
        if 0 < raw_len <= len(packet) - 4:
            data = json.loads(zlib.decompress(packet[4:4+raw_len]).decode("utf-8"))
        else:
            raise ValueError("bad packet length")
    except Exception:
        try:
            # Backward compatible with V58 visible-base64 keys.
            raw = base64.b64decode(compact.encode("ascii"), validate=False)
            data = json.loads(raw.decode("utf-8"))
        except Exception as e:
            raise ValueError(f"激活码无法解析：{e}") from e
    if not isinstance(data, dict):
        raise ValueError("激活码内容无效。")
    sig = str(data.get("signature", "")).upper()
    expected = _sign({k: v for k, v in data.items() if k != "signature"})
    if not hmac.compare_digest(sig, expected):
        raise ValueError("激活码签名无效。")
    return data


@dataclass
class LicenseStatus:
    activated: bool
    valid: bool
    machine_code: str
    message: str
    features: dict[str, bool]
    expires_at: str = ""
    trial_remaining_seconds: int = 0

    def has(self, feature: str) -> bool:
        if self.activated and self.valid:
            return bool(self.features.get(feature, False))
        if feature == "dictation" and self.trial_remaining_seconds > 0:
            return True
        return False


def _read_json(path: Path) -> dict[str, Any]:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _write_json(path: Path, data: dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def trial_remaining() -> int:
    now = int(_dt.datetime.now().timestamp())
    state = _read_json(TRIAL_PATH)
    mc = machine_code()
    if state.get("machine_code") != mc or not state.get("first_run_ts"):
        state = {"machine_code": mc, "first_run_ts": now}
        _write_json(TRIAL_PATH, state)
    first = int(state.get("first_run_ts") or now)
    return max(0, TRIAL_SECONDS - (now - first))


def get_status() -> LicenseStatus:
    mc = machine_code()
    remaining = trial_remaining()
    if not LICENSE_PATH.exists():
        return LicenseStatus(False, False, mc, f"未激活：仅可试用听写训练 {remaining//60} 分钟。", {k: False for k in FEATURES}, trial_remaining_seconds=remaining)
    try:
        code = LICENSE_PATH.read_text(encoding="utf-8")
        data = decode_activation_code(code)
        if str(data.get("machine_code", "")).upper() != mc:
            return LicenseStatus(True, False, mc, "激活码不属于本机，禁止换机复制使用。", {k: False for k in FEATURES}, trial_remaining_seconds=remaining)
        exp = str(data.get("expires_at", ""))
        exp_dt = _dt.datetime.fromisoformat(exp.replace("Z", "+00:00"))
        now = _dt.datetime.now(_dt.timezone.utc)
        if exp_dt.tzinfo is None:
            exp_dt = exp_dt.replace(tzinfo=_dt.timezone.utc)
        if now > exp_dt:
            return LicenseStatus(True, False, mc, "激活码已过期。", {k: False for k in FEATURES}, expires_at=exp, trial_remaining_seconds=remaining)
        feats = data.get("features") if isinstance(data.get("features"), dict) else {}
        return LicenseStatus(True, True, mc, "已激活", {k: bool(feats.get(k, False)) for k in FEATURES}, expires_at=exp, trial_remaining_seconds=remaining)
    except Exception as e:
        return LicenseStatus(True, False, mc, f"激活文件无效：{e}", {k: False for k in FEATURES}, trial_remaining_seconds=remaining)


def install_activation_code(code: str) -> LicenseStatus:
    data = decode_activation_code(code)
    mc = machine_code()
    if str(data.get("machine_code", "")).upper() != mc:
        raise ValueError("该激活码绑定的设备码不是本机设备码，禁止换机使用。")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LICENSE_PATH.write_text(code.strip() + "\n", encoding="utf-8")
    return get_status()
