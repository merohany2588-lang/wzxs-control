from __future__ import annotations
import csv
import html
import traceback
import random
import re
import time
from pathlib import Path
from typing import List
from PySide6.QtCore import Qt, Signal, QTimer, QThread, QUrl
from PySide6.QtGui import QAction, QFont, QFontMetrics, QKeySequence, QShortcut, QGuiApplication
from PySide6.QtWidgets import *
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget

from .models import Material, Chunk
from .settings import app_settings, DEFAULT_SHORTCUTS, THEMES, SKINS
from .theme import make_qss, THEME_TOKENS, theme_profile, SKIN_TOKENS, LINE_COLOR_PRESETS
from .dictation_engine import segment_chunks, normalize_word, chunk_component_hint, diagnose_word_error
from .wordbook import lookup_word, get_chunk_infos, reload_wordbook, diagnose_kaikki_words
from .material_loader import load_file
from .translation_service import translate_text
from .speech_engine import SpeechEngineManager
from .sound_engine import SoundManager, SOUND_NAMES
from .storage import (get_source_names, get_all_materials, insert_materials, update_material_stats, add_wrong_item, get_wrong_items, clear_wrong_items, toggle_favorite, update_material_chinese)
from .production_workbench import ProductionWorkbench
from .license_manager import get_status, install_activation_code, FEATURES

ROOT = Path(__file__).resolve().parents[1]


class ScanWorker(QThread):
    """Background resource folder scanner. It only scans file paths; it never parses or translates, so the UI will not freeze."""
    done = Signal(str, object)
    error = Signal(str)

    def __init__(self, root: str, extensions: list[str] | None = None):
        super().__init__()
        self.root = str(root)
        self.extensions = {e.lower() for e in (extensions or [".txt", ".csv", ".srt", ".vtt"])}

    def run(self):
        try:
            root_path = Path(self.root)
            folders: list[str] = []
            files: list[str] = []
            for p in root_path.rglob("*"):
                if p.is_dir():
                    folders.append(str(p))
                elif p.is_file() and p.suffix.lower() in self.extensions:
                    files.append(str(p))
            folders.sort(key=lambda x: x.lower())
            files.sort(key=lambda x: x.lower())
            self.done.emit(str(root_path), {"folders": folders, "files": files})
        except Exception as e:
            self.error.emit(str(e) + "\n" + traceback.format_exc())


class FileLoadWorker(QThread):
    """Load one resource file in background.

    Important: loading must NEVER call online translation.  A 1000-line SRT would
    otherwise look like the app is frozen for minutes.  Loading only parses local
    text and immediately shows the course.  Chinese translation is a separate
    background task to be added/triggered explicitly, not part of file opening.
    """
    done = Signal(str, object)
    error = Signal(str)

    def __init__(self, filepath: str):
        super().__init__()
        self.filepath = str(filepath)

    def run(self):
        try:
            # Fast local parse only. Do not translate here.
            items = load_file(self.filepath, allow_translate=False)
            self.done.emit(self.filepath, items)
        except Exception as e:
            self.error.emit(str(e) + "\n" + traceback.format_exc())


class TranslationWorker(QThread):
    done = Signal(int, str, str)  # index, chinese, english
    error = Signal(str)

    def __init__(self, index: int, english: str):
        super().__init__()
        self.index = index
        self.english = english

    def run(self):
        try:
            zh = translate_text(self.english)
            self.done.emit(self.index, zh or "", self.english)
        except Exception as e:
            self.error.emit(str(e))


class ChunkInput(QLineEdit):
    def __init__(self, chunk: Chunk, parent=None):
        super().__init__(parent)
        self.chunk = chunk
        self.expected = chunk.text
        self.checked = False
        self.correct = False
        self.setObjectName("chunkInput")
        self.setFrame(False)
        self.setProperty("role", "chunk")
        self.setProperty("state", "normal")
        self.setAlignment(Qt.AlignCenter)
        self.setFont(QFont("Consolas", 18))
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setMinimumWidth(max(96, min(300, len(self.expected) * 14 + 26)))
        self.setFixedHeight(48)
        self._apply_line_style("normal")

    def _apply_line_style(self, state: str):
        # v54: 横线输入框跟随“主题 + 皮肤”。V52/V53 这里写死颜色，导致皮肤看起来不生效。
        try:
            profile = theme_profile(str(app_settings.get("theme", "云青禅意") or "云青禅意"))
            skin = SKIN_TOKENS.get(str(app_settings.get("skin", "极简学习本") or "极简学习本"), SKIN_TOKENS["极简学习本"])
            preset = str(app_settings.get("chunk_line_color", "theme") or "theme").lower()
            base_line = LINE_COLOR_PRESETS.get(preset) or profile["line"]
            focus_line = profile["accent"] if preset == "theme" else base_line
            width = int(skin.get("line_width", 2))
            style = str(skin.get("line_style", "solid"))
            state_color = {
                "normal": base_line,
                "focus": focus_line,
                "prefix": focus_line,
                "correct": profile["success"],
                "wrong": profile["danger"],
            }.get(state, base_line)
            text_color = profile["success"] if state == "correct" else (profile["danger"] if state == "wrong" else profile["input_text"])
            bg = profile["wrong_bg"] if state == "wrong" else "transparent"
            font = "Consolas"
            if str(app_settings.get("skin", "")) == "胶片影视":
                font = "Georgia, Consolas"
            self.setStyleSheet(f"""
                QLineEdit#chunkInput {{
                    border: none;
                    border-bottom: {width + (1 if state in {"focus", "prefix", "correct", "wrong"} else 0)}px {style} {state_color};
                    border-radius: 0px;
                    background: {bg};
                    color: {text_color};
                    padding: 0px 2px 8px 2px;
                    font-size: 22px;
                    font-family: {font};
                    selection-background-color: {profile["selected"]};
                }}
            """)
        except Exception:
            self.setStyleSheet("QLineEdit#chunkInput{border:none;border-bottom:2px solid #64748b;background:transparent;color:#111827;padding:0 2px 8px 2px;font-size:22px;font-family:Consolas;}")

    def set_state(self, state: str):
        self.setProperty("state", state)
        self._apply_line_style(state)
        self.style().unpolish(self); self.style().polish(self)

    def mark_correct(self):
        self.checked = True; self.correct = True; self.set_state("correct")

    def mark_wrong(self):
        self.checked = True; self.correct = False; self.set_state("wrong")

    def focusInEvent(self, event):
        super().focusInEvent(event)
        if not self.correct:
            self.set_state("focus")

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        if not self.correct and self.property("state") != "wrong":
            self.set_state("normal")

    def keyPressEvent(self, event):
        key = event.key(); win = self.window()
        if key == Qt.Key_Space:
            expected_words = [w for w in self.expected.split() if w]
            text = self.text()
            typed_words = [w for w in text.strip().split(" ") if w]
            # 1) 不允许开头空格；2) 不允许连续多个空格；3) 最后一个词后不插入尾随空格。
            if not text.strip() or text.endswith(" "):
                if hasattr(win, "_set_status"):
                    win._set_status("空格规则：开头不能空格，单词之间只能一个空格。", "wrong")
                return
            if len(expected_words) > 1 and len(typed_words) < len(expected_words):
                # 还没到最后一个词：允许输入一个真实空格。
                QLineEdit.keyPressEvent(self, event)
                return
            # 已经是最后一个词/单词语块：Space 只用于判定跳转，不写入尾随空格。
            if hasattr(win, "handle_space_on_chunk"):
                win.handle_space_on_chunk(self)
                return
        if key == Qt.Key_Left:
            if hasattr(win, "_prev_sentence"):
                win._prev_sentence(); return
        if key == Qt.Key_Right:
            if hasattr(win, "_next_sentence"):
                win._next_sentence(); return
        super().keyPressEvent(event)


class FloatingVideoDialog(QDialog):
    """Freely draggable video window for the intensive listening page."""
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setObjectName("floatingVideoDialog")
        self.setWindowTitle("精听视频小窗")
        self.setWindowFlags(self.windowFlags() | Qt.Window)
        self.resize(720, 405)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        self.video = QVideoWidget(self)
        self.video.setObjectName("intensiveVideoWidget")
        layout.addWidget(self.video, 1)
        bar = QHBoxLayout()
        self.full_btn = QPushButton("全屏/还原 F11")
        self.full_btn.clicked.connect(self.toggle_fullscreen)
        self.back_btn = QPushButton("收回到页面")
        self.back_btn.clicked.connect(self.return_to_page)
        bar.addStretch(); bar.addWidget(self.full_btn); bar.addWidget(self.back_btn)
        layout.addLayout(bar)

    def toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Escape, Qt.Key_F11):
            self.toggle_fullscreen()
            return
        if event.key() == Qt.Key_Left and hasattr(self.owner, "_intensive_prev"):
            self.owner._intensive_prev(); return
        if event.key() == Qt.Key_Right and hasattr(self.owner, "_intensive_next"):
            self.owner._intensive_next(); return
        super().keyPressEvent(event)

    def return_to_page(self):
        if hasattr(self.owner, "_dock_video_to_intensive_page"):
            self.owner._dock_video_to_intensive_page()

    def closeEvent(self, event):
        self.return_to_page()
        event.accept()


class _SegmentAudioMixin:
    """Small shared player for v56 independent transcript/intensive windows."""
    def _init_segment_player(self, with_video: bool = False):
        self._seg_player = QMediaPlayer(self)
        self._seg_audio = QAudioOutput(self)
        self._seg_player.setAudioOutput(self._seg_audio)
        self._seg_timer = QTimer(self)
        self._seg_timer.setSingleShot(True)
        self._seg_timer.timeout.connect(self._on_segment_finished)
        self._repeat_left = 0
        self._timed_next = False

    def _owner_materials(self) -> list:
        return list(getattr(self.owner, "_materials", []) or [])

    def _current_material(self):
        mats = self._owner_materials()
        idx = int(getattr(self.owner, "_current_index", 0))
        if not mats:
            return None
        return mats[max(0, min(idx, len(mats)-1))]

    def _play_material_segment_or_tts(self, material, speed: float = 1.0, repeat: int = 1, video_output=None):
        self._repeat_left = max(1, int(repeat)) - 1
        self._play_once(material, speed, video_output)

    def _play_once(self, material, speed: float, video_output=None):
        """Play a subtitle segment with a visible video surface when media exists.

        V61 fixes the V60 black/no-sound regression by:
        - never stacking a QLabel over QVideoWidget;
        - assigning video/audio output before setSource;
        - using delayed seek/play so MKV has time to load;
        - falling back to TTS with a visible hint when no local media is bound.
        """
        self._seg_timer.stop()
        media_path = str(getattr(material, "media_path", "") or "")
        start_ms = int(getattr(material, "start_ms", -1))
        end_ms = int(getattr(material, "end_ms", -1))
        if media_path and start_ms >= 0 and Path(media_path).exists():
            try:
                if video_output is not None:
                    self._seg_player.setVideoOutput(video_output)
                self._seg_player.setAudioOutput(self._seg_audio)
                self._seg_audio.setVolume(float(app_settings.get("speech_volume", 1.0)))
                self._seg_player.setPlaybackRate(float(speed))
                target = str(Path(media_path).resolve())
                if self._seg_player.source().toLocalFile() != target:
                    self._seg_player.setSource(QUrl.fromLocalFile(target))
                if hasattr(self, "video_hint"):
                    self.video_hint.setText(f"正在播放本地视频片段：{Path(media_path).name}  {start_ms/1000:.2f}s")

                def seek_and_play():
                    try:
                        self._seg_player.setPosition(max(0, int(start_ms)))
                        self._seg_player.play()
                        if end_ms > start_ms:
                            dur = int((end_ms - start_ms) / max(0.1, float(speed))) + 260
                            self._seg_timer.start(max(320, dur))
                    except Exception as e:
                        if hasattr(self, "video_hint"):
                            self.video_hint.setText(f"视频播放失败，已退回 TTS：{e}")
                        try:
                            self.owner._speech.play_text(str(getattr(material, "english", "") or ""), str(getattr(material, "audio_path", "") or ""))
                        except Exception:
                            pass
                # MKV/large files need a little time after setSource before seek is reliable.
                QTimer.singleShot(260, seek_and_play)
                return True
            except Exception as e:
                if hasattr(self, "video_hint"):
                    self.video_hint.setText(f"本地媒体绑定失败，已退回 TTS：{e}")
        # fallback: no video/audio binding; use the main speech engine and keep the independent window alive.
        try:
            if hasattr(self, "video_hint"):
                self.video_hint.setText("当前字幕没有绑定到同名视频/音频，已使用 TTS 播放。请确认 SRT 与 MKV/MP4/MP3 同目录同名。")
            old_speed = app_settings.get("play_speed", 1.0)
            app_settings.set("play_speed", float(speed))
            self.owner._speech.play_text(str(getattr(material, "english", "") or ""), str(getattr(material, "audio_path", "") or ""))
            app_settings.set("play_speed", old_speed)
        except Exception:
            pass
        return False

    def _on_segment_finished(self):
        try:
            self._seg_player.pause()
        except Exception:
            pass
        if int(getattr(self, "_repeat_left", 0)) > 0:
            self._repeat_left -= 1
            m = self._current_material()
            if m is not None:
                self._play_once(m, float(getattr(self, "speed_box", None).value() if hasattr(self, "speed_box") else 1.0), getattr(self, "video_widget", None))
            return
        if getattr(self, "_timed_next", False):
            self._schedule_next_from_timer()

    def _stop_segment_player(self):
        try:
            self._seg_timer.stop()
            self._seg_player.stop()
            self.owner._speech.player.stop()
        except Exception:
            pass


class FullTranscriptBrowserDialog(QDialog, _SegmentAudioMixin):
    """v56: true full-script browser. No dictation lines, no old mode stack."""
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setObjectName("fullTranscriptDialog")
        self.setWindowTitle("全文浏览｜剧集台词")
        self.setWindowFlags(self.windowFlags() | Qt.Window)
        self.resize(1180, 760)
        self._init_segment_player(False)
        layout = QVBoxLayout(self); layout.setContentsMargins(14, 12, 14, 12); layout.setSpacing(10)
        top = QHBoxLayout()
        self.title = QLabel("全文浏览：像 TXT 文档一样查看完整剧集台词，选中/双击台词即可播放")
        self.title.setObjectName("hintWord")
        top.addWidget(self.title, 1)
        self.click_play = QCheckBox("点击即播放")
        self.click_play.setChecked(True)
        top.addWidget(self.click_play)
        self.filter_edit = QLineEdit(); self.filter_edit.setPlaceholderText("搜索英文 / 中文 / 时间")
        self.filter_edit.setClearButtonEnabled(True); self.filter_edit.setMinimumWidth(280)
        self.filter_edit.textChanged.connect(lambda: self.refresh(keep_filter=True))
        top.addWidget(self.filter_edit)
        self.intensive_btn = QPushButton("打开精听弹窗")
        self.intensive_btn.clicked.connect(self.open_intensive_popup)
        top.addWidget(self.intensive_btn)
        layout.addLayout(top)
        self.table = QTableWidget(0, 4)
        self.table.setObjectName("transcriptTable")
        self.table.setHorizontalHeaderLabels(["序号", "英文台词", "中文翻译", "时间"])
        self.table.setAlternatingRowColors(True); self.table.setWordWrap(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows); self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.itemClicked.connect(self._clicked)
        self.table.itemDoubleClicked.connect(self._double_clicked)
        layout.addWidget(self.table, 1)
        bottom = QHBoxLayout()
        self.prev_btn = QPushButton("‹ 上一句") ; self.prev_btn.clicked.connect(self.prev_line)
        self.play_btn = QPushButton("播放选中台词") ; self.play_btn.clicked.connect(self.play_current_line)
        self.next_btn = QPushButton("下一句 ›") ; self.next_btn.clicked.connect(self.next_line)
        self.stop_btn = QPushButton("停止") ; self.stop_btn.clicked.connect(self._stop_segment_player)
        for b in [self.prev_btn, self.play_btn, self.next_btn, self.stop_btn]: bottom.addWidget(b)
        bottom.addStretch()
        self.info = QLabel("全文浏览只负责阅读和选句播放；精听视频、次数、速度、定时连播在“精听弹窗”里完成。")
        self.info.setObjectName("footerLabel")
        bottom.addWidget(self.info, 1)
        layout.addLayout(bottom)

    def _time_label(self, m):
        if int(getattr(m, "start_ms", -1)) >= 0:
            txt = self.owner._ms_label(int(m.start_ms))
            if int(getattr(m, "end_ms", -1)) > int(m.start_ms):
                txt += " - " + self.owner._ms_label(int(m.end_ms))
            return txt
        if getattr(m, "audio_path", ""):
            return "独立音频"
        return ""

    def refresh(self, keep_filter: bool = True, soft: bool = False):
        mats = self._owner_materials()
        filt = self.filter_edit.text().strip().lower() if keep_filter else ""
        if not keep_filter:
            self.filter_edit.clear()
        current = int(getattr(self.owner, "_current_index", 0))
        self.table.blockSignals(True); self.table.setRowCount(0)
        visible = 0
        for idx, m in enumerate(mats):
            hay = f"{idx+1} {m.english} {m.chinese} {self._time_label(m)}".lower()
            if filt and filt not in hay:
                continue
            row = self.table.rowCount(); self.table.insertRow(row)
            vals = [str(idx + 1), m.english, m.chinese or "", self._time_label(m)]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setData(Qt.UserRole, idx)
                if col == 0: item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row, col, item)
            visible += 1
        self.table.blockSignals(False)
        self.title.setText(f"全文浏览：显示 {visible} / {len(mats)} 条｜没有横线输入框，独立于听写/填空/选词模式")
        self.select_index(current)

    def select_index(self, idx: int):
        try:
            self.table.blockSignals(True)
            for row in range(self.table.rowCount()):
                it = self.table.item(row, 0)
                if it is not None and int(it.data(Qt.UserRole)) == int(idx):
                    self.table.selectRow(row); self.table.scrollToItem(it, QAbstractItemView.PositionAtCenter); break
        finally:
            self.table.blockSignals(False)

    def _clicked(self, item):
        self._set_owner_index(int(item.data(Qt.UserRole)))
        if self.click_play.isChecked():
            self.play_current_line()

    def _double_clicked(self, item):
        self._set_owner_index(int(item.data(Qt.UserRole)))
        self.open_intensive_popup()

    def _set_owner_index(self, idx: int):
        mats = self._owner_materials()
        if not mats: return
        self.owner._current_index = max(0, min(int(idx), len(mats)-1))
        app_settings.set("last_index", self.owner._current_index)
        self.owner._load_current_sentence()
        self.select_index(self.owner._current_index)

    def play_current_line(self):
        m = self._current_material()
        if m is not None:
            self._play_material_segment_or_tts(m, 1.0, 1, None)

    def prev_line(self):
        if self._owner_materials():
            self._set_owner_index(max(0, int(getattr(self.owner, "_current_index", 0)) - 1))
            self.play_current_line()

    def next_line(self):
        mats = self._owner_materials()
        if mats:
            self._set_owner_index(min(len(mats)-1, int(getattr(self.owner, "_current_index", 0)) + 1))
            self.play_current_line()

    def open_intensive_popup(self):
        self.owner._open_intensive_page()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Left:
            self.prev_line(); return
        if event.key() == Qt.Key_Right:
            self.next_line(); return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.play_current_line(); return
        super().keyPressEvent(event)


class IntensiveListeningDialog(QDialog, _SegmentAudioMixin):
    """v56: popup opened from full-script browser; owns video display and intensive controls."""
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setObjectName("intensivePopupDialog")
        self.setWindowTitle("精听模式｜台词 + 翻译 + 视频")
        self.setWindowFlags(self.windowFlags() | Qt.Window)
        self.resize(1180, 720)
        self._init_segment_player(True)
        self._next_timer = QTimer(self); self._next_timer.setSingleShot(True); self._next_timer.timeout.connect(self._timer_next)
        self._movie_sync_timer = QTimer(self); self._movie_sync_timer.setInterval(220); self._movie_sync_timer.timeout.connect(self._sync_movie_position)
        self._movie_mode_active = False
        self._timed_deadline_ts = 0.0
        self._intensive_shortcuts: list[QShortcut] = []
        self._episode_loading = False
        root = QVBoxLayout(self); root.setContentsMargins(14, 12, 14, 12); root.setSpacing(10)
        header = QHBoxLayout()
        self.title = QLabel("精听模式：独立弹窗｜可选集数｜快捷键可设置｜视频/次数/速度/原文翻译显示")
        self.title.setObjectName("hintWord")
        header.addWidget(self.title, 1)
        header.addWidget(QLabel("集数"))
        self.episode_combo = QComboBox()
        self.episode_combo.setMinimumWidth(260)
        self.episode_combo.setToolTip("自由选择要播放/精听的剧集或素材来源。切换后会刷新全文台词列表。")
        self.episode_combo.currentTextChanged.connect(self._change_episode_source)
        header.addWidget(self.episode_combo)
        self.refresh_episode_btn = QPushButton("刷新集数")
        self.refresh_episode_btn.clicked.connect(self._populate_episode_sources)
        header.addWidget(self.refresh_episode_btn)
        self.full_btn = QPushButton("全屏/还原 F11"); self.full_btn.clicked.connect(self.toggle_fullscreen)
        header.addWidget(self.full_btn)
        root.addLayout(header)
        self.splitter = QSplitter(Qt.Horizontal); self.splitter.setObjectName("intensiveSplitter")
        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(0,0,8,0); ll.setSpacing(8)
        ctrl1 = QHBoxLayout()
        self.prev_btn = QPushButton("‹ 上一句") ; self.prev_btn.clicked.connect(self.prev_line)
        self.play_btn = QPushButton("播放当前句") ; self.play_btn.clicked.connect(self.play_current)
        self.pause_btn = QPushButton("暂停/继续") ; self.pause_btn.clicked.connect(self.pause_resume)
        self.stop_btn = QPushButton("停止") ; self.stop_btn.clicked.connect(self.stop_all)
        self.movie_btn = QPushButton("观影模式") ; self.movie_btn.clicked.connect(self.play_movie_mode)
        self.next_btn = QPushButton("下一句 ›") ; self.next_btn.clicked.connect(self.next_line)
        for b in [self.prev_btn, self.play_btn, self.pause_btn, self.stop_btn, self.movie_btn, self.next_btn]: ctrl1.addWidget(b)
        ll.addLayout(ctrl1)
        copy_row = QHBoxLayout()
        self.copy_en_btn = QPushButton("复制英文") ; self.copy_en_btn.clicked.connect(lambda: self.copy_selected_text("en"))
        self.copy_zh_btn = QPushButton("复制中文") ; self.copy_zh_btn.clicked.connect(lambda: self.copy_selected_text("zh"))
        self.copy_bi_btn = QPushButton("复制双语") ; self.copy_bi_btn.clicked.connect(lambda: self.copy_selected_text("bi"))
        self.copy_cur_btn = QPushButton("复制当前句") ; self.copy_cur_btn.clicked.connect(lambda: self.copy_current_text("bi"))
        for b in [self.copy_en_btn, self.copy_zh_btn, self.copy_bi_btn, self.copy_cur_btn]: copy_row.addWidget(b)
        copy_row.addStretch(); ll.addLayout(copy_row)
        ctrl2 = QHBoxLayout()
        ctrl2.addWidget(QLabel("次数")); self.times_box = QSpinBox(); self.times_box.setRange(1, 50); self.times_box.setValue(int(app_settings.get("intensive_play_times", app_settings.get("play_times", 1))))
        self.times_box.valueChanged.connect(lambda v: app_settings.set("intensive_play_times", int(v))); ctrl2.addWidget(self.times_box)
        ctrl2.addWidget(QLabel("速度")); self.speed_box = QDoubleSpinBox(); self.speed_box.setRange(0.5, 2.0); self.speed_box.setSingleStep(0.05); self.speed_box.setValue(float(app_settings.get("intensive_play_speed", app_settings.get("play_speed", 1.0))))
        self.speed_box.valueChanged.connect(lambda v: app_settings.set("intensive_play_speed", float(v))); ctrl2.addWidget(self.speed_box)
        self.show_en = QCheckBox("显示原文"); self.show_en.setChecked(bool(app_settings.get("intensive_show_english", True))); self.show_en.stateChanged.connect(self.update_current_labels); ctrl2.addWidget(self.show_en)
        self.show_zh = QCheckBox("显示翻译"); self.show_zh.setChecked(bool(app_settings.get("intensive_show_chinese", True))); self.show_zh.stateChanged.connect(self.update_current_labels); ctrl2.addWidget(self.show_zh)
        self.video_subtitle_box = QCheckBox("视频字幕"); self.video_subtitle_box.setChecked(bool(app_settings.get("intensive_video_subtitle", True)))
        self.video_subtitle_box.stateChanged.connect(lambda _v: (app_settings.set("intensive_video_subtitle", self.video_subtitle_box.isChecked()), self._update_video_subtitle_overlay()))
        ctrl2.addWidget(self.video_subtitle_box)
        ctrl2.addStretch(); ll.addLayout(ctrl2)
        ctrl3 = QHBoxLayout()
        self.timed_box = QCheckBox("定时连播"); self.timed_box.setChecked(bool(app_settings.get("intensive_timed_play", False))); self.timed_box.stateChanged.connect(lambda _v: app_settings.set("intensive_timed_play", self.timed_box.isChecked())); ctrl3.addWidget(self.timed_box)
        ctrl3.addWidget(QLabel("定时/分钟")); self.timed_minutes_box = QDoubleSpinBox(); self.timed_minutes_box.setRange(0.0, 240.0); self.timed_minutes_box.setSingleStep(1.0); self.timed_minutes_box.setDecimals(1); self.timed_minutes_box.setValue(float(app_settings.get("intensive_timed_minutes", 0.0)))
        self.timed_minutes_box.setToolTip("0 = 不限制总时长；>0 时到点自动停止定时连播。")
        self.timed_minutes_box.valueChanged.connect(lambda v: app_settings.set("intensive_timed_minutes", float(v))); ctrl3.addWidget(self.timed_minutes_box)
        ctrl3.addWidget(QLabel("句间隔/秒")); self.interval_box = QDoubleSpinBox(); self.interval_box.setRange(0.0, 60.0); self.interval_box.setSingleStep(0.5); self.interval_box.setValue(float(app_settings.get("intensive_interval_sec", 1.0)))
        self.interval_box.valueChanged.connect(lambda v: app_settings.set("intensive_interval_sec", float(v))); ctrl3.addWidget(self.interval_box)
        self.filter_edit = QLineEdit(); self.filter_edit.setPlaceholderText("筛选台词"); self.filter_edit.setClearButtonEnabled(True); self.filter_edit.textChanged.connect(lambda: self.refresh(keep_filter=True)); ctrl3.addWidget(self.filter_edit, 1)
        ll.addLayout(ctrl3)
        self.en_label = QLabel("（暂无原文）"); self.en_label.setObjectName("intensiveEnglish"); self.en_label.setWordWrap(True); self.en_label.setTextInteractionFlags(Qt.TextSelectableByMouse); ll.addWidget(self.en_label)
        self.zh_label = QLabel("（暂无翻译）"); self.zh_label.setObjectName("intensiveChinese"); self.zh_label.setWordWrap(True); self.zh_label.setTextInteractionFlags(Qt.TextSelectableByMouse); ll.addWidget(self.zh_label)
        self.table = QTableWidget(0, 4); self.table.setObjectName("intensiveTable"); self.table.setHorizontalHeaderLabels(["序号", "英文台词", "中文", "时间"])
        self.table.setAlternatingRowColors(True); self.table.setWordWrap(True); self.table.setSelectionBehavior(QAbstractItemView.SelectRows); self.table.setSelectionMode(QAbstractItemView.ExtendedSelection); self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents); self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch); self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch); self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.itemClicked.connect(self._clicked)
        QShortcut(QKeySequence.Copy, self.table, activated=lambda: self.copy_selected_text("bi"))
        ll.addWidget(self.table, 1)
        video_host = QFrame(); video_host.setObjectName("intensiveVideoHost"); vl = QVBoxLayout(video_host); vl.setContentsMargins(8,8,8,8); vl.setSpacing(8)
        self.video_canvas = QFrame(video_host); self.video_canvas.setObjectName("intensiveVideoCanvas"); self.video_canvas.setMinimumSize(420, 260)
        # V61: QVideoWidget on Windows is usually a native video surface.
        # Putting a QLabel over it can make the renderer turn black / silent on some machines.
        # Therefore subtitles are rendered in a safe subtitle bar under the video surface.
        video_vbox = QVBoxLayout(self.video_canvas); video_vbox.setContentsMargins(0,0,0,0); video_vbox.setSpacing(6)
        self.video_widget = QVideoWidget(self.video_canvas); self.video_widget.setObjectName("intensiveVideoWidget"); self.video_widget.setMinimumHeight(260)
        video_vbox.addWidget(self.video_widget, 1)
        self.video_subtitle = QLabel("", self.video_canvas); self.video_subtitle.setObjectName("videoSubtitleOverlay")
        self.video_subtitle.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter); self.video_subtitle.setWordWrap(True); self.video_subtitle.setTextFormat(Qt.RichText)
        self.video_subtitle.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.video_subtitle.setStyleSheet("QLabel#videoSubtitleOverlay{background:#111827;color:#FFFFFF;font-weight:900;font-size:24px;padding:10px 18px;border-radius:12px;}")
        video_vbox.addWidget(self.video_subtitle, 0)
        vl.addWidget(self.video_canvas, 1)
        self.video_hint = QLabel("视频区：V61 安全字幕条显示原文/翻译；避免 QLabel 叠在 QVideoWidget 上导致黑屏/无声。")
        self.video_hint.setObjectName("footerLabel"); self.video_hint.setWordWrap(True); vl.addWidget(self.video_hint)
        self._seg_player.setVideoOutput(self.video_widget)
        self.splitter.addWidget(left); self.splitter.addWidget(video_host); self.splitter.setSizes([720, 460]); self.splitter.setChildrenCollapsible(False)
        root.addWidget(self.splitter, 1)
        self._populate_episode_sources()
        self._setup_intensive_shortcuts()
        self.refresh(keep_filter=False)

    def _populate_episode_sources(self):
        """V62: allow selecting another episode/source directly inside 精听模式."""
        try:
            self._episode_loading = True
            current = ""
            try:
                current = self.owner.source_combo.currentText()
            except Exception:
                current = str(app_settings.get("last_source", ""))
            names = []
            try:
                names = list(get_source_names())
            except Exception:
                names = []
            if not names and hasattr(self.owner, "source_combo"):
                names = [self.owner.source_combo.itemText(i) for i in range(self.owner.source_combo.count())]
            self.episode_combo.blockSignals(True)
            self.episode_combo.clear()
            self.episode_combo.addItems(names)
            if current and current in names:
                self.episode_combo.setCurrentText(current)
            self.episode_combo.blockSignals(False)
        finally:
            self._episode_loading = False

    def _change_episode_source(self, source: str):
        if getattr(self, "_episode_loading", False) or not source:
            return
        try:
            self.stop_all(keep_video=True)
        except Exception:
            pass
        try:
            if hasattr(self.owner, "source_combo") and self.owner.source_combo.currentText() != source:
                self.owner.source_combo.setCurrentText(source)
            else:
                self.owner._load_source(source)
            self.filter_edit.clear()
            self.refresh(keep_filter=False)
            self.video_hint.setText(f"已切换集数：{source}")
        except Exception as e:
            QMessageBox.warning(self, "切换集数失败", str(e))

    def _setup_intensive_shortcuts(self):
        """V62: 精听模式快捷键独立读取设置中心。"""
        for sc in getattr(self, "_intensive_shortcuts", []):
            try:
                sc.setEnabled(False); sc.deleteLater()
            except Exception:
                pass
        self._intensive_shortcuts = []
        mapping = {
            "intensive_play_current": self.play_current,
            "intensive_prev_line": self.prev_line,
            "intensive_next_line": self.next_line,
            "intensive_pause_resume": self.pause_resume,
            "intensive_stop": self.stop_all,
            "intensive_movie_mode": self.play_movie_mode,
            "intensive_fullscreen": self.toggle_fullscreen,
            "intensive_exit_fullscreen": self.toggle_fullscreen,
            "intensive_copy_current": lambda: self.copy_current_text("bi"),
        }
        for name, func in mapping.items():
            seq = app_settings.get_shortcut(name)
            if not seq:
                continue
            try:
                sc = QShortcut(QKeySequence(seq), self)
                sc.setContext(Qt.WindowShortcut)
                sc.activated.connect(func)
                self._intensive_shortcuts.append(sc)
            except Exception:
                pass

    def _time_label(self, m):
        if int(getattr(m, "start_ms", -1)) >= 0:
            txt = self.owner._ms_label(int(m.start_ms))
            if int(getattr(m, "end_ms", -1)) > int(m.start_ms):
                txt += " - " + self.owner._ms_label(int(m.end_ms))
            return txt
        if getattr(m, "audio_path", ""):
            return "独立音频"
        return ""

    def refresh(self, keep_filter: bool = True, soft: bool = False):
        mats = self._owner_materials(); filt = self.filter_edit.text().strip().lower() if keep_filter else ""
        current = int(getattr(self.owner, "_current_index", 0))
        self.table.blockSignals(True); self.table.setRowCount(0)
        visible = 0
        for idx, m in enumerate(mats):
            hay = f"{idx+1} {m.english} {m.chinese} {self._time_label(m)}".lower()
            if filt and filt not in hay: continue
            row = self.table.rowCount(); self.table.insertRow(row)
            vals = [str(idx+1), m.english if self.show_en.isChecked() else "（原文已隐藏）", (m.chinese or "") if self.show_zh.isChecked() else "（翻译已隐藏）", self._time_label(m)]
            for col, val in enumerate(vals):
                item=QTableWidgetItem(val); item.setData(Qt.UserRole, idx)
                if col == 0: item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row, col, item)
            visible += 1
        self.table.blockSignals(False)
        src = self.episode_combo.currentText() if hasattr(self, "episode_combo") else ""
        self.title.setText(f"精听模式：{src}｜显示 {visible} / {len(mats)} 条｜快捷键可在设置中心修改")
        self.select_index(current); self.update_current_labels()

    def select_index(self, idx:int):
        try:
            self.table.blockSignals(True)
            for row in range(self.table.rowCount()):
                it=self.table.item(row,0)
                if it is not None and int(it.data(Qt.UserRole)) == int(idx):
                    self.table.selectRow(row); self.table.scrollToItem(it, QAbstractItemView.PositionAtCenter); break
        finally:
            self.table.blockSignals(False)

    def update_current_labels(self, *args):
        app_settings.set("intensive_show_english", self.show_en.isChecked())
        app_settings.set("intensive_show_chinese", self.show_zh.isChecked())
        m=self._current_material()
        if m is None:
            self.en_label.setText("（暂无原文）"); self.zh_label.setText("（暂无翻译）"); return
        self.en_label.setText(m.english if self.show_en.isChecked() else "（原文已隐藏：用于盲听精听）")
        self.zh_label.setText((m.chinese or "（无中文翻译）") if self.show_zh.isChecked() else "（翻译已隐藏）")
        self._update_video_subtitle_overlay()

    def _selected_material_indexes(self) -> list[int]:
        indexes = []
        for item in self.table.selectedItems():
            try:
                idx = int(item.data(Qt.UserRole))
                if idx not in indexes:
                    indexes.append(idx)
            except Exception:
                pass
        if not indexes and self._current_material() is not None:
            indexes = [int(getattr(self.owner, "_current_index", 0))]
        return sorted(indexes)

    def _format_material_for_copy(self, m, mode: str = "bi") -> str:
        en = str(getattr(m, "english", "") or "").strip()
        zh = str(getattr(m, "chinese", "") or "").strip()
        if mode == "en":
            return en
        if mode == "zh":
            return zh
        return (en + ("\n" + zh if zh else "")).strip()

    def copy_selected_text(self, mode: str = "bi"):
        mats = self._owner_materials(); parts = []
        for idx in self._selected_material_indexes():
            if 0 <= idx < len(mats):
                txt = self._format_material_for_copy(mats[idx], mode)
                if txt:
                    parts.append(txt)
        QApplication.clipboard().setText("\n\n".join(parts))

    def copy_current_text(self, mode: str = "bi"):
        m = self._current_material()
        QApplication.clipboard().setText(self._format_material_for_copy(m, mode) if m is not None else "")

    def _set_owner_index(self, idx:int):
        mats=self._owner_materials()
        if not mats: return
        self.owner._current_index=max(0,min(int(idx),len(mats)-1)); app_settings.set("last_index", self.owner._current_index)
        self.owner._load_current_sentence(); self.select_index(self.owner._current_index); self.update_current_labels()

    def _clicked(self, item):
        self._set_owner_index(int(item.data(Qt.UserRole)))
        self.play_current()

    def _update_video_subtitle_overlay(self):
        if not hasattr(self, "video_subtitle"):
            return
        m = self._current_material()
        if m is None or not getattr(self, "video_subtitle_box", None) or not self.video_subtitle_box.isChecked():
            self.video_subtitle.setText(""); return
        en = html.escape(str(getattr(m, "english", "") or "").strip()) if self.show_en.isChecked() else ""
        zh = html.escape(str(getattr(m, "chinese", "") or "").strip()) if self.show_zh.isChecked() else ""
        parts = []
        if zh:
            parts.append(f'<div style="font-size:34px;color:#FFFFFF;font-weight:900;">{zh}</div>')
        if en:
            parts.append(f'<div style="font-size:24px;color:#FFB454;font-style:italic;font-weight:800;">{en}</div>')
        self.video_subtitle.setText("".join(parts))

    def _sync_movie_position(self):
        if not getattr(self, "_movie_mode_active", False):
            return
        mats = self._owner_materials()
        if not mats:
            return
        pos = int(self._seg_player.position())
        cur_media = self._seg_player.source().toLocalFile()
        best = None
        for i, m in enumerate(mats):
            try:
                if cur_media and getattr(m, "media_path", "") and str(Path(m.media_path).resolve()) != str(Path(cur_media).resolve()):
                    continue
                s = int(getattr(m, "start_ms", -1)); e = int(getattr(m, "end_ms", -1))
                if s >= 0 and (e <= s and pos >= s or s <= pos <= max(e, s + 1500)):
                    best = i; break
                if s >= 0 and s <= pos:
                    best = i
            except Exception:
                continue
        if best is not None and best != int(getattr(self.owner, "_current_index", 0)):
            self._set_owner_index(best)
        else:
            self._update_video_subtitle_overlay()

    def play_movie_mode(self):
        m=self._current_material()
        if m is None: return
        try:
            self._next_timer.stop(); self._seg_timer.stop(); self._repeat_left=0; self._timed_next=False
            self._movie_mode_active = True
            if getattr(m, "media_path", "") and Path(m.media_path).exists():
                media = str(Path(m.media_path).resolve())
                self._seg_player.setVideoOutput(self.video_widget)
                self._seg_player.setAudioOutput(self._seg_audio)
                self._seg_audio.setVolume(float(app_settings.get("speech_volume", 1.0)))
                self._seg_player.setPlaybackRate(float(self.speed_box.value()))
                if self._seg_player.source().toLocalFile() != media:
                    self._seg_player.setSource(QUrl.fromLocalFile(media))
                self._update_video_subtitle_overlay()
                def start_movie():
                    if int(getattr(m, "start_ms", -1)) >= 0:
                        self._seg_player.setPosition(max(0, int(m.start_ms)))
                    self._seg_player.play()
                    self._movie_sync_timer.start()
                QTimer.singleShot(260, start_movie)
                self.video_hint.setText("观影模式：连续播放视频；台词会随播放进度自动跳行/高亮，字幕由安全字幕条显示。")
            else:
                self.play_current()
        except Exception:
            self.play_current()

    def play_current(self):
        m=self._current_material()
        if m is None: return
        self._movie_mode_active = False; self._movie_sync_timer.stop()
        self._timed_next = self.timed_box.isChecked()
        if self._timed_next and not getattr(self, "_timed_deadline_ts", 0.0):
            mins = float(self.timed_minutes_box.value()) if hasattr(self, "timed_minutes_box") else 0.0
            self._timed_deadline_ts = time.time() + mins * 60.0 if mins > 0 else 0.0
        self._play_material_segment_or_tts(m, float(self.speed_box.value()), int(self.times_box.value()), self.video_widget)

    def prev_line(self):
        self.stop_all(keep_video=True)
        self._set_owner_index(max(0, int(getattr(self.owner,"_current_index",0))-1))
        self.play_current()

    def next_line(self):
        self.stop_all(keep_video=True)
        mats=self._owner_materials()
        if mats:
            self._set_owner_index(min(len(mats)-1, int(getattr(self.owner,"_current_index",0))+1))
            self.play_current()

    def _schedule_next_from_timer(self):
        delay=int(max(0.0, float(self.interval_box.value()))*1000)
        self._next_timer.start(delay)

    def _timer_next(self):
        mats=self._owner_materials()
        if not mats: return
        if getattr(self, "_timed_deadline_ts", 0.0) and time.time() >= float(self._timed_deadline_ts):
            self._timed_next=False; self._timed_deadline_ts=0.0; self.stop_all(); return
        idx=int(getattr(self.owner,"_current_index",0))
        if idx >= len(mats)-1:
            self._timed_next=False; self._timed_deadline_ts=0.0; return
        self._set_owner_index(idx+1)
        self.play_current()

    def pause_resume(self):
        try:
            if self._seg_player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
                self._seg_player.pause(); self._seg_timer.stop()
            else:
                self._seg_player.play()
        except Exception:
            pass

    def stop_all(self, keep_video: bool=False):
        self._next_timer.stop(); self._movie_sync_timer.stop(); self._movie_mode_active=False; self._timed_next=False; self._timed_deadline_ts=0.0; self._seg_timer.stop(); self._repeat_left=0
        try:
            self._seg_player.pause() if keep_video else self._seg_player.stop()
            self.owner._speech.player.stop()
        except Exception:
            pass

    def toggle_fullscreen(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def keyPressEvent(self,event):
        if event.key()==Qt.Key_Left:
            self.prev_line(); return
        if event.key()==Qt.Key_Right:
            self.next_line(); return
        if event.key() in (Qt.Key_F11, Qt.Key_Escape):
            self.toggle_fullscreen(); return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.play_current(); return
        super().keyPressEvent(event)

    def closeEvent(self,event):
        self.stop_all(); event.accept()


class ActivationDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("软件激活 / 机器码绑定")
        self.resize(760, 620)
        root = QVBoxLayout(self)
        status = get_status()
        root.addWidget(QLabel("本机设备码（发给管理员生成激活码）："))
        self.machine = QLineEdit(status.machine_code)
        self.machine.setReadOnly(True)
        root.addWidget(self.machine)
        btns0 = QHBoxLayout()
        copy_machine = QPushButton("复制设备码")
        copy_machine.clicked.connect(lambda: QApplication.clipboard().setText(self.machine.text()))
        btns0.addWidget(copy_machine); btns0.addStretch(); root.addLayout(btns0)
        root.addWidget(QLabel("粘贴激活码："))
        self.code = QTextEdit()
        self.code.setPlaceholderText("粘贴管理员生成的 200 行激活码")
        self.code.setLineWrapMode(QTextEdit.NoWrap)
        root.addWidget(self.code, 1)
        self.info = QLabel(status.message)
        self.info.setWordWrap(True)
        root.addWidget(self.info)
        btns = QHBoxLayout()
        activate = QPushButton("激活")
        activate.clicked.connect(self.activate)
        close = QPushButton("关闭")
        close.clicked.connect(self.reject)
        btns.addStretch(); btns.addWidget(activate); btns.addWidget(close)
        root.addLayout(btns)

    def activate(self):
        try:
            st = install_activation_code(self.code.toPlainText())
            QMessageBox.information(self, "激活成功", f"已激活到：{st.expires_at}\n权限：" + "、".join(FEATURES[k] for k, v in st.features.items() if v))
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "激活失败", str(e))

class MainWindow(QMainWindow):
    speech_ready = Signal(str)
    speech_error = Signal(str)
    speech_generating = Signal()

    def __init__(self):
        super().__init__()
        self._license_status = get_status()
        self._license_timer = QTimer(self)
        self._license_timer.timeout.connect(self._check_license_runtime)
        self._license_timer.start(60000)
        self.setWindowTitle("MangoDictationMini")
        self.resize(1180, 760)
        self.setMinimumSize(920, 620)
        self._materials: List[Material] = []
        self._current_index = 0
        self._chunks: List[Chunk] = []
        self._chunk_inputs: List[ChunkInput] = []
        self._chunk_ipa_labels: List[QLabel] = []
        self._chunk_hint_labels: List[QLabel] = []
        self._chunk_info_cache: dict[int, list] = {}
        self._choice_selected: list[str] = []
        self._choice_buttons: list[QPushButton] = []
        self._choice_expected_words: list[str] = []
        self._fill_words: list[str] = []
        self._fill_blank_indexes: list[int] = []
        self._fill_selected: list[str] = []
        self._fill_buttons: list[QPushButton] = []
        self._submitted = False
        self._wrong_mode = False
        self._six_step = 0
        self._play_counter = 0
        self._scan_worker = None
        self._load_worker = None
        self._translation_worker = None
        self._resource_root = ""
        self._speech = SpeechEngineManager()
        self._speech.set_callbacks(self.speech_ready.emit, self.speech_error.emit, self.speech_generating.emit)
        self.speech_ready.connect(self._on_speech_ready)
        self.speech_error.connect(self._on_speech_error)
        self.speech_generating.connect(self._on_speech_generating)
        try:
            self._speech.player.mediaStatusChanged.connect(self._on_media_status_changed)
        except Exception:
            pass
        # v55: independent video player for the standalone intensive listening page.
        self._video_player = QMediaPlayer(self)
        self._video_audio = QAudioOutput(self)
        self._video_player.setAudioOutput(self._video_audio)
        self._video_segment_timer = QTimer(self)
        self._video_segment_timer.setSingleShot(True)
        self._video_segment_timer.timeout.connect(self._on_intensive_segment_finished)
        self._intensive_auto_timer = QTimer(self)
        self._intensive_auto_timer.setSingleShot(True)
        self._intensive_auto_timer.timeout.connect(self._intensive_next_and_play)
        self._intensive_repeat_left = 0
        self._floating_video_dialog = None
        self._transcript_dialog = None
        self._intensive_dialog = None
        self._sound = SoundManager()
        self._build_ui(); self._build_menu(); self._build_resource_dock(); self._apply_theme(); self._setup_shortcuts(); self._refresh_sources(); self._load_initial(); self._apply_license_gates()

    # ---------- UI ----------
    def _build_ui(self):
        root = QWidget(); root.setObjectName("root"); self.setCentralWidget(root)
        main = QVBoxLayout(root); self.main_layout = main; main.setContentsMargins(34,22,34,14); main.setSpacing(12)
        top = QHBoxLayout(); self.title_label = QLabel("MangoDictationMini"); self.title_label.setObjectName("titleLabel"); top.addWidget(self.title_label); top.addStretch()
        top.addWidget(QLabel("课程")); self.source_combo = QComboBox(); self.source_combo.setMinimumWidth(260); self.source_combo.currentTextChanged.connect(self._on_source_changed); top.addWidget(self.source_combo)
        top.addSpacing(18); self.progress_label = QLabel("第 0 / 0 句"); self.progress_label.setObjectName("progressLabel"); top.addWidget(self.progress_label); main.addLayout(top)
        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setObjectName("separator"); main.addWidget(line)
        self.chinese_label = QLabel("请导入素材（Ctrl+O）"); self.chinese_label.setObjectName("chineseLabel"); self.chinese_label.setAlignment(Qt.AlignCenter); self.chinese_label.setWordWrap(True); self.chinese_label.setMinimumHeight(86); main.addWidget(self.chinese_label)
        self.mode_bar = QTabBar(); self.mode_bar.setObjectName("modeBar")
        self.mode_bar.addTab("听写模式")
        self.mode_bar.addTab("盲听模式")
        self.mode_bar.addTab("选词模式")
        self.mode_bar.addTab("填空模式")
        self.mode_bar.currentChanged.connect(self._on_mode_tab_changed)
        main.addWidget(self.mode_bar)
        self.mode_stack = QStackedWidget(); self.mode_stack.setObjectName("modeStack")
        self.dictation_page = QWidget(); self.dictation_page.setObjectName("dictationPage")
        dp = QVBoxLayout(self.dictation_page); dp.setContentsMargins(0,0,0,0); dp.setSpacing(0)
        self.dictation_panel = QWidget(); self.dictation_panel.setObjectName("dictationPanel"); self.dictation_panel.setMinimumHeight(190); self.dictation_panel.setMaximumHeight(330); self.dictation_layout = QVBoxLayout(self.dictation_panel); self.dictation_layout.setContentsMargins(18,18,18,18); self.dictation_layout.setSpacing(12); dp.addWidget(self.dictation_panel)
        self.mode_stack.addWidget(self.dictation_page)
        self.status_label = QLabel(""); self.status_label.setObjectName("statusLabel"); self.status_label.setAlignment(Qt.AlignCenter); main.addWidget(self.status_label)
        self.workspace_tabs = QTabWidget(); self.workspace_tabs.setObjectName("workspaceTabs")
        self.hint_box = QFrame(); self.hint_box.setObjectName("hintBox"); h = QVBoxLayout(self.hint_box); h.setContentsMargins(16,10,16,10); h.setSpacing(4)
        self.hint_word = QLabel(""); self.hint_word.setObjectName("hintWord")
        self.hint_text = QLabel(""); self.hint_text.setObjectName("hintText"); self.hint_text.setWordWrap(True); self.hint_text.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.hint_scroll = QScrollArea(); self.hint_scroll.setWidgetResizable(True); self.hint_scroll.setFrameShape(QFrame.NoFrame); self.hint_scroll.setWidget(self.hint_text)
        self.hint_scroll.setMinimumHeight(80)
        self.hint_scroll.setMaximumHeight(16777215)  # v48: allow splitter resizing instead of fixed max height
        h.addWidget(self.hint_word); h.addWidget(self.hint_scroll, 1); self.hint_box.setMinimumHeight(120)
        self.workspace_tabs.addTab(self.hint_box, "彩色提示")

        self.choice_panel = QWidget(); self.choice_panel.setObjectName("choicePanel")
        cp = QVBoxLayout(self.choice_panel); cp.setContentsMargins(16,12,16,12); cp.setSpacing(10)
        self.choice_status = QLabel("选词模式：按正确顺序点击单词。上方横线显示目标词位，下方是候选词。") ; self.choice_status.setObjectName("choiceStatus"); self.choice_status.setWordWrap(True); cp.addWidget(self.choice_status)
        self.choice_slots = QLabel(""); self.choice_slots.setObjectName("choiceSlots"); self.choice_slots.setWordWrap(True); self.choice_slots.setTextInteractionFlags(Qt.TextSelectableByMouse); cp.addWidget(self.choice_slots)
        self.choice_answer = QLabel(""); self.choice_answer.setObjectName("choiceAnswer"); self.choice_answer.setWordWrap(True); cp.addWidget(self.choice_answer)
        self.choice_scroll = QScrollArea(); self.choice_scroll.setWidgetResizable(True); self.choice_scroll.setFrameShape(QFrame.NoFrame); self.choice_scroll.setMaximumHeight(190)
        self.choice_words_host = QWidget(); self.choice_words_layout = QGridLayout(self.choice_words_host); self.choice_words_layout.setContentsMargins(4,4,4,4); self.choice_words_layout.setHorizontalSpacing(10); self.choice_words_layout.setVerticalSpacing(10)
        self.choice_scroll.setWidget(self.choice_words_host); cp.addWidget(self.choice_scroll, 0)
        choice_btns = QHBoxLayout(); self.choice_reset_btn = QPushButton("重置选词"); self.choice_reset_btn.clicked.connect(self._reset_choice_mode); choice_btns.addWidget(self.choice_reset_btn); choice_btns.addStretch(); cp.addLayout(choice_btns)
        cp.addStretch(1)
        self.mode_stack.addWidget(self.choice_panel)

        self.fill_panel = QWidget(); self.fill_panel.setObjectName("fillPanel")
        fp = QVBoxLayout(self.fill_panel); fp.setContentsMargins(16,12,16,12); fp.setSpacing(10)
        self.fill_status = QLabel("填空模式：阅读句子，按空格位置点击正确单词。")
        self.fill_status.setObjectName("fillStatus"); self.fill_status.setWordWrap(True); fp.addWidget(self.fill_status)
        self.fill_sentence = QLabel("")
        self.fill_sentence.setObjectName("fillSentence"); self.fill_sentence.setWordWrap(True); self.fill_sentence.setTextInteractionFlags(Qt.TextSelectableByMouse); fp.addWidget(self.fill_sentence)
        self.fill_scroll = QScrollArea(); self.fill_scroll.setWidgetResizable(True); self.fill_scroll.setFrameShape(QFrame.NoFrame)
        self.fill_words_host = QWidget(); self.fill_words_layout = QGridLayout(self.fill_words_host); self.fill_words_layout.setContentsMargins(4,4,4,4); self.fill_words_layout.setHorizontalSpacing(8); self.fill_words_layout.setVerticalSpacing(8)
        self.fill_scroll.setWidget(self.fill_words_host); self.fill_scroll.setMaximumHeight(190); fp.addWidget(self.fill_scroll, 0)
        fill_btns = QHBoxLayout(); self.fill_reset_btn = QPushButton("重置填空"); self.fill_reset_btn.clicked.connect(self._reset_fill_mode); fill_btns.addWidget(self.fill_reset_btn); fill_btns.addStretch(); fp.addLayout(fill_btns)
        self.mode_stack.addWidget(self.fill_panel)

        # v48: mode stack and bottom hint/workspace are placed in a vertical splitter so the hint panel can be dragged larger/smaller.
        # main.addWidget(self.mode_stack, 3)

        self.quick_panel = QWidget(); self.quick_panel.setObjectName("quickPanel")
        qp = QVBoxLayout(self.quick_panel); qp.setContentsMargins(16,12,16,12)
        self.engine_status_label = QLabel("F1 切换发音模型｜F2 切换声音｜F3 切换翻译模型｜F4/F5/F6 显示隐藏｜F7 盲听｜F8 模式")
        self.engine_status_label.setObjectName("engineStatusLabel"); self.engine_status_label.setWordWrap(True); qp.addWidget(self.engine_status_label); qp.addStretch()
        self.workspace_tabs.addTab(self.quick_panel, "快捷状态")

        self.transcript_panel = QWidget(); self.transcript_panel.setObjectName("transcriptPanel")
        tp = QVBoxLayout(self.transcript_panel); tp.setContentsMargins(12,10,12,10); tp.setSpacing(8)
        transcript_top = QHBoxLayout()
        self.transcript_title = QLabel("全文浏览：点击任意台词即可定位并播放")
        self.transcript_title.setObjectName("hintWord")
        transcript_top.addWidget(self.transcript_title)
        transcript_top.addStretch()
        self.transcript_click_play = QCheckBox("点击即播放")
        self.transcript_click_play.setChecked(True)
        transcript_top.addWidget(self.transcript_click_play)
        self.transcript_filter = QLineEdit()
        self.transcript_filter.setPlaceholderText("筛选英文 / 中文台词")
        self.transcript_filter.setClearButtonEnabled(True)
        self.transcript_filter.textChanged.connect(self._refresh_transcript_browser)
        self.transcript_filter.setMinimumWidth(220)
        transcript_top.addWidget(self.transcript_filter)
        tp.addLayout(transcript_top)
        self.transcript_table = QTableWidget(0, 4)
        self.transcript_table.setObjectName("transcriptTable")
        self.transcript_table.setHorizontalHeaderLabels(["序号", "英文台词", "中文", "时间/音频"])
        self.transcript_table.setAlternatingRowColors(True)
        self.transcript_table.setWordWrap(True)
        self.transcript_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.transcript_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.transcript_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.transcript_table.verticalHeader().setVisible(False)
        self.transcript_table.horizontalHeader().setStretchLastSection(False)
        self.transcript_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.transcript_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.transcript_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.transcript_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.transcript_table.itemClicked.connect(self._on_transcript_item_clicked)
        tp.addWidget(self.transcript_table, 1)
        # v56: 全文浏览改为完全独立弹窗，不再叠加在底部工作区。
        # self.workspace_tabs.addTab(self.transcript_panel, "全文浏览")

        # v55: standalone intensive listening page, inspired by full-script episode players.
        self.intensive_panel = QWidget(); self.intensive_panel.setObjectName("intensivePanel")
        ip = QVBoxLayout(self.intensive_panel); ip.setContentsMargins(12,10,12,10); ip.setSpacing(8)
        i_top = QHBoxLayout()
        self.intensive_title = QLabel("单独精听播放页：点击台词播放，←/→ 切换上一句/下一句")
        self.intensive_title.setObjectName("hintWord")
        i_top.addWidget(self.intensive_title, 1)
        self.intensive_open_float_btn = QPushButton("视频小窗")
        self.intensive_open_float_btn.clicked.connect(self._float_video_window)
        i_top.addWidget(self.intensive_open_float_btn)
        self.intensive_video_full_btn = QPushButton("视频全屏")
        self.intensive_video_full_btn.clicked.connect(self._fullscreen_video_window)
        i_top.addWidget(self.intensive_video_full_btn)
        ip.addLayout(i_top)

        self.intensive_splitter = QSplitter(Qt.Horizontal)
        self.intensive_splitter.setObjectName("intensiveSplitter")
        self.intensive_left = QWidget(); il = QVBoxLayout(self.intensive_left); il.setContentsMargins(0,0,8,0); il.setSpacing(8)
        ctrl1 = QHBoxLayout()
        self.intensive_play_btn = QPushButton("播放当前句")
        self.intensive_play_btn.clicked.connect(self._intensive_play_current)
        self.intensive_prev_btn = QPushButton("‹ 上一句")
        self.intensive_prev_btn.clicked.connect(self._intensive_prev)
        self.intensive_next_btn = QPushButton("下一句 ›")
        self.intensive_next_btn.clicked.connect(self._intensive_next)
        self.intensive_pause_btn = QPushButton("暂停/继续")
        self.intensive_pause_btn.clicked.connect(self._intensive_toggle_pause)
        self.intensive_stop_btn = QPushButton("停止")
        self.intensive_stop_btn.clicked.connect(self._intensive_stop_all)
        for b in [self.intensive_prev_btn, self.intensive_play_btn, self.intensive_pause_btn, self.intensive_stop_btn, self.intensive_next_btn]:
            ctrl1.addWidget(b)
        il.addLayout(ctrl1)

        ctrl2 = QHBoxLayout()
        ctrl2.addWidget(QLabel("次数"))
        self.intensive_times = QSpinBox(); self.intensive_times.setRange(1, 20); self.intensive_times.setValue(int(app_settings.get("intensive_play_times", app_settings.get("play_times", 1))))
        self.intensive_times.valueChanged.connect(lambda v: app_settings.set("intensive_play_times", int(v)))
        ctrl2.addWidget(self.intensive_times)
        ctrl2.addWidget(QLabel("速度"))
        self.intensive_speed = QDoubleSpinBox(); self.intensive_speed.setRange(0.5, 2.0); self.intensive_speed.setSingleStep(0.05); self.intensive_speed.setValue(float(app_settings.get("intensive_play_speed", app_settings.get("play_speed", 1.0))))
        self.intensive_speed.valueChanged.connect(lambda v: app_settings.set("intensive_play_speed", float(v)))
        ctrl2.addWidget(self.intensive_speed)
        self.intensive_show_en = QCheckBox("显示原文"); self.intensive_show_en.setChecked(bool(app_settings.get("intensive_show_english", True)))
        self.intensive_show_en.stateChanged.connect(self._refresh_intensive_visibility)
        ctrl2.addWidget(self.intensive_show_en)
        self.intensive_show_zh = QCheckBox("显示翻译"); self.intensive_show_zh.setChecked(bool(app_settings.get("intensive_show_chinese", True)))
        self.intensive_show_zh.stateChanged.connect(self._refresh_intensive_visibility)
        ctrl2.addWidget(self.intensive_show_zh)
        ctrl2.addStretch()
        il.addLayout(ctrl2)

        ctrl3 = QHBoxLayout()
        self.intensive_timed = QCheckBox("定时连播")
        self.intensive_timed.setChecked(bool(app_settings.get("intensive_timed_play", False)))
        self.intensive_timed.stateChanged.connect(lambda _v: app_settings.set("intensive_timed_play", self.intensive_timed.isChecked()))
        ctrl3.addWidget(self.intensive_timed)
        ctrl3.addWidget(QLabel("句间隔/秒"))
        self.intensive_interval = QDoubleSpinBox(); self.intensive_interval.setRange(0.0, 30.0); self.intensive_interval.setSingleStep(0.5); self.intensive_interval.setValue(float(app_settings.get("intensive_interval_sec", 1.0)))
        self.intensive_interval.valueChanged.connect(lambda v: app_settings.set("intensive_interval_sec", float(v)))
        ctrl3.addWidget(self.intensive_interval)
        self.intensive_filter = QLineEdit(); self.intensive_filter.setPlaceholderText("筛选当前剧集台词")
        self.intensive_filter.setClearButtonEnabled(True); self.intensive_filter.textChanged.connect(self._refresh_intensive_table)
        ctrl3.addWidget(self.intensive_filter, 1)
        il.addLayout(ctrl3)

        self.intensive_english_label = QLabel("（暂无原文）")
        self.intensive_english_label.setObjectName("intensiveEnglish")
        self.intensive_english_label.setWordWrap(True); self.intensive_english_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        il.addWidget(self.intensive_english_label)
        self.intensive_chinese_label = QLabel("（暂无翻译）")
        self.intensive_chinese_label.setObjectName("intensiveChinese")
        self.intensive_chinese_label.setWordWrap(True); self.intensive_chinese_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        il.addWidget(self.intensive_chinese_label)
        self.intensive_table = QTableWidget(0, 4)
        self.intensive_table.setObjectName("intensiveTable")
        self.intensive_table.setHorizontalHeaderLabels(["序号", "英文台词", "中文", "时间"])
        self.intensive_table.setAlternatingRowColors(True); self.intensive_table.setWordWrap(True)
        self.intensive_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.intensive_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.intensive_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.intensive_table.verticalHeader().setVisible(False)
        self.intensive_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.intensive_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.intensive_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.intensive_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.intensive_table.itemClicked.connect(self._on_intensive_item_clicked)
        il.addWidget(self.intensive_table, 1)

        self.intensive_video_host = QFrame(); self.intensive_video_host.setObjectName("intensiveVideoHost")
        vr = QVBoxLayout(self.intensive_video_host); vr.setContentsMargins(8,8,8,8); vr.setSpacing(8)
        self.intensive_video_widget = QVideoWidget(self.intensive_video_host)
        self.intensive_video_widget.setObjectName("intensiveVideoWidget")
        self.intensive_video_widget.setMinimumSize(360, 220)
        vr.addWidget(self.intensive_video_widget, 1)
        self.intensive_video_hint = QLabel("视频预览区：导入 SRT/VTT 并同目录存在同名 MP4/MKV/MP3 时，点击台词会按时间段播放。可一键弹出小窗自由拖动。")
        self.intensive_video_hint.setWordWrap(True); self.intensive_video_hint.setObjectName("footerLabel")
        vr.addWidget(self.intensive_video_hint)
        self._video_player.setVideoOutput(self.intensive_video_widget)

        self.intensive_splitter.addWidget(self.intensive_left)
        self.intensive_splitter.addWidget(self.intensive_video_host)
        self.intensive_splitter.setSizes([760, 420])
        self.intensive_splitter.setChildrenCollapsible(False)
        ip.addWidget(self.intensive_splitter, 1)
        # v56: 精听模式改为全文浏览下的独立弹窗，不再叠加在底部工作区。
        # self.workspace_tabs.addTab(self.intensive_panel, "精听播放页")
        self.vertical_splitter = QSplitter(Qt.Vertical)
        self.vertical_splitter.setObjectName("mainVerticalSplitter")
        self.vertical_splitter.addWidget(self.mode_stack)
        self.vertical_splitter.addWidget(self.workspace_tabs)
        self.vertical_splitter.setChildrenCollapsible(False)
        self.vertical_splitter.setHandleWidth(9)
        try:
            raw_sizes = app_settings.get("main_splitter_sizes", [])
            if isinstance(raw_sizes, list) and len(raw_sizes) == 2 and all(int(x) > 0 for x in raw_sizes):
                self.vertical_splitter.setSizes([int(raw_sizes[0]), int(raw_sizes[1])])
            else:
                self.vertical_splitter.setSizes([520, 260])
        except Exception:
            self.vertical_splitter.setSizes([520, 260])
        self.vertical_splitter.splitterMoved.connect(self._save_main_splitter_sizes)
        main.addWidget(self.vertical_splitter, 1)
        self._floating_hint_dialog = None
        footer_bar = QHBoxLayout(); footer_bar.setSpacing(10); footer_bar.addStretch()
        self.prev_btn = QPushButton("‹ 上一句"); self.prev_btn.setObjectName("navButton"); self.prev_btn.clicked.connect(self._prev_sentence); footer_bar.addWidget(self.prev_btn)
        self.play_sentence_btn = QPushButton("播放整句 Ctrl+↑"); self.play_sentence_btn.clicked.connect(self._play_sentence); footer_bar.addWidget(self.play_sentence_btn)
        self.play_chunk_btn = QPushButton("播放语块 Ctrl+↓"); self.play_chunk_btn.clicked.connect(self._play_current_chunk); footer_bar.addWidget(self.play_chunk_btn)
        self.copy_sentence_btn = QPushButton("复制台词 Ctrl+Shift+C"); self.copy_sentence_btn.clicked.connect(self._copy_sentence); footer_bar.addWidget(self.copy_sentence_btn)
        self.show_answer_btn = QPushButton("显示答案 Ctrl+;"); self.show_answer_btn.clicked.connect(self._show_answer); footer_bar.addWidget(self.show_answer_btn)
        self.next_btn = QPushButton("下一句 ›"); self.next_btn.setObjectName("navButton"); self.next_btn.clicked.connect(self._next_sentence); footer_bar.addWidget(self.next_btn)
        footer_bar.addStretch(); main.addLayout(footer_bar)
        self.footer_label = QLabel(""); self.footer_label.setObjectName("footerLabel"); self.footer_label.setAlignment(Qt.AlignCenter); main.addWidget(self.footer_label); self._refresh_shortcut_texts()

    def _save_main_splitter_sizes(self, *args):
        try:
            if hasattr(self, "vertical_splitter"):
                app_settings.set("main_splitter_sizes", [int(x) for x in self.vertical_splitter.sizes()])
        except Exception:
            pass

    def _build_menu(self):
        menu = self.menuBar(); file_menu = menu.addMenu("文件"); self.scan_action = QAction("扫描资源文件夹", self); self.scan_action.triggered.connect(self._scan_folder); file_menu.addAction(self.scan_action); self.rescan_action = QAction("重新扫描当前文件夹", self); self.rescan_action.triggered.connect(self._rescan_folder); file_menu.addAction(self.rescan_action); self.import_action = QAction("打开单个素材文件", self); self.import_action.triggered.connect(self._import_material); file_menu.addAction(self.import_action); file_menu.addSeparator(); exit_action = QAction("退出", self); exit_action.triggered.connect(self.close); file_menu.addAction(exit_action)
        prac = menu.addMenu("练习"); self.wrong_action = QAction("只练错题", self); self.wrong_action.triggered.connect(self._practice_wrong_items); prac.addAction(self.wrong_action); self.all_action = QAction("练习全部", self); self.all_action.triggered.connect(self._practice_all); prac.addAction(self.all_action); prac.addSeparator(); copy_action = QAction("复制整句台词", self); copy_action.triggered.connect(self._copy_sentence); prac.addAction(copy_action); exp = QAction("导出错题 CSV", self); exp.triggered.connect(self._export_wrong_csv); prac.addAction(exp); clear = QAction("清空错题本", self); clear.triggered.connect(self._clear_wrong_items); prac.addAction(clear)
        view_menu = menu.addMenu("视图")
        self.open_transcript_action = QAction("打开全文浏览", self)
        self.open_transcript_action.triggered.connect(self._open_transcript_tab)
        view_menu.addAction(self.open_transcript_action)
        self.open_intensive_action = QAction("打开精听播放页", self)
        self.open_intensive_action.triggered.connect(self._open_intensive_page)
        view_menu.addAction(self.open_intensive_action)
        view_menu.addSeparator()
        self.toggle_resource_action = QAction("显示/隐藏资源库", self)
        self.toggle_resource_action.triggered.connect(self._toggle_resource_library)
        view_menu.addAction(self.toggle_resource_action)
        view_menu.addSeparator()
        a = QAction("显示/隐藏中文 F4", self); a.triggered.connect(self._toggle_chinese_runtime); view_menu.addAction(a)
        a = QAction("显示/隐藏音标 F5", self); a.triggered.connect(self._toggle_ipa_runtime); view_menu.addAction(a)
        a = QAction("显示/隐藏横线提示 F6", self); a.triggered.connect(self._toggle_subhint_runtime); view_menu.addAction(a)
        view_menu.addSeparator()
        a = QAction("盲听模式 F7", self); a.triggered.connect(self._toggle_blind_mode); view_menu.addAction(a)
        a = QAction("切换练习模式 F8", self); a.triggered.connect(self._cycle_practice_mode); view_menu.addAction(a)
        prod_menu = menu.addMenu("制作台")
        self.production_action = QAction("字幕翻译 / Edge-TTS 缓存制作台", self)
        self.production_action.triggered.connect(self._open_production_workbench)
        prod_menu.addAction(self.production_action)
        settings = menu.addMenu("设置"); pref = QAction("偏好设置", self); pref.triggered.connect(self._open_settings); settings.addAction(pref)
        diag = QAction("Kaikki 词典诊断", self); diag.triggered.connect(self._diagnose_kaikki); settings.addAction(diag)
        settings.addSeparator()
        act = QAction("软件激活 / 查看设备码", self); act.triggered.connect(self._open_activation_dialog); settings.addAction(act)

    def _open_activation_dialog(self):
        dlg = ActivationDialog(self)
        if dlg.exec():
            self._license_status = get_status()
            self._apply_license_gates()

    def _check_license_runtime(self):
        self._license_status = get_status()
        if not self._license_status.activated and self._license_status.trial_remaining_seconds <= 0:
            self._apply_license_gates()
            self.status_label.setText("未激活试用已结束：请在 设置 → 软件激活 中输入激活码。")
        else:
            self._apply_license_gates(silent=True)

    def _license_text(self) -> str:
        st = self._license_status
        if st.activated and st.valid:
            allowed = "、".join(FEATURES[k] for k, v in st.features.items() if v) or "无"
            return f"已激活｜到期：{st.expires_at}｜权限：{allowed}"
        if st.trial_remaining_seconds > 0:
            return f"未激活试用｜仅听写训练｜剩余 {st.trial_remaining_seconds//60} 分钟"
        return "未激活试用已结束｜请激活"

    def _require_feature(self, feature: str) -> bool:
        self._license_status = get_status()
        if self._license_status.has(feature):
            return True
        QMessageBox.warning(self, "功能未授权", f"当前机器未获得权限：{FEATURES.get(feature, feature)}\n\n{self._license_status.message}\n\n设备码：{self._license_status.machine_code}")
        self._open_activation_dialog()
        return False

    def _apply_license_gates(self, silent: bool = False):
        st = self._license_status = get_status()
        try:
            self.footer_label.setText(self._license_text())
        except Exception:
            pass
        def en(action_name: str, feature: str):
            a = getattr(self, action_name, None)
            if a is not None:
                a.setEnabled(st.has(feature))
        en("open_transcript_action", "transcript")
        en("open_intensive_action", "intensive")
        en("production_action", "production")
        try:
            for i, feature in [(0, "dictation"), (1, "blind"), (2, "choice"), (3, "fill_blank")]:
                self.mode_bar.setTabEnabled(i, st.has(feature))
            if not st.has("dictation"):
                self.mode_bar.setEnabled(False)
            elif not self.mode_bar.isTabEnabled(self.mode_bar.currentIndex()):
                self.mode_bar.setCurrentIndex(0)
        except Exception:
            pass


    def _open_production_workbench(self):
        if not self._require_feature("production"):
            return
        if not hasattr(self, "_production_workbench") or self._production_workbench is None:
            self._production_workbench = ProductionWorkbench(self)
        self._production_workbench.show()
        self._production_workbench.raise_()
        self._production_workbench.activateWindow()

    def _apply_theme(self):
        theme_name = str(app_settings.get("theme", "云青禅意") or "云青禅意")
        line_color = str(app_settings.get("chunk_line_color", "theme") or "theme")
        skin_name = str(app_settings.get("skin", "极简学习本") or "极简学习本")
        qss = make_qss(theme_name, line_color, skin_name)
        # Apply to QApplication globally.  Applying only to QMainWindow made some
        # native child widgets keep the previous palette, so switching themes
        # looked like “no change”.
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet("")
            app.setStyleSheet(qss)
        self.setStyleSheet(qss)
        self._apply_skin_runtime(skin_name)
        try:
            if self.centralWidget():
                self.centralWidget().setAttribute(Qt.WA_StyledBackground, True)
            for inp in getattr(self, "_chunk_inputs", []):
                try:
                    inp._apply_line_style(str(inp.property("state") or "normal"))
                except Exception:
                    pass
            for w in self.findChildren(QWidget):
                w.style().unpolish(w)
                w.style().polish(w)
                w.update()
            self.update()
            log_path = ROOT / "data" / "theme_apply.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            tokens = THEME_TOKENS.get(theme_name, {})
            log_path.write_text(f"theme={theme_name}\nskin={skin_name}\nline_color={line_color}\nprimary={tokens.get('primary')}\nsecondary={tokens.get('secondary')}\naccent={tokens.get('accent')}\nbackground={tokens.get('bg')}\nqss_len={len(qss)}\n", encoding="utf-8")
        except Exception:
            pass

    def _apply_skin_runtime(self, skin_name: str) -> None:
        """Runtime layout changes that QSS alone cannot express reliably."""
        try:
            profiles = {
                "极简学习本": dict(m=(34,22,34,14), spacing=12, panel=(190,330), splitter=9, row=54),
                "国风雅卷": dict(m=(38,24,38,16), spacing=14, panel=(210,355), splitter=10, row=64),
                "商务绅士": dict(m=(30,20,30,14), spacing=10, panel=(190,320), splitter=8, row=54),
                "赛博终端": dict(m=(24,16,24,12), spacing=8, panel=(180,305), splitter=7, row=48),
                "轻奢奶油": dict(m=(42,28,42,18), spacing=16, panel=(220,370), splitter=11, row=66),
                "胶片影视": dict(m=(32,20,32,14), spacing=12, panel=(205,350), splitter=9, row=62),
                "学霸练习册": dict(m=(22,14,22,10), spacing=7, panel=(170,285), splitter=7, row=46),
                "悬浮挂件": dict(m=(18,12,18,10), spacing=6, panel=(155,250), splitter=6, row=42),
            }
            cfg = profiles.get(skin_name, profiles["极简学习本"])
            if hasattr(self, "main_layout"):
                self.main_layout.setContentsMargins(*cfg["m"])
                self.main_layout.setSpacing(int(cfg["spacing"]))
            if hasattr(self, "dictation_panel"):
                self.dictation_panel.setMinimumHeight(int(cfg["panel"][0]))
                self.dictation_panel.setMaximumHeight(int(cfg["panel"][1]))
            if hasattr(self, "vertical_splitter"):
                self.vertical_splitter.setHandleWidth(int(cfg["splitter"]))
            if hasattr(self, "transcript_table"):
                self.transcript_table.verticalHeader().setDefaultSectionSize(int(cfg["row"]))
            if hasattr(self, "intensive_table"):
                self.intensive_table.verticalHeader().setDefaultSectionSize(int(cfg["row"]))
            if hasattr(self, "title_label"):
                suffix = {
                    "极简学习本": " · Minimal", "国风雅卷": " · Chinese Classic", "商务绅士": " · Business",
                    "赛博终端": " · Cyber", "轻奢奶油": " · Cream", "胶片影视": " · Cinema",
                    "学霸练习册": " · Notebook", "悬浮挂件": " · Floating",
                }.get(skin_name, "")
                self.title_label.setText("MangoDictationMini" + suffix)
        except Exception:
            pass

    def _setup_shortcuts(self):
        for child in self.findChildren(QShortcut):
            child.setEnabled(False); child.deleteLater()
        actions = {
            "play_sentence": self._play_sentence,
            "play_current_chunk": self._play_current_chunk,
            "submit": self._on_enter,
            "show_hint": self._six_step_hint,
            "show_answer": self._show_answer,
            "fullscreen": self._toggle_fullscreen,
            "exit_fullscreen": self._exit_fullscreen,
            "prev_sentence": self._prev_sentence,
            "next_sentence": self._next_sentence,
            "import_material": self._import_material,
            "favorite": self._toggle_favorite,
            "copy_sentence": self._copy_sentence,
            "scan_folder": self._scan_folder,
            "toggle_resource_library": self._toggle_resource_library,
            "cycle_speech_engine": self._cycle_speech_engine,
            "cycle_speech_voice": self._cycle_speech_voice,
            "cycle_translation_engine": self._cycle_translation_engine,
            "toggle_chinese_runtime": self._toggle_chinese_runtime,
            "toggle_ipa_runtime": self._toggle_ipa_runtime,
            "toggle_subhint_runtime": self._toggle_subhint_runtime,
            "toggle_blind_mode": self._toggle_blind_mode,
            "cycle_practice_mode": self._cycle_practice_mode,
        }
        for name, func in actions.items():
            seq = app_settings.get_shortcut(name)
            if seq:
                sc = QShortcut(QKeySequence(seq), self); sc.setContext(Qt.ApplicationShortcut); sc.activated.connect(func)
        self._refresh_shortcut_texts()

    def _refresh_shortcut_texts(self):
        """Refresh visible shortcut labels from settings instead of hardcoding them."""
        try:
            ps = app_settings.get_shortcut("play_sentence")
            pc = app_settings.get_shortcut("play_current_chunk")
            cp = app_settings.get_shortcut("copy_sentence")
            ans = app_settings.get_shortcut("show_answer")
            sub = app_settings.get_shortcut("submit")
            hint = app_settings.get_shortcut("show_hint")
            f1 = app_settings.get_shortcut("cycle_speech_engine")
            f2 = app_settings.get_shortcut("cycle_speech_voice")
            f3 = app_settings.get_shortcut("cycle_translation_engine")
            if hasattr(self, "play_sentence_btn"):
                self.play_sentence_btn.setText(f"播放整句 {ps}")
            if hasattr(self, "play_chunk_btn"):
                self.play_chunk_btn.setText(f"播放语块 {pc}")
            if hasattr(self, "copy_sentence_btn"):
                self.copy_sentence_btn.setText(f"复制台词 {cp}")
            if hasattr(self, "show_answer_btn"):
                self.show_answer_btn.setText(f"显示答案 {ans}")
            if hasattr(self, "footer_label"):
                f4 = app_settings.get_shortcut("toggle_chinese_runtime"); f5 = app_settings.get_shortcut("toggle_ipa_runtime"); f6 = app_settings.get_shortcut("toggle_subhint_runtime"); f7 = app_settings.get_shortcut("toggle_blind_mode"); f8 = app_settings.get_shortcut("cycle_practice_mode")
                self.footer_label.setText(f"Space：有输入才跳转｜{sub}：提交｜{hint}：六步｜{f1}/{f2}/{f3}：发音/声音/翻译｜{f4}/{f5}/{f6}：中/音/提示｜{f7}/{f8}：盲听/模式")
        except Exception:
            pass

    def _available_kokoro_voices(self) -> list[str]:
        vals = []
        try:
            base = Path(str(app_settings.get("kokoro_voices_dir", "") or "").strip())
            if not base.exists():
                model_dir = Path(str(app_settings.get("kokoro_model_dir", "") or "").strip())
                maybe = model_dir / "voices"
                if maybe.exists():
                    base = maybe
            if base.exists() and base.is_dir():
                vals = [p.stem for p in sorted(base.glob("*.pt"))]
        except Exception:
            vals = []
        return vals or ["af_heart", "af_bella", "af_alloy", "af_aoede", "am_adam", "bf_emma", "bm_george"]

    def _cycle_setting(self, key: str, values: list[str]) -> str:
        current = str(app_settings.get(key, values[0]) or values[0])
        if current not in values:
            nxt = values[0]
        else:
            nxt = values[(values.index(current) + 1) % len(values)]
        app_settings.set(key, nxt)
        return nxt

    def _cycle_speech_engine(self):
        values = ["kokoro", "edge_tts", "chattts", "melotts", "styletts2", "local_audio"]
        nxt = self._cycle_setting("speech_engine", values)
        self._apply_runtime_settings("shortcut_cycle", {"speech_engine"})
        self._set_status(f"发音引擎已切换：{nxt}", "correct")

    def _cycle_speech_voice(self):
        engine = str(app_settings.get("speech_engine", "edge_tts") or "edge_tts")
        if engine == "kokoro":
            voices = self._available_kokoro_voices()
            current = str(app_settings.get("kokoro_voice", voices[0]) or voices[0])
            nxt = voices[(voices.index(current) + 1) % len(voices)] if current in voices else voices[0]
            app_settings.set("kokoro_voice", nxt)
        elif engine == "melotts":
            voices = ["EN-US", "EN", "EN_NEWEST"]
            current = str(app_settings.get("melotts_speaker", voices[0]) or voices[0])
            nxt = voices[(voices.index(current) + 1) % len(voices)] if current in voices else voices[0]
            app_settings.set("melotts_speaker", nxt)
        elif engine == "chattts":
            voices = ["default", "seed_1", "seed_2", "seed_3"]
            current = str(app_settings.get("chattts_voice", voices[0]) or voices[0])
            nxt = voices[(voices.index(current) + 1) % len(voices)] if current in voices else voices[0]
            app_settings.set("chattts_voice", nxt)
        elif engine == "styletts2":
            nxt = "styletts2"
        else:
            voices = ["en-US-AriaNeural", "en-US-JennyNeural", "en-US-GuyNeural", "en-GB-SoniaNeural", "en-GB-RyanNeural", "en-AU-NatashaNeural", "en-CA-ClaraNeural"]
            current = str(app_settings.get("speech_voice", voices[0]) or voices[0])
            nxt = voices[(voices.index(current) + 1) % len(voices)] if current in voices else voices[0]
            app_settings.set("speech_voice", nxt)
        self._apply_runtime_settings("shortcut_cycle", {"speech_voice", "kokoro_voice", "melotts_speaker", "chattts_voice"})
        self._set_status(f"当前声音：{engine} / {nxt}", "correct")

    def _cycle_translation_engine(self):
        values = ["auto_google_opus", "opus_local", "google_online", "api_online", "api_google_opus", "opus_google_api", "manual", "none"]
        nxt = self._cycle_setting("translation_engine", values)
        self._apply_runtime_settings("shortcut_cycle", {"translation_engine"})
        self._set_status(f"翻译引擎已切换：{nxt}", "correct")

    def _toggle_bool_setting(self, key: str) -> bool:
        nxt = not bool(app_settings.get(key, True))
        app_settings.set(key, nxt)
        return nxt

    def _toggle_chinese_runtime(self):
        nxt = self._toggle_bool_setting("show_chinese")
        if self._materials:
            m = self._materials[self._current_index]
            self.chinese_label.setText(m.chinese if (nxt and m.chinese) else ("（中文已隐藏）" if not nxt else "（无中文提示）"))
        self._apply_blind_visibility()
        self._set_status(f"中文显示：{'开启' if nxt else '关闭'}", "correct")

    def _toggle_ipa_runtime(self):
        nxt = self._toggle_bool_setting("show_word_ipa_above_line")
        self._update_sub_hints(show_all=False)
        self._set_status(f"音标显示：{'开启' if nxt else '关闭'}", "correct")

    def _toggle_subhint_runtime(self):
        nxt = self._toggle_bool_setting("show_chunk_structure_hint")
        self._update_sub_hints(show_all=False)
        self._set_status(f"下方提示：{'开启' if nxt else '关闭'}", "correct")

    def _on_mode_tab_changed(self, index: int):
        mapping = {0: "dictation", 1: "blind", 2: "choice", 3: "fill_blank"}
        feature = mapping.get(index, "dictation")
        if not self._require_feature(feature):
            self.mode_bar.blockSignals(True)
            self.mode_bar.setCurrentIndex(0)
            self.mode_bar.blockSignals(False)
            return
        mode = feature
        if str(app_settings.get("practice_mode", "dictation")) == mode:
            return
        app_settings.set("practice_mode", mode)
        app_settings.set("blind_mode_active", mode == "blind")
        if self._materials:
            self._load_current_sentence()
        else:
            self._apply_mode_visibility()
        self._set_status(f"练习模式：{mode}", "correct")

    def _toggle_blind_mode(self):
        if not self._require_feature("blind"):
            return
        active = not bool(app_settings.get("blind_mode_active", False))
        app_settings.set("blind_mode_active", active)
        app_settings.set("practice_mode", "blind" if active else "dictation")
        self._apply_blind_visibility()
        self._set_status("盲听模式已开启：只保留输入区和错误提示。" if active else "盲听模式已关闭。", "correct")

    def _cycle_practice_mode(self):
        vals = ["dictation", "blind", "choice", "fill_blank"]
        cur = str(app_settings.get("practice_mode", "dictation"))
        start = vals.index(cur) if cur in vals else 0
        nxt = vals[0]
        for step in range(1, len(vals)+1):
            cand = vals[(start + step) % len(vals)]
            if self._license_status.has(cand):
                nxt = cand; break
        if not self._require_feature(nxt):
            return
        app_settings.set("practice_mode", nxt)
        app_settings.set("blind_mode_active", nxt == "blind")
        self._load_current_sentence() if self._materials else self._apply_blind_visibility()
        self._set_status(f"练习模式：{nxt}", "correct")

    def _apply_blind_visibility(self):
        blind = bool(app_settings.get("blind_mode_active", False)) or str(app_settings.get("practice_mode", "dictation")) == "blind"
        if blind:
            self.chinese_label.setVisible(False)
            self.hint_box.setVisible(False)
            self.show_answer_btn.setVisible(False)
            for lab in self._chunk_ipa_labels + self._chunk_hint_labels:
                lab.setVisible(False)
        else:
            self.chinese_label.setVisible(True)
            self.hint_box.setVisible(True)
            self.show_answer_btn.setVisible(True)
            for lab in self._chunk_ipa_labels:
                lab.setVisible(bool(app_settings.get("show_word_ipa_above_line", True)))
            for lab in self._chunk_hint_labels:
                lab.setVisible(bool(app_settings.get("show_chunk_structure_hint", True)))

    # ---------- resource scanner ----------
    def _build_resource_dock(self):
        self.resource_dock = QDockWidget("资源库", self)
        self.resource_dock.setObjectName("resourceDock")
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(8, 8, 8, 8)
        self.resource_root_label = QLabel("未扫描资源文件夹")
        self.resource_root_label.setObjectName("resourceRootLabel")
        lay.addWidget(self.resource_root_label)
        self.resource_tree = QTreeWidget()
        self.resource_tree.setHeaderLabels(["文件夹 / 素材文件"])
        self.resource_tree.itemDoubleClicked.connect(self._on_resource_activated)
        lay.addWidget(self.resource_tree, 1)
        tip = QLabel("双击 .txt / .csv / .srt 加载为当前课程。扫描只列文件；双击加载时在后台解析，中文为空时按设置自动翻译。")
        tip.setWordWrap(True)
        tip.setObjectName("resourceTipLabel")
        lay.addWidget(tip)
        self.resource_dock.setWidget(box)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.resource_dock)
        self._apply_visibility_controls()
        root = str(app_settings.get("last_scan_root", "") or "")
        if root and Path(root).exists():
            QTimer.singleShot(200, lambda: self._start_scan(root))

    def _scan_folder(self):
        root = QFileDialog.getExistingDirectory(self, "选择资源根文件夹")
        if not root:
            return
        app_settings.set("last_scan_root", root)
        self._start_scan(root)

    def _rescan_folder(self):
        root = str(app_settings.get("last_scan_root", "") or self._resource_root or "")
        if not root or not Path(root).exists():
            self._scan_folder()
            return
        self._start_scan(root)

    def _start_scan(self, root: str):
        if self._scan_worker and self._scan_worker.isRunning():
            self._set_status("正在扫描中，请稍候……")
            return
        self._resource_root = root
        self.resource_root_label.setText(f"扫描中：{root}")
        self.resource_tree.clear()
        exts = app_settings.get("scan_supported_extensions", [".txt", ".csv", ".srt"])
        self._scan_worker = ScanWorker(root, list(exts) if isinstance(exts, list) else None)
        self._scan_worker.done.connect(self._on_scan_done)
        self._scan_worker.error.connect(lambda msg: QMessageBox.critical(self, "扫描失败", msg))
        self._scan_worker.start()
        self._set_status("正在后台扫描资源文件夹……")

    def _on_scan_done(self, root: str, result: object):
        data = result if isinstance(result, dict) else {"folders": [], "files": []}
        folders = [Path(x) for x in data.get("folders", [])]
        files = [Path(x) for x in data.get("files", [])]
        self.resource_tree.clear()
        root_path = Path(root)
        root_item = QTreeWidgetItem([root_path.name or str(root_path)])
        root_item.setData(0, Qt.UserRole, {"type": "dir", "path": str(root_path)})
        self.resource_tree.addTopLevelItem(root_item)
        node_map: dict[str, QTreeWidgetItem] = {str(root_path): root_item}

        def ensure_dir(p: Path) -> QTreeWidgetItem:
            key = str(p)
            if key in node_map:
                return node_map[key]
            parent = ensure_dir(p.parent) if p.parent != p else root_item
            item = QTreeWidgetItem([p.name])
            item.setData(0, Qt.UserRole, {"type": "dir", "path": str(p)})
            parent.addChild(item)
            node_map[key] = item
            return item

        for d in folders:
            try:
                d.relative_to(root_path)
                ensure_dir(d)
            except Exception:
                continue
        for f in files:
            try:
                f.relative_to(root_path)
            except Exception:
                continue
            parent = ensure_dir(f.parent)
            item = QTreeWidgetItem([f.name])
            item.setData(0, Qt.UserRole, {"type": "file", "path": str(f)})
            parent.addChild(item)
        root_item.setExpanded(True)
        self.resource_root_label.setText(f"资源根目录：{root_path}  ｜ 文件 {len(files)} 个，文件夹 {len(folders)} 个")
        if app_settings.get("auto_show_resource_library_after_scan", True):
            self.resource_dock.show()
            app_settings.set("show_resource_library", True)
        self._set_status(f"扫描完成：发现 {len(files)} 个素材文件。双击文件加载。")

    def _on_resource_activated(self, item, column: int):
        data = item.data(0, Qt.UserRole) or {}
        if isinstance(data, dict) and data.get("type") == "file":
            self._load_resource_file(str(data.get("path", "")))

    def _load_resource_file(self, path: str):
        if not path:
            return
        p = Path(path)
        if not p.exists():
            QMessageBox.warning(self, "加载失败", f"文件不存在：{path}")
            return
        if self._load_worker and self._load_worker.isRunning():
            self._set_status("正在加载上一个文件，请稍候……")
            return
        self._set_status(f"正在后台加载：{p.name}（只解析本地文本，不联网翻译，避免卡死）")
        self._load_worker = FileLoadWorker(str(p))
        self._load_worker.done.connect(self._on_resource_loaded)
        self._load_worker.error.connect(self._show_load_error)
        self._load_worker.start()

    def _show_load_error(self, msg: str):
        self._load_worker = None
        try:
            log_path = ROOT / "data" / "last_load_error.log"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            log_path.write_text(msg, encoding="utf-8")
        except Exception:
            pass
        QMessageBox.critical(self, "加载失败", "加载素材时发生错误。详细信息已保存到 data/last_load_error.log。\n\n" + str(msg)[:1500])

    def _on_resource_loaded(self, path: str, items: object):
        self._load_worker = None
        materials = items if isinstance(items, list) else []
        if not materials:
            QMessageBox.warning(self, "加载失败", "文件中没有找到有效英文素材。\n\n已增强兼容：UTF-8/GBK/UTF-16、双语SRT/VTT、混合中英行。若仍失败，请把该字幕前20行发我。")
            self._set_status("加载失败：没有解析到英文素材。", "wrong")
            return
        src = Path(path).name
        for m in materials:
            m.source_name = src
        n = insert_materials(materials)
        self._refresh_sources()
        idx = self.source_combo.findText(src)
        if idx >= 0:
            self.source_combo.setCurrentIndex(idx)
        # Immediate display from freshly parsed list; do not depend on combobox signal/database refresh.
        self._materials = materials
        self._wrong_mode = False
        self._current_index = 0
        app_settings.set("last_source", src)
        app_settings.set("last_index", 0)
        self._refresh_transcript_browser()
        self._refresh_intensive_table()
        self._refresh_independent_browsers()
        self._load_current_sentence()
        trans_note = "中文为空时会按设置后台补译" if app_settings.get("auto_translate_on_import", True) else "中文为空时不自动翻译"
        self._set_status(f"已加载 {n} 条：{src}（{trans_note}）")

    # ---------- transcript browser ----------
    def _open_transcript_tab(self):
        if not self._require_feature("transcript"):
            return
        """v56: open a true independent full-script browser window.

        It is intentionally not mixed with dictation/blank/choice modes, so the
        window contains only episode lines, like reading a TXT/SRT document.
        """
        if not hasattr(self, "_transcript_dialog") or self._transcript_dialog is None:
            self._transcript_dialog = FullTranscriptBrowserDialog(self)
        self._transcript_dialog.refresh()
        self._transcript_dialog.show()
        self._transcript_dialog.raise_()
        self._transcript_dialog.activateWindow()

    def _open_intensive_page(self):
        if not self._require_feature("intensive"):
            return
        """v56: open the intensive-listening popup directly."""
        if not hasattr(self, "_intensive_dialog") or self._intensive_dialog is None:
            self._intensive_dialog = IntensiveListeningDialog(self)
        self._intensive_dialog.refresh()
        self._intensive_dialog.show()
        self._intensive_dialog.raise_()
        self._intensive_dialog.activateWindow()

    def _refresh_independent_browsers(self, soft: bool = False):
        """Refresh v56 independent transcript/intensive windows if they are open."""
        try:
            dlg = getattr(self, "_transcript_dialog", None)
            if dlg is not None and dlg.isVisible():
                dlg.refresh(keep_filter=True, soft=soft)
        except Exception:
            pass
        try:
            dlg = getattr(self, "_intensive_dialog", None)
            if dlg is not None and dlg.isVisible():
                dlg.refresh(keep_filter=True, soft=soft)
        except Exception:
            pass

    def _ms_label(self, ms: int) -> str:
        try:
            ms = int(ms)
            if ms < 0:
                return ""
            total = ms // 1000
            h = total // 3600
            m = (total % 3600) // 60
            sec = total % 60
            return f"{h:02d}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"
        except Exception:
            return ""

    def _refresh_transcript_browser(self, *args):
        if not hasattr(self, "transcript_table"):
            return
        filt = ""
        try:
            filt = self.transcript_filter.text().strip().lower()
        except Exception:
            filt = ""
        self.transcript_table.blockSignals(True)
        self.transcript_table.setRowCount(0)
        visible = 0
        for idx, m in enumerate(self._materials):
            hay = f"{m.english} {m.chinese}".lower()
            if filt and filt not in hay:
                continue
            row = self.transcript_table.rowCount()
            self.transcript_table.insertRow(row)
            mark = ""
            if int(getattr(m, "start_ms", -1)) >= 0:
                mark = self._ms_label(int(m.start_ms))
                if int(getattr(m, "end_ms", -1)) > int(m.start_ms):
                    mark += " - " + self._ms_label(int(m.end_ms))
            elif getattr(m, "audio_path", ""):
                mark = "独立音频"
            for col, val in enumerate([str(idx + 1), m.english, m.chinese or "", mark]):
                item = QTableWidgetItem(val)
                item.setData(Qt.UserRole, idx)
                if col == 0:
                    item.setTextAlignment(Qt.AlignCenter)
                self.transcript_table.setItem(row, col, item)
            visible += 1
        self.transcript_table.blockSignals(False)
        if hasattr(self, "transcript_title"):
            self.transcript_title.setText(f"全文浏览：点击任意台词即可定位并播放（显示 {visible} / {len(self._materials)} 条）")
        self._sync_transcript_selection()

    def _on_transcript_item_clicked(self, item: QTableWidgetItem):
        try:
            idx = int(item.data(Qt.UserRole))
        except Exception:
            return
        if not (0 <= idx < len(self._materials)):
            return
        self._current_index = idx
        app_settings.set("last_index", idx)
        self._load_current_sentence()
        self._open_transcript_tab()
        if not hasattr(self, "transcript_click_play") or self.transcript_click_play.isChecked():
            QTimer.singleShot(80, self._play_sentence)

    def _sync_transcript_selection(self):
        if not hasattr(self, "transcript_table"):
            return
        try:
            self.transcript_table.blockSignals(True)
            for row in range(self.transcript_table.rowCount()):
                item = self.transcript_table.item(row, 0)
                if item is not None and int(item.data(Qt.UserRole)) == int(self._current_index):
                    self.transcript_table.selectRow(row)
                    self.transcript_table.scrollToItem(item, QAbstractItemView.PositionAtCenter)
                    break
        except Exception:
            pass
        finally:
            try:
                self.transcript_table.blockSignals(False)
            except Exception:
                pass

    # ---------- v55 standalone intensive listening page ----------
    def _refresh_intensive_table(self, *args):
        if not hasattr(self, "intensive_table"):
            return
        filt = ""
        try:
            filt = self.intensive_filter.text().strip().lower()
        except Exception:
            pass
        show_en = bool(getattr(self, "intensive_show_en", None).isChecked()) if hasattr(self, "intensive_show_en") else True
        show_zh = bool(getattr(self, "intensive_show_zh", None).isChecked()) if hasattr(self, "intensive_show_zh") else True
        self.intensive_table.blockSignals(True)
        self.intensive_table.setRowCount(0)
        visible = 0
        for idx, m in enumerate(self._materials):
            hay = f"{m.english} {m.chinese}".lower()
            if filt and filt not in hay:
                continue
            mark = ""
            if int(getattr(m, "start_ms", -1)) >= 0:
                mark = self._ms_label(int(m.start_ms))
                if int(getattr(m, "end_ms", -1)) > int(m.start_ms):
                    mark += " - " + self._ms_label(int(m.end_ms))
            elif getattr(m, "audio_path", ""):
                mark = "独立音频"
            row = self.intensive_table.rowCount(); self.intensive_table.insertRow(row)
            vals = [str(idx + 1), m.english if show_en else "（原文已隐藏）", m.chinese if show_zh else "（翻译已隐藏）", mark]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val or "")
                item.setData(Qt.UserRole, idx)
                if col == 0:
                    item.setTextAlignment(Qt.AlignCenter)
                self.intensive_table.setItem(row, col, item)
            visible += 1
        self.intensive_table.blockSignals(False)
        if hasattr(self, "intensive_title"):
            self.intensive_title.setText(f"单独精听播放页：显示 {visible} / {len(self._materials)} 条｜←/→ 上一句/下一句｜次数/速度/定时独立保存")
        self._sync_intensive_selection()

    def _refresh_intensive_visibility(self, *args):
        if hasattr(self, "intensive_show_en"):
            app_settings.set("intensive_show_english", self.intensive_show_en.isChecked())
        if hasattr(self, "intensive_show_zh"):
            app_settings.set("intensive_show_chinese", self.intensive_show_zh.isChecked())
        self._update_intensive_current_labels()
        self._refresh_intensive_table()

    def _update_intensive_current_labels(self):
        if not hasattr(self, "intensive_english_label"):
            return
        if not self._materials:
            self.intensive_english_label.setText("（暂无原文）")
            self.intensive_chinese_label.setText("（暂无翻译）")
            return
        m = self._materials[self._current_index]
        show_en = self.intensive_show_en.isChecked() if hasattr(self, "intensive_show_en") else True
        show_zh = self.intensive_show_zh.isChecked() if hasattr(self, "intensive_show_zh") else True
        self.intensive_english_label.setText(m.english if show_en else "（原文已隐藏：用于盲听/精听）")
        self.intensive_chinese_label.setText((m.chinese or "（无中文翻译）") if show_zh else "（翻译已隐藏）")

    def _sync_intensive_selection(self):
        if not hasattr(self, "intensive_table"):
            return
        try:
            self.intensive_table.blockSignals(True)
            for row in range(self.intensive_table.rowCount()):
                item = self.intensive_table.item(row, 0)
                if item is not None and int(item.data(Qt.UserRole)) == int(self._current_index):
                    self.intensive_table.selectRow(row)
                    self.intensive_table.scrollToItem(item, QAbstractItemView.PositionAtCenter)
                    break
        except Exception:
            pass
        finally:
            try:
                self.intensive_table.blockSignals(False)
            except Exception:
                pass

    def _on_intensive_item_clicked(self, item: QTableWidgetItem):
        try:
            idx = int(item.data(Qt.UserRole))
        except Exception:
            return
        if 0 <= idx < len(self._materials):
            self._current_index = idx
            app_settings.set("last_index", idx)
            self._load_current_sentence()
            self._intensive_play_current()

    def _intensive_play_current(self):
        if not self._materials:
            return
        if hasattr(self, "workspace_tabs") and hasattr(self, "intensive_panel"):
            self.workspace_tabs.setCurrentWidget(self.intensive_panel)
        self._intensive_repeat_left = max(1, int(self.intensive_times.value() if hasattr(self, "intensive_times") else app_settings.get("play_times", 1)))
        self._intensive_play_once()

    def _intensive_play_once(self):
        if not self._materials:
            return
        self._intensive_auto_timer.stop()
        m = self._materials[self._current_index]
        speed = float(self.intensive_speed.value() if hasattr(self, "intensive_speed") else app_settings.get("play_speed", 1.0))
        self._intensive_repeat_left = max(0, int(getattr(self, "_intensive_repeat_left", 1)) - 1)
        if m.media_path and int(m.start_ms) >= 0 and Path(m.media_path).exists():
            self._video_audio.setVolume(float(app_settings.get("speech_volume", 1.0)))
            self._video_player.setPlaybackRate(speed)
            self._video_segment_timer.stop()
            try:
                if self._video_player.source().toLocalFile() != str(Path(m.media_path).resolve()):
                    self._video_player.stop()
                    self._video_player.setSource(QUrl.fromLocalFile(str(Path(m.media_path).resolve())))
            except Exception:
                self._video_player.setSource(QUrl.fromLocalFile(str(Path(m.media_path).resolve())))
            def seek_and_play():
                try:
                    self._video_player.setPosition(max(0, int(m.start_ms)))
                    self._video_player.play()
                    end_ms = int(m.end_ms)
                    if end_ms > int(m.start_ms):
                        dur = int((end_ms - int(m.start_ms)) / max(0.1, speed)) + 180
                        self._video_segment_timer.start(max(220, dur))
                except Exception:
                    self._video_player.play()
            QTimer.singleShot(90, seek_and_play)
            self._set_status("精听播放：本地视频/音频片段", "correct")
        else:
            # No bound media: use the same speech engine as dictation, but keep v55 page controls.
            old_speed = app_settings.get("play_speed", 1.0)
            try:
                app_settings.set("play_speed", speed)
                self._speech.play_text(m.english, m.audio_path)
                self._set_status("精听播放：未绑定本地视频，已使用发音引擎播放当前句", "normal")
            finally:
                app_settings.set("play_speed", old_speed)

    def _on_intensive_segment_finished(self):
        try:
            self._video_player.pause()
        except Exception:
            pass
        if int(getattr(self, "_intensive_repeat_left", 0)) > 0:
            self._intensive_play_once()
            return
        if hasattr(self, "intensive_timed") and self.intensive_timed.isChecked():
            delay = int(max(0.0, float(self.intensive_interval.value())) * 1000)
            self._intensive_auto_timer.start(delay)

    def _intensive_next_and_play(self):
        if not self._materials:
            return
        if self._current_index < len(self._materials) - 1:
            self._current_index += 1
        elif app_settings.get("play_loop_mode") == "list":
            self._current_index = 0
        else:
            self._set_status("定时连播结束：已经是最后一句", "correct")
            return
        self._load_current_sentence()
        self._intensive_play_current()

    def _intensive_prev(self):
        self._intensive_stop_all(keep_video=True)
        self._prev_sentence()
        self._sync_intensive_selection()

    def _intensive_next(self):
        self._intensive_stop_all(keep_video=True)
        self._next_sentence()
        self._sync_intensive_selection()

    def _intensive_toggle_pause(self):
        try:
            state = self._video_player.playbackState()
            if state == QMediaPlayer.PlaybackState.PlayingState:
                self._video_player.pause(); self._video_segment_timer.stop()
            else:
                self._video_player.play()
        except Exception:
            pass

    def _intensive_stop_all(self, keep_video: bool = False):
        self._intensive_auto_timer.stop(); self._video_segment_timer.stop(); self._intensive_repeat_left = 0
        try:
            self._video_player.pause() if keep_video else self._video_player.stop()
        except Exception:
            pass
        try:
            self._speech.player.stop()
        except Exception:
            pass

    def _float_video_window(self):
        if self._floating_video_dialog is None:
            self._floating_video_dialog = FloatingVideoDialog(self)
        self._video_player.setVideoOutput(self._floating_video_dialog.video)
        self._floating_video_dialog.show()
        self._floating_video_dialog.raise_()
        self._floating_video_dialog.activateWindow()

    def _dock_video_to_intensive_page(self):
        try:
            self._video_player.setVideoOutput(self.intensive_video_widget)
            if self._floating_video_dialog is not None:
                self._floating_video_dialog.hide()
        except Exception:
            pass

    def _fullscreen_video_window(self):
        self._float_video_window()
        if self._floating_video_dialog is not None:
            self._floating_video_dialog.showFullScreen()

    # ---------- data ----------
    def _refresh_sources(self):
        self.source_combo.blockSignals(True); self.source_combo.clear(); self.source_combo.addItems(get_source_names()); self.source_combo.blockSignals(False)

    def _load_initial(self):
        sources = get_source_names()
        if not sources:
            self._clear_display(); return
        last = str(app_settings.get("last_source", ""))
        src = last if last in sources else sources[0]
        self.source_combo.setCurrentText(src); self._load_source(src)

    def _on_source_changed(self, source: str):
        if source: self._load_source(source)

    def _load_source(self, source: str):
        self._wrong_mode = False; self._materials = get_all_materials(source); self._current_index = min(int(app_settings.get("last_index", 0)), max(0, len(self._materials)-1)); app_settings.set("last_source", source); self._refresh_transcript_browser(); self._refresh_intensive_table(); self._refresh_independent_browsers(); self._load_current_sentence()

    def _clear_display(self):
        self.progress_label.setText("第 0 / 0 句"); self.chinese_label.setText("请导入素材（Ctrl+O）"); self._clear_dictation(); self.hint_word.setText(""); self.hint_text.setText(""); self._update_intensive_current_labels()

    def _load_current_sentence(self):
        if not self._materials:
            self._clear_display(); self._refresh_transcript_browser(); return
        self._current_index = max(0, min(self._current_index, len(self._materials)-1)); app_settings.set("last_index", self._current_index)
        if hasattr(self, "transcript_table") and self.transcript_table.rowCount() != len(self._materials) and not getattr(self, "_refreshing_transcript", False):
            self._refreshing_transcript = True
            try:
                self._refresh_transcript_browser()
            finally:
                self._refreshing_transcript = False
        self._submitted = False
        if app_settings.get("six_step_auto_reset_on_sentence", True):
            self._six_step = 0
        m = self._materials[self._current_index]
        prefix = "错题" if self._wrong_mode else "第"
        self.progress_label.setText(f"{prefix} {self._current_index+1} / {len(self._materials)} 句")
        self.chinese_label.setText(m.chinese if (app_settings.get("show_chinese", True) and m.chinese) else "（无中文提示）")
        self._maybe_translate_current_sentence()
        self._chunks = segment_chunks(m.english, str(app_settings.get("chunk_mode", "smart")), int(app_settings.get("max_words_per_chunk", 3)))
        self._build_chunks()
        self._build_choice_panel()
        self._build_fill_panel()
        self._apply_mode_visibility()
        if self._chunk_inputs:
            self._chunk_inputs[0].setFocus(); self._update_hint_for_chunk(self._chunk_inputs[0])
            if app_settings.get("six_step_default_visible", False) and str(app_settings.get("practice_mode", "dictation")) != "blind":
                self._six_step = 0
                QTimer.singleShot(80, self._six_step_hint)
        self._sync_transcript_selection()
        self._update_intensive_current_labels()
        self._sync_intensive_selection()
        self._refresh_independent_browsers(soft=True)
        self._set_status("")
        if app_settings.get("auto_play_sentence_on_load", False):
            QTimer.singleShot(180, self._play_sentence)

    def _maybe_translate_current_sentence(self):
        if not self._materials:
            return
        m = self._materials[self._current_index]
        if m.chinese or not app_settings.get("show_chinese", True):
            return
        if not (bool(app_settings.get("auto_translate_on_import", True)) or bool(app_settings.get("background_translate_missing_chinese", True))):
            self.chinese_label.setText("（无中文提示）")
            return
        engine = str(app_settings.get("translation_engine", "auto_google_opus"))
        if engine in {"manual", "none"}:
            self.chinese_label.setText("（无中文提示）")
            return
        if self._translation_worker and self._translation_worker.isRunning():
            return
        self.chinese_label.setText("（正在后台翻译中文……）")
        idx = self._current_index
        self._translation_worker = TranslationWorker(idx, m.english)
        self._translation_worker.done.connect(self._on_translation_done)
        self._translation_worker.error.connect(lambda msg: self._set_status("翻译失败：" + str(msg)[:120], "wrong"))
        self._translation_worker.start()

    def _on_translation_done(self, index: int, zh: str, english: str):
        if not zh:
            if self._materials and index == self._current_index and not self._materials[index].chinese:
                self.chinese_label.setText("（无中文提示）")
            return
        if 0 <= index < len(self._materials) and self._materials[index].english == english:
            self._materials[index].chinese = zh
            try:
                update_material_chinese(self._materials[index].id, zh)
            except Exception:
                pass
            if index == self._current_index and app_settings.get("show_chinese", True):
                self.chinese_label.setText(zh)

    def _clear_dictation(self):
        while self.dictation_layout.count():
            item = self.dictation_layout.takeAt(0)
            w = item.widget()
            if w: w.deleteLater()
            lay = item.layout()
            if lay:
                while lay.count():
                    sub = lay.takeAt(0); sw = sub.widget();
                    if sw: sw.deleteLater()
        self._chunk_inputs.clear(); self._chunk_ipa_labels.clear(); self._chunk_hint_labels.clear(); self._chunk_info_cache.clear()

    def _build_chunks(self):
        self._clear_dictation()
        max_chars = int(app_settings.get("max_chars_per_line", 54))
        cur_len = 0
        row = None
        font = QFont("Consolas", 18)
        metrics = QFontMetrics(font)
        # 语块之间保持约 2-3 个字符距离，按当前字体计算，不再使用过大的固定间隔。
        gap = int(app_settings.get("chunk_gap", max(22, metrics.horizontalAdvance("MMM"))) or max(22, metrics.horizontalAdvance("MMM")))
        min_width = int(app_settings.get("chunk_min_width", 36) or 36)
        for c in self._chunks:
            punct = str(c.trailing_punct or "")
            need = len(c.text) + len(punct) + 2
            if row is None or cur_len + need > max_chars:
                if row is not None:
                    row.addStretch(1)
                row_widget = QWidget(); row_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                row_layout = QHBoxLayout(row_widget); row_layout.setContentsMargins(0, 0, 0, 0); row_layout.setSpacing(gap)
                row_layout.addStretch(1)
                self.dictation_layout.addWidget(row_widget); row = row_layout; cur_len = 0
            block = QWidget(); block.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            b = QVBoxLayout(block); b.setContentsMargins(0, 0, 0, 0); b.setSpacing(7)
            # 横线长度严格按实际字体测量：一个字母占多少像素，横线就跟随多少像素。
            width = max(min_width, min(360, metrics.horizontalAdvance(c.text) + 18))
            block.setFixedWidth(width)
            ipa = QLabel(""); ipa.setObjectName("chunkIpaHint"); ipa.setAlignment(Qt.AlignCenter); ipa.setFixedWidth(width); ipa.setFixedHeight(24); b.addWidget(ipa)
            inp = ChunkInput(c); inp.setFont(font); inp.setFixedWidth(width); inp.textChanged.connect(self._on_chunk_changed); inp.returnPressed.connect(self._on_enter); b.addWidget(inp)
            sub = QLabel(""); sub.setObjectName("chunkSubHint"); sub.setAlignment(Qt.AlignCenter); sub.setFixedWidth(width); sub.setWordWrap(True); sub.setMinimumHeight(38); sub.setMaximumHeight(52); b.addWidget(sub)
            self._chunk_ipa_labels.append(ipa); self._chunk_inputs.append(inp); self._chunk_hint_labels.append(sub); row.addWidget(block, 0, Qt.AlignTop)
            if punct:
                lab = QLabel(punct); lab.setObjectName("punctLabel"); row.addWidget(lab, 0, Qt.AlignVCenter)
            cur_len += need
        if row is not None:
            row.addStretch(1)
        self.dictation_layout.addStretch()
        # Preload word info once per sentence. This removes repeated Kaikki JSONL
        # lookups while typing / switching tabs.
        try:
            for inp in self._chunk_inputs:
                self._chunk_info_cache[id(inp)] = get_chunk_infos(inp.chunk.words)
        except Exception:
            self._chunk_info_cache.clear()
        self._update_sub_hints(show_all=False)

    # ---------- choice mode ----------
    def _clear_choice_buttons(self):
        while self.choice_words_layout.count():
            item = self.choice_words_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self._choice_buttons.clear()

    def _sentence_words(self) -> list[str]:
        words: list[str] = []
        for c in self._chunks:
            words.extend([w for w in c.words if str(w).strip()])
        return words

    def _build_choice_panel(self):
        self._choice_selected = []
        self._choice_expected_words = self._sentence_words()
        self._clear_choice_buttons()
        if not self._choice_expected_words:
            self.choice_status.setText("选词模式：当前句没有可用英文单词。")
            self.choice_answer.setText("")
            if hasattr(self, "choice_slots"):
                self.choice_slots.setText("")
            return
        self._update_choice_slots()
        pool = list(self._choice_expected_words)
        if bool(app_settings.get("choice_add_distractors", False)):
            distractors = ["the", "a", "to", "in", "on", "for", "with", "that", "this", "you", "me", "go", "get", "make", "take", "very", "really", "just", "not", "now"]
            for x in distractors:
                if x.lower() not in [w.lower() for w in pool]:
                    pool.append(x)
                    if len(pool) >= len(self._choice_expected_words) + int(app_settings.get("choice_distractor_count", 8)):
                        break
        random.shuffle(pool)
        cols = 5
        for i, word in enumerate(pool):
            btn = QPushButton(word)
            btn.setObjectName("choiceWordButton")
            btn.clicked.connect(lambda _=False, b=btn, w=word: self._choice_word_clicked(b, w))
            self._choice_buttons.append(btn)
            self.choice_words_layout.addWidget(btn, i // cols, i % cols)
        self.choice_status.setText("选词模式：按正确顺序点击单词。选错会加入错题集。")
        self.choice_answer.setText("")
        self._update_choice_slots()

    def _update_choice_slots(self):
        parts = []
        for i, w in enumerate(self._choice_expected_words):
            if i < len(self._choice_selected):
                parts.append(f"<span style='color:#16a34a;font-weight:900'>{html.escape(self._choice_selected[i])}</span>")
            else:
                parts.append("<span style='border-bottom:2px solid #64748b;color:#64748b'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>")
        if hasattr(self, "choice_slots"):
            self.choice_slots.setText("&nbsp;&nbsp;".join(parts))

    def _reset_choice_mode(self):
        self._build_choice_panel()
        self._set_status("选词已重置。")

    def _choice_word_clicked(self, btn: QPushButton, word: str):
        pos = len(self._choice_selected)
        expected = self._choice_expected_words[pos] if pos < len(self._choice_expected_words) else ""
        if normalize_word(word, True, True) != normalize_word(expected, True, True):
            btn.setProperty("state", "wrong"); btn.style().unpolish(btn); btn.style().polish(btn)
            self._set_status(f"选错词：当前应该选择第 {pos+1} 个词。", "wrong")
            self._sound.play("sound_wrong")
            try:
                m = self._materials[self._current_index]
                add_wrong_item(m.id, m.english, m.chinese, "choice_wrong:" + word)
            except Exception:
                pass
            return
        self._choice_selected.append(word)
        btn.setEnabled(False); btn.setProperty("state", "correct"); btn.style().unpolish(btn); btn.style().polish(btn)
        self.choice_answer.setText("已选：" + " ".join(self._choice_selected))
        self._update_choice_slots()
        self._sound.play("sound_correct")
        if len(self._choice_selected) >= len(self._choice_expected_words):
            self._submitted = True
            self._set_status("✓ 选词全部正确", "correct")
            self._show_correct_hints()
            self.workspace_tabs.setCurrentIndex(0)

    # ---------- fill-blank mode ----------
    def _clear_fill_buttons(self):
        while self.fill_words_layout.count():
            item = self.fill_words_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self._fill_buttons.clear()

    def _choose_fill_blank_indexes(self, words: list[str]) -> list[int]:
        if not words:
            return []
        count = max(1, min(len(words), int(app_settings.get("fill_blank_count", 2) or 2)))
        # 优先挖掉信息量较大的词，短功能词少挖。
        stop = {"a", "an", "the", "to", "of", "in", "on", "at", "for", "and", "or", "but", "is", "are", "am", "was", "were"}
        candidates = [i for i, w in enumerate(words) if normalize_word(w, True, True) not in stop and len(w) > 2]
        if len(candidates) < count:
            candidates = list(range(len(words)))
        return sorted(candidates[:count])

    def _render_fill_sentence(self):
        parts = []
        selected_map = {idx: self._fill_selected[pos] for pos, idx in enumerate(self._fill_blank_indexes[:len(self._fill_selected)])}
        for i, w in enumerate(self._fill_words):
            if i in self._fill_blank_indexes:
                if i in selected_map:
                    parts.append(f"<span style='color:#16a34a;font-weight:800;border-bottom:2px solid #16a34a'>{self._esc(selected_map[i])}</span>")
                else:
                    underline = "_" * max(3, len(w))
                    parts.append(f"<span style='color:#64748b;border-bottom:2px solid #64748b'>{underline}</span>")
            else:
                parts.append(self._esc(w))
        self.fill_sentence.setText(" ".join(parts))

    def _build_fill_panel(self):
        self._fill_words = self._sentence_words()
        self._fill_blank_indexes = self._choose_fill_blank_indexes(self._fill_words)
        self._fill_selected = []
        self._clear_fill_buttons()
        if not self._fill_words:
            self.fill_status.setText("填空模式：当前句没有可用英文单词。")
            self.fill_sentence.setText("")
            return
        blank_words = [self._fill_words[i] for i in self._fill_blank_indexes]
        pool = list(blank_words)
        if bool(app_settings.get("fill_add_distractors", app_settings.get("choice_add_distractors", False))):
            distractors = ["the", "a", "to", "in", "on", "for", "with", "that", "this", "you", "me", "go", "get", "make", "take", "very", "really", "just", "not", "now"]
            for x in distractors:
                if x.lower() not in [w.lower() for w in pool]:
                    pool.append(x)
                    if len(pool) >= len(blank_words) + int(app_settings.get("fill_distractor_count", 6)):
                        break
        random.shuffle(pool)
        cols = 5
        for i, word in enumerate(pool):
            btn = QPushButton(word)
            btn.setObjectName("fillWordButton")
            btn.clicked.connect(lambda _=False, b=btn, w=word: self._fill_word_clicked(b, w))
            self._fill_buttons.append(btn)
            self.fill_words_layout.addWidget(btn, i // cols, i % cols)
        self.fill_status.setText("填空模式：点击正确单词填入空格。选错会加入错题集。")
        self._render_fill_sentence()

    def _reset_fill_mode(self):
        self._build_fill_panel()
        self._set_status("填空已重置。")

    def _fill_word_clicked(self, btn: QPushButton, word: str):
        pos = len(self._fill_selected)
        if pos >= len(self._fill_blank_indexes):
            return
        expected = self._fill_words[self._fill_blank_indexes[pos]]
        if normalize_word(word, True, True) != normalize_word(expected, True, True):
            btn.setProperty("state", "wrong"); btn.style().unpolish(btn); btn.style().polish(btn)
            self._set_status(f"填空错误：第 {pos+1} 个空应选择另一个词。", "wrong")
            self._sound.play("sound_wrong")
            try:
                m = self._materials[self._current_index]
                add_wrong_item(m.id, m.english, m.chinese, "fill_wrong:" + word)
            except Exception:
                pass
            return
        self._fill_selected.append(word)
        btn.setEnabled(False); btn.setProperty("state", "correct"); btn.style().unpolish(btn); btn.style().polish(btn)
        self._render_fill_sentence()
        self._sound.play("sound_correct")
        if len(self._fill_selected) >= len(self._fill_blank_indexes):
            self._submitted = True
            self._set_status("✓ 填空全部正确", "correct")
            self._show_correct_hints()
            self.workspace_tabs.setCurrentWidget(self.hint_box)

    def _apply_mode_visibility(self):
        mode = str(app_settings.get("practice_mode", "dictation") or "dictation")
        blind = bool(app_settings.get("blind_mode_active", False)) or mode == "blind"
        choice = mode == "choice"
        fill = mode == "fill_blank"
        if hasattr(self, "mode_stack"):
            if choice:
                self.mode_stack.setCurrentWidget(self.choice_panel)
            elif fill:
                self.mode_stack.setCurrentWidget(self.fill_panel)
            else:
                self.mode_stack.setCurrentWidget(self.dictation_page)
        if hasattr(self, "mode_bar"):
            idx = 3 if fill else (2 if choice else (1 if blind else 0))
            if self.mode_bar.currentIndex() != idx:
                self.mode_bar.blockSignals(True)
                self.mode_bar.setCurrentIndex(idx)
                self.mode_bar.blockSignals(False)
        if not (choice or fill) and hasattr(self, "workspace_tabs"):
            # Keep the hint area as a secondary panel; never reuse dictation input area for new modes.
            pass
        self._apply_blind_visibility()

    # ---------- hints ----------
    def _current_chunk_input(self) -> ChunkInput | None:
        fw = self.focusWidget()
        if isinstance(fw, ChunkInput):
            return fw
        for x in self._chunk_inputs:
            if not x.correct:
                return x
        return self._chunk_inputs[-1] if self._chunk_inputs else None

    def _esc(self, text: str) -> str:
        return html.escape(str(text or ""), quote=False)

    def _ipa_text(self, info) -> str:
        """Return IPA according to Settings -> 提示信息 -> 音标显示类型.

        auto: prefer UK then US then generic; uk/us: force that accent with generic fallback;
        both: show UK and US together when they differ; none: hide IPA text.
        """
        mode = str(app_settings.get("phonetic_display_type", "auto") or "auto").lower()
        if mode == "none":
            return ""
        if not info:
            return "?"
        uk = (getattr(info, "ipa_uk", "") or "").strip().strip("/")
        us = (getattr(info, "ipa_us", "") or "").strip().strip("/")
        generic = (getattr(info, "phonetic", "") or "").strip().strip("/")
        if mode == "uk":
            return uk or generic or us or "?"
        if mode == "us":
            return us or generic or uk or "?"
        if mode == "both":
            parts = []
            if uk: parts.append(f"UK /{uk}/")
            if us and us != uk: parts.append(f"US /{us}/")
            if not parts and generic: parts.append(f"/{generic}/")
            return "  ".join(parts) if parts else "?"
        return uk or us or generic or "?"

    def _pos_text(self, info) -> str:
        return (info.pos if info and info.pos else "?")

    def _zh_text(self, info) -> str:
        return (info.zh if info and info.zh else "")

    def _def_text(self, info) -> str:
        return (info.en_def if info and info.en_def else "")

    def _word_badge_html(self, word: str, info, idx: int = 0, include_answer: bool = False) -> str:
        colors = ["#2563eb", "#16a34a", "#ea580c", "#7c3aed", "#db2777", "#0891b2", "#ca8a04"]
        c = colors[idx % len(colors)]
        ipa = self._ipa_text(info)
        pos = self._pos_text(info)
        zh = self._zh_text(info)
        wd = self._esc(word) if include_answer else f"第{idx+1}词"
        parts = [
            f"<span style='color:{c};font-weight:800'>{wd}</span>",
            f"<span style='color:#64748b'>/{self._esc(ipa).strip('/')}/</span>",
            f"<span style='color:{c}'>{self._esc(pos)}</span>",
        ]
        if zh:
            parts.append(f"<span style='color:#475569'>{self._esc(zh)}</span>")
        return " ｜ ".join(parts)

    def _step_html(self, step: int, words: list[str], infos: list[tuple[str, object]], reveal_answer: bool = False) -> str:
        palette = {
            1: ("英文释义/同音词", "#2563eb"),
            2: ("音标", "#16a34a"),
            3: ("中文", "#ea580c"),
            4: ("近反义词", "#7c3aed"),
            5: ("首尾字母", "#db2777"),
            6: ("正确答案", "#dc2626"),
        }
        title, color = palette.get(step, ("提示", "#111827"))
        rows = [f"<div style='margin-top:6px'><b style='color:{color}'>{step}. {title}</b></div>"]
        if step == 1:
            for i, (w, info) in enumerate(infos, 1):
                if info and info.en_def:
                    rows.append(f"<div>第{i}词：{self._esc(info.en_def)}</div>")
                elif info and info.homophones:
                    rows.append(f"<div>第{i}词同音提示：{self._esc(info.homophones)}</div>")
                else:
                    rows.append(f"<div>第{i}词：暂无英文释义/同音词</div>")
        elif step == 2:
            for i, (w, info) in enumerate(infos, 1):
                ipa_value = self._ipa_text(info).strip()
                if ipa_value and ipa_value != "?" and not ipa_value.startswith("UK ") and not ipa_value.startswith("US "):
                    ipa_value = f"/{ipa_value.strip('/')}/"
                rows.append(f"<div>第{i}词：{self._esc(ipa_value or '已隐藏')}</div>")
        elif step == 3:
            for i, (w, info) in enumerate(infos, 1):
                rows.append(f"<div>第{i}词：{self._esc(self._zh_text(info) or '暂无中文')}</div>")
        elif step == 4:
            for i, (w, info) in enumerate(infos, 1):
                syn = self._esc(info.synonyms if info and info.synonyms else '暂无')
                ant = self._esc(info.antonyms if info and info.antonyms else '暂无')
                rows.append(f"<div>第{i}词：近义 {syn}；反义 {ant}</div>")
        elif step == 5:
            for i, (w, info) in enumerate(infos, 1):
                rows.append(f"<div>第{i}词：{self._esc(w[:1])}...{self._esc(w[-1:])}，{len(w)}字符</div>")
        elif step == 6:
            if reveal_answer:
                rows.append(f"<div style='font-weight:800;color:{color}'>正确答案：{self._esc(' '.join(words))}</div>")
            else:
                rows.append("<div>第6步才显示完整答案。</div>")
        return "".join(rows)

    def _render_six_step_hint(self, inp: ChunkInput, up_to: int, reveal_answer: bool = False) -> None:
        words = list(inp.chunk.words or [])
        infos = self._chunk_info_cache.get(id(inp)) or get_chunk_infos(words)
        mode = str(app_settings.get("six_step_display_mode", "overlay") or "overlay")
        use_color = bool(app_settings.get("six_step_show_color", True))
        if mode == "step":
            title = f"六步提示 {up_to}/6：当前语块 {len(words)}词"
            body = self._step_html(up_to, words, infos, reveal_answer=(up_to == 6 or reveal_answer))
        else:
            title = f"六步叠加提示 1-{up_to}/6：当前语块 {len(words)}词"
            body = "".join(self._step_html(i, words, infos, reveal_answer=(i == 6 and (up_to >= 6 or reveal_answer))) for i in range(1, up_to + 1))
        if not use_color:
            # still HTML, but neutral enough; avoid stripping markup because QLabel handles it well.
            body = body.replace("#2563eb", "#111827").replace("#16a34a", "#111827").replace("#ea580c", "#111827").replace("#7c3aed", "#111827").replace("#db2777", "#111827").replace("#dc2626", "#111827")
        self.hint_word.setText(self._esc(title))
        self.hint_text.setText(body + "<div style='margin-top:6px;color:#64748b'>按 Ctrl+H 继续下一步</div>")

    def _update_hint_for_chunk(self, inp: ChunkInput | None = None, user_text: str = ""):
        inp = inp or self._current_chunk_input()
        if not inp:
            return
        words = list(inp.chunk.words or [])
        comp = chunk_component_hint(words, lookup_word) if app_settings.get("show_chunk_structure_hint", True) else ""
        if not user_text:
            self.hint_word.setText(f"当前语块：{len(words)}词")
            lines = []
            if comp:
                lines.append(self._esc(comp))
            lines.append("智能提示：输入后显示已输入内容的音标/词性；Ctrl+H 开启六步提示。")
            self.hint_text.setText("<br>".join(lines))
            return
        typed = [w for w in user_text.split() if w]
        lines = [f"<b>已输入：</b>{self._esc(user_text)}"]
        if comp:
            lines.append(self._esc(comp))
        for i, w in enumerate(typed):
            info = lookup_word(w)
            lines.append(self._word_badge_html(w, info, i, include_answer=True))
        self.hint_word.setText("智能提示")
        self.hint_text.setText("<br>".join(lines))

    def _update_sub_hints(self, show_all: bool = False):
        show_ipa = bool(app_settings.get("show_word_ipa_above_line", True))
        show_struct = bool(app_settings.get("show_chunk_structure_hint", True))
        for inp, ipa_lab, sub_lab in zip(self._chunk_inputs, self._chunk_ipa_labels, self._chunk_hint_labels):
            infos = self._chunk_info_cache.get(id(inp)) or get_chunk_infos(inp.chunk.words)
            ipa_parts = []
            pos_parts = []
            for w, info in infos:
                ipa_value = self._ipa_text(info).strip()
                if ipa_value and ipa_value != "?":
                    if ipa_value.startswith("UK ") or ipa_value.startswith("US "):
                        ipa_parts.append(ipa_value)
                    else:
                        ipa_parts.append(f"/{ipa_value.strip('/')}/")
                elif ipa_value == "?":
                    ipa_parts.append("?")
                pos_parts.append(self._pos_text(info))
            ipa_lab.setText("  ".join(ipa_parts) if show_ipa else "")
            if show_all:
                rows = []
                for i, (w, info) in enumerate(infos):
                    rows.append(self._word_badge_html(w, info, i, include_answer=True))
                sub_lab.setText("<br>".join(rows))
            elif show_struct:
                sub_lab.setText(self._esc(chunk_component_hint(inp.chunk.words, lookup_word).replace("句子成分提示：", "")))
            else:
                sub_lab.setText("")

    def _show_floating_hint_window(self, title: str, html_text: str) -> None:
        """Topmost resizable floating hint window for long full-answer panels."""
        try:
            old = getattr(self, "_floating_hint_dialog", None)
            if old is not None and old.isVisible():
                old.close()
            dlg = QDialog(self)
            dlg.setWindowTitle(title or "提示挂件")
            dlg.setWindowFlag(Qt.WindowStaysOnTopHint, True)
            dlg.setWindowFlag(Qt.Tool, True)
            dlg.resize(760, 520)
            lay = QVBoxLayout(dlg); lay.setContentsMargins(10,10,10,10); lay.setSpacing(8)
            top = QLabel("可拖动窗口 / 可滚动查看完整提示。关闭后不影响练习。")
            top.setObjectName("footerLabel"); lay.addWidget(top)
            view = QTextEdit(); view.setReadOnly(True); view.setAcceptRichText(True); view.setHtml(html_text or "")
            lay.addWidget(view, 1)
            btns = QDialogButtonBox(QDialogButtonBox.Close); btns.rejected.connect(dlg.close); lay.addWidget(btns)
            self._floating_hint_dialog = dlg
            dlg.show(); dlg.raise_(); dlg.activateWindow()
        except Exception:
            pass

    def _maybe_show_full_hint_floating(self, title: str, html_text: str) -> None:
        if str(app_settings.get("hint_full_display_mode", "inline_scroll") or "inline_scroll") == "floating":
            self._show_floating_hint_window(title, html_text)

    def _six_step_hint(self):
        inp = self._current_chunk_input()
        if not inp:
            return
        self._six_step = (self._six_step % 6) + 1
        self._render_six_step_hint(inp, self._six_step, reveal_answer=(self._six_step >= 6))

    def _show_correct_hints(self):
        if not self._materials:
            return
        lines = ["<div style='font-size:16px;font-weight:800;margin-bottom:6px'>彩色完整提示（含六步提示总览）</div>"]
        for idx, inp in enumerate(self._chunk_inputs, 1):
            infos = self._chunk_info_cache.get(id(inp)) or get_chunk_infos(inp.chunk.words)
            lines.append(f"<div style='margin-top:10px'><b style='color:#2563eb'>【语块{idx}】</b> {self._esc(inp.expected)}</div>")
            lines.append(f"<div style='color:#475569'>{self._esc(chunk_component_hint(inp.chunk.words, lookup_word))}</div>")
            for i, (w, info) in enumerate(infos):
                lines.append(f"<div style='margin-left:16px'>{self._word_badge_html(w, info, i, include_answer=True)}</div>")
            lines.append("<div style='margin:8px 0 2px 0;font-weight:800;color:#7c3aed'>六步提示总览</div>")
            for step in range(1, 7):
                lines.append(self._step_html(step, inp.chunk.words, infos, reveal_answer=True))
        self.hint_word.setText("彩色完整提示")
        full_html = "".join(lines)
        self.hint_text.setText(full_html)
        self._maybe_show_full_hint_floating("彩色完整提示", full_html)
        self._update_sub_hints(show_all=False)

    # ---------- input ----------
    def _diagnose_chunk_error(self, inp: ChunkInput, user_text: str) -> str:
        """Diagnose the first wrong word inside a multi-word chunk without exposing the full answer."""
        expected_words = list(inp.chunk.words or [])
        user_words = [w for w in str(user_text or "").strip().split() if w]
        ignore_case = bool(app_settings.get("ignore_case", True))
        ignore_punct = bool(app_settings.get("ignore_punctuation", True))
        if not user_words:
            return "当前语块未输入。"
        if len(user_words) < len(expected_words):
            # Find the first typed mismatch, otherwise just tell them phrase is incomplete.
            for i, got in enumerate(user_words):
                exp = expected_words[i] if i < len(expected_words) else ""
                if normalize_word(got, ignore_case, ignore_punct) != normalize_word(exp, ignore_case, ignore_punct):
                    return f"第 {i+1} 个词有误：" + diagnose_word_error(exp, got, lookup_word(exp), lookup_word(got))
            return f"当前语块还没输完：已输入 {len(user_words)} / {len(expected_words)} 个词。"
        if len(user_words) > len(expected_words):
            return f"当前语块多输入了 {len(user_words)-len(expected_words)} 个词，请删除多余内容。"
        for i, (exp, got) in enumerate(zip(expected_words, user_words), 1):
            if normalize_word(got, ignore_case, ignore_punct) != normalize_word(exp, ignore_case, ignore_punct):
                return f"第 {i} 个词有误：" + diagnose_word_error(exp, got, lookup_word(exp), lookup_word(got))
        return "当前语块顺序或空格可能有误，请检查。"

    def _sanitize_chunk_text(self, inp: ChunkInput, text: str) -> str:
        """Keep spaces legal while still allowing a single in-progress trailing space
        between words. Rules: no leading spaces, no multiple spaces, no trailing
        space after the final expected word.
        """
        s = str(text or "").replace("\t", " ").replace("\n", " ")
        s = re.sub(r" {2,}", " ", s).lstrip()
        expected_n = len([w for w in inp.expected.split() if w])
        if expected_n <= 1:
            return s.strip()
        typed = [w for w in s.strip().split(" ") if w]
        if len(typed) >= expected_n:
            return s.rstrip()
        return s

    def _on_chunk_changed(self, text: str):
        inp = self.sender()
        if not isinstance(inp, ChunkInput) or self._submitted: return
        fixed = self._sanitize_chunk_text(inp, text)
        if fixed != text:
            pos = max(0, min(inp.cursorPosition(), len(fixed)))
            inp.blockSignals(True)
            inp.setText(fixed)
            inp.setCursorPosition(pos)
            inp.blockSignals(False)
            text = fixed
        self._sound.play("sound_key")
        user = text.strip(); exp = inp.expected
        if not user:
            inp.checked = False; inp.correct = False; inp.set_state("focus"); self._update_hint_for_chunk(inp); return
        nu = normalize_word(user, bool(app_settings.get("ignore_case", True)), bool(app_settings.get("ignore_punctuation", True)))
        ne = normalize_word(exp, bool(app_settings.get("ignore_case", True)), bool(app_settings.get("ignore_punctuation", True)))
        if nu == ne:
            inp.mark_correct(); self._sound.play("sound_correct"); self._update_hint_for_chunk(inp, user); return
        if ne.startswith(nu):
            inp.checked = False; inp.correct = False; inp.set_state("prefix"); self._update_hint_for_chunk(inp, user); return
        inp.checked = True; inp.correct = False; inp.set_state("wrong"); self._sound.play("sound_wrong")
        diag = self._diagnose_chunk_error(inp, user)
        self._update_hint_for_chunk(inp, user); self._set_status(diag, "wrong")

    def handle_space_on_chunk(self, inp: ChunkInput):
        if app_settings.get("require_input_before_space_jump", True) and not inp.text().strip():
            self._set_status("当前横线为空，不能跳过。", "wrong"); self._sound.play("sound_wrong"); return
        self._focus_next(inp)

    def _focus_next(self, current: ChunkInput):
        try: i = self._chunk_inputs.index(current)
        except ValueError: return
        if i + 1 < len(self._chunk_inputs):
            self._chunk_inputs[i+1].setFocus(); self._update_hint_for_chunk(self._chunk_inputs[i+1]); self._auto_play_focus_chunk(self._chunk_inputs[i+1]); return
        self._submit_sentence()

    def _on_enter(self):
        if self._submitted: self._next_sentence()
        else: self._submit_sentence()

    def _submit_sentence(self):
        if not self._materials: return
        m = self._materials[self._current_index]
        wrong_first = None; all_ok = True
        answers=[]
        for inp in self._chunk_inputs:
            answers.append(inp.text().strip())
            ok = normalize_word(inp.text(), bool(app_settings.get("ignore_case", True)), bool(app_settings.get("ignore_punctuation", True))) == normalize_word(inp.expected, bool(app_settings.get("ignore_case", True)), bool(app_settings.get("ignore_punctuation", True)))
            if ok: inp.mark_correct()
            else:
                inp.mark_wrong(); all_ok = False
                if wrong_first is None: wrong_first = inp
        if all_ok:
            self._submitted = True; update_material_stats(m.id, True); self._set_status("✓ 全部正确", "correct"); self._sound.play("sound_complete")
            if app_settings.get("show_colored_hints_after_correct", True): self._show_correct_hints()
            if app_settings.get("auto_show_six_step_after_correct", False): self._six_step_hint()
            if app_settings.get("auto_next", False): QTimer.singleShot(800, self._next_sentence)
        else:
            update_material_stats(m.id, False); add_wrong_item(m.id, m.english, m.chinese, " | ".join(answers)); self._set_status("✗ 有错误：已回到第一处错误，请修改后再提交。", "wrong"); self._sound.play("sound_wrong")
            if wrong_first: wrong_first.setFocus(); self._update_hint_for_chunk(wrong_first, wrong_first.text())

    # ---------- playback ----------
    def _play_text_times(self, text: str, audio_path: str = ""):
        times = max(1, int(app_settings.get("play_times", 1)))
        self._pending_play = {"kind": "text", "text": text, "audio": audio_path, "left": times}
        self._play_next_pending()

    def _play_material_times(self, m: Material):
        times = max(1, int(app_settings.get("play_times", 1)))
        engine = str(app_settings.get("speech_engine", "edge_tts") or "edge_tts")
        local_mode = str(app_settings.get("local_media_mode", "cached_segment") or "cached_segment")
        # local_audio means: prefer the subtitle's local media segment when it exists.
        # This avoids the old bug where selecting local_audio still fell through to
        # play_text() and showed “当前句未绑定本地音频”.
        use_segment = (engine == "local_audio" or bool(app_settings.get("prefer_local_media_audio", True)))
        if use_segment and local_mode != "off" and m.media_path and int(m.start_ms) >= 0:
            self._pending_play = {"kind": "segment", "media": m.media_path, "start": int(m.start_ms), "end": int(m.end_ms), "left": times}
        else:
            self._pending_play = {"kind": "text", "text": m.english, "audio": m.audio_path, "left": times}
        self._play_next_pending()

    def _play_next_pending(self):
        pending = getattr(self, "_pending_play", None)
        if not pending:
            return
        left = int(pending.get("left", 0))
        if left <= 0:
            return
        pending["left"] = left - 1
        kind = pending.get("kind")
        if kind == "segment":
            start = int(pending.get("start", -1)); end = int(pending.get("end", -1))
            ok = self._speech.play_media_segment(str(pending.get("media", "")), start, end)
            if not ok:
                self._set_status("本地媒体片段播放失败，改用所选发音引擎。", "wrong")
                self._speech.play_text(self._materials[self._current_index].english, "")
        else:
            self._speech.play_text(str(pending.get("text", "")), str(pending.get("audio", "")))

    def _play_sentence(self):
        if not self._materials: return
        self._play_material_times(self._materials[self._current_index])

    def _play_current_chunk(self):
        inp = self._current_chunk_input()
        if inp: self._play_text_times(inp.expected, "")

    def _auto_play_focus_chunk(self, inp: ChunkInput):
        mode = str(app_settings.get("auto_play_on_chunk_focus", "off"))
        if mode == "chunk": self._play_text_times(inp.expected, "")
        elif mode == "word" and inp.chunk.words: self._play_text_times(inp.chunk.words[0], "")

    def _on_speech_ready(self, path: str):
        self._speech.play_audio(path)

    def _on_media_status_changed(self, status):
        try:
            name = getattr(status, "name", "") or str(status)
            if "EndOfMedia" in name or status == getattr(QMediaPlayer.MediaStatus, "EndOfMedia", object()):
                self._maybe_continue_play()
        except Exception:
            pass

    def _maybe_continue_play(self):
        if getattr(self, "_pending_play", None) and int(self._pending_play.get("left", 0)) > 0:
            self._play_next_pending()
    def _on_speech_error(self, msg: str): self._set_status(msg, "wrong")
    def _on_speech_generating(self): self._set_status("正在准备发音/本地音频片段……")

    # ---------- actions ----------
    def _show_answer(self):
        if not self._materials: return
        for inp in self._chunk_inputs:
            inp.setText(inp.expected); inp.mark_correct()
        self._set_status(f"答案：{self._materials[self._current_index].english}")

    def _copy_sentence(self):
        if not self._materials:
            self._set_status("当前没有可复制的台词。", "wrong"); return
        text = self._materials[self._current_index].english
        QGuiApplication.clipboard().setText(text)
        self._set_status("已复制整句台词：" + (text[:80] + ("..." if len(text) > 80 else "")), "correct")

    def _toggle_favorite(self):
        if not self._materials: return
        m = self._materials[self._current_index]; m.favorite = not m.favorite; toggle_favorite(m.id, m.favorite); self._set_status("★ 已收藏" if m.favorite else "☆ 已取消收藏")
    def _toggle_fullscreen(self): self.showNormal() if self.isFullScreen() else self.showFullScreen()
    def _exit_fullscreen(self):
        if self.isFullScreen(): self.showNormal()
    def _toggle_resource_library(self):
        visible = not self.resource_dock.isVisible()
        self.resource_dock.setVisible(visible)
        app_settings.set("show_resource_library", visible)
        self._set_status("资源库已显示" if visible else "资源库已隐藏")
    def _apply_visibility_controls(self):
        if hasattr(self, "resource_dock"):
            self.resource_dock.setVisible(bool(app_settings.get("show_resource_library", True)))
    def _prev_sentence(self):
        if self._materials and self._current_index > 0: self._current_index -= 1; self._load_current_sentence()
        else: self._set_status("已经是第一句")
    def _next_sentence(self):
        if not self._materials: return
        if self._current_index < len(self._materials)-1: self._current_index += 1; self._load_current_sentence()
        else:
            if app_settings.get("play_loop_mode") == "list": self._current_index = 0; self._load_current_sentence()
            else: self._set_status("已经是最后一句")
    def _set_status(self, text: str, state: str = "normal"):
        self.status_label.setText(text); self.status_label.setProperty("state", state); self.status_label.style().unpolish(self.status_label); self.status_label.style().polish(self.status_label)

    def _import_material(self):
        path, _ = QFileDialog.getOpenFileName(self, "打开单个素材文件", "", "素材文件 (*.txt *.csv *.srt);;Text (*.txt);;CSV (*.csv);;SRT (*.srt)")
        if not path:
            return
        self._load_resource_file(path)

    def _practice_wrong_items(self):
        items = get_wrong_items()
        if not items: QMessageBox.information(self, "错题本", "错题本为空。") ; return
        self._materials = [Material(id=x.material_id, source_name="错题本", english=x.english, chinese=x.chinese, wrong_count=x.wrong_count) for x in items]
        self._wrong_mode = True; self._current_index = 0; self._load_current_sentence()
    def _practice_all(self): self._wrong_mode = False; self._load_source(self.source_combo.currentText())
    def _export_wrong_csv(self):
        items = get_wrong_items()
        if not items: QMessageBox.information(self, "导出", "错题本为空。") ; return
        path, _ = QFileDialog.getSaveFileName(self, "导出错题", "wrong_items.csv", "CSV (*.csv)")
        if not path: return
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w=csv.writer(f); w.writerow(["english","chinese","user_answer","wrong_count","last_wrong_at"])
            for x in items: w.writerow([x.english,x.chinese,x.user_answer,x.wrong_count,x.last_wrong_at])
        QMessageBox.information(self, "导出成功", path)
    def _clear_wrong_items(self):
        if QMessageBox.question(self, "清空错题", "确定清空错题本？", QMessageBox.Yes|QMessageBox.No, QMessageBox.No) == QMessageBox.Yes:
            clear_wrong_items(); self._set_status("错题本已清空")

    def _apply_runtime_settings(self, reason: str = "settings", changed_keys: set[str] | None = None) -> None:
        """Apply settings immediately, but avoid expensive full refreshes unless needed."""
        changed_keys = set(changed_keys or [])
        dictionary_keys = {
            "kaikki_enabled", "kaikki_jsonl_path", "kaikki_index_path", "kaikki_index_v2_path",
            "online_phonetic_realtime", "word_zh_realtime", "phonetic_display_type"
        }
        sentence_keys = {
            "font_size", "show_chinese", "show_chunk_structure_hint", "show_word_ipa_above_line",
            "six_step_display_mode", "six_step_show_color", "six_step_default_visible",
            "chunk_mode", "max_words_per_chunk", "max_chars_per_line", "theme", "skin", "chunk_line_color",
            "chunk_gap", "chunk_min_width", "hint_full_display_mode", "hint_panel_max_height", "show_colored_hints_after_correct",
            "practice_mode", "blind_mode_active", "choice_add_distractors", "choice_distractor_count",
            "fill_blank_count", "fill_add_distractors", "fill_distractor_count"
        }
        speech_keys = {
            "speech_engine", "speech_fallback_engine", "speech_voice", "speech_rate", "speech_volume",
            "kokoro_voice", "chattts_voice", "melotts_speaker", "styletts2_keep_alive",
            "prefer_local_media_audio", "local_media_mode"
        }

        try:
            if not changed_keys or (changed_keys & speech_keys) or app_settings.get("stop_playback_on_settings_apply", True):
                self._pending_play = None
                self._play_counter = 0
                self._speech.stop()
        except Exception:
            pass

        if not changed_keys or (changed_keys & dictionary_keys):
            try:
                reload_wordbook()
            except Exception:
                pass

        self._apply_theme()
        try:
            if hasattr(self, "hint_scroll"):
                self.hint_scroll.setMaximumHeight(int(app_settings.get("hint_panel_max_height", 260) or 260))
        except Exception:
            pass
        self._setup_shortcuts()
        try:
            if getattr(self, "_intensive_dialog", None) is not None and self._intensive_dialog.isVisible():
                self._intensive_dialog._setup_intensive_shortcuts()
        except Exception:
            pass
        self._apply_visibility_controls()
        self._refresh_shortcut_texts()

        try:
            if not changed_keys or any(k.startswith("sound_") or k == "typing_sound_enabled" for k in changed_keys):
                self._sound = SoundManager()
        except Exception:
            pass

        if self._materials:
            if not changed_keys or (changed_keys & sentence_keys) or (changed_keys & dictionary_keys):
                self._load_current_sentence()
            else:
                self._update_sub_hints(show_all=False)
        else:
            self._clear_display()

        self._set_status("设置已立即生效。", "correct")

    def _diagnose_kaikki(self):
        try:
            text = diagnose_kaikki_words()
        except Exception as e:
            text = "Kaikki 诊断失败：" + str(e) + "\n" + traceback.format_exc()
        dlg = QDialog(self)
        dlg.setWindowTitle("Kaikki 词典诊断")
        dlg.resize(860, 620)
        lay = QVBoxLayout(dlg)
        box = QTextEdit()
        box.setReadOnly(True)
        box.setPlainText(text)
        lay.addWidget(box)
        note = QLabel("如果显示 v1_single_offset，建议运行根目录 build_kaikki_index_v2.bat 重建 v2 多 offset 索引。")
        note.setWordWrap(True)
        lay.addWidget(note)
        btn = QDialogButtonBox(QDialogButtonBox.Close)
        btn.rejected.connect(dlg.reject)
        lay.addWidget(btn)
        dlg.exec()

    def _open_settings(self):
        if not self._require_feature("settings"):
            return
        """Open settings as a non-modal, resizable tool window.

        Using dlg.exec() made the very tall settings dialog modal.  If the
        window moved behind the main window or failed during resize, it captured
        all input invisibly and Windows played ding-dong sounds.  This version
        keeps it non-modal and keeps Apply/Save errors inside the dialog.
        """
        old = getattr(self, "_settings_dialog", None)
        if old is not None and old.isVisible():
            old.raise_()
            old.activateWindow()
            return
        dlg = SettingsDialog(self)
        self._settings_dialog = dlg
        dlg.settings_applied.connect(lambda keys: self._apply_runtime_settings("settings_dialog", set(keys or [])))
        dlg.destroyed.connect(lambda *_: setattr(self, "_settings_dialog", None))
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

class SettingsDialog(QDialog):
    settings_applied = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("偏好设置")
        self.setWindowModality(Qt.NonModal)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.resize(1040, 820)
        self.setMinimumSize(860, 620)
        main=QVBoxLayout(self); main.setContentsMargins(12,12,12,12); main.setSpacing(8)
        tabs=QTabWidget(); main.addWidget(tabs, 1)
        self._edits={}; self._shortcut_edits={}
        tabs.addTab(self._scroll(self._tab_basic()), "基础/训练")
        tabs.addTab(self._scroll(self._tab_hint()), "提示/六步")
        tabs.addTab(self._scroll(self._tab_playback()), "播放控制")
        tabs.addTab(self._scroll(self._tab_speech_translation()), "发音/翻译")
        tabs.addTab(self._scroll(self._tab_shortcuts()), "快捷键")
        tabs.addTab(self._scroll(self._tab_sounds()), "音效")
        btn=QDialogButtonBox()
        self.apply_btn = btn.addButton("应用", QDialogButtonBox.ApplyRole)
        self.save_btn = btn.addButton("保存并关闭", QDialogButtonBox.AcceptRole)
        self.close_btn = btn.addButton("关闭", QDialogButtonBox.RejectRole)
        btn.clicked.connect(self._on_button_clicked)
        main.addWidget(btn)

    def _scroll(self, widget: QWidget) -> QScrollArea:
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.NoFrame)
        area.setWidget(widget)
        return area

    def _on_button_clicked(self, button):
        box = self.findChild(QDialogButtonBox)
        role = box.buttonRole(button) if box else QDialogButtonBox.InvalidRole
        if role == QDialogButtonBox.ApplyRole:
            self._safe_apply(close_after=False)
        elif role == QDialogButtonBox.AcceptRole:
            self._safe_apply(close_after=True)
        elif role == QDialogButtonBox.RejectRole:
            self.close()

    def _safe_apply(self, close_after: bool = False) -> bool:
        try:
            changed = self.apply_settings()
            self.settings_applied.emit(changed)
            if close_after:
                self.accept()
            return True
        except Exception as e:
            log = ROOT / "data" / "settings_apply_error.log"
            try:
                log.parent.mkdir(parents=True, exist_ok=True)
                log.write_text(str(e) + "\n" + traceback.format_exc(), encoding="utf-8")
            except Exception:
                pass
            QMessageBox.critical(self, "设置应用失败", f"设置保存/应用失败，窗口不会关闭：\n{e}\n\n日志：{log}")
            return False

    def _tab_basic(self):
        w=QWidget(); l=QFormLayout(w)
        self.font_size=QSpinBox(); self.font_size.setRange(12,36); self.font_size.setValue(int(app_settings.get("font_size",20))); l.addRow("字体大小", self.font_size)
        self.show_chinese=QCheckBox("显示中文提示"); self.show_chinese.setChecked(bool(app_settings.get("show_chinese", True))); l.addRow(self.show_chinese)
        self.auto_next=QCheckBox("答对后自动下一句"); self.auto_next.setChecked(bool(app_settings.get("auto_next", False))); l.addRow(self.auto_next)
        self.practice_mode=QComboBox(); self.practice_mode.addItems(["dictation","blind","choice","fill_blank"]); self.practice_mode.setCurrentText(str(app_settings.get("practice_mode", "dictation"))); l.addRow("练习模式", self.practice_mode)
        self.choice_add_distractors=QCheckBox("选词模式加入干扰项（关闭=纯净模式，只使用台词单词）"); self.choice_add_distractors.setChecked(bool(app_settings.get("choice_add_distractors", False))); l.addRow(self.choice_add_distractors)
        self.choice_distractor_count=QSpinBox(); self.choice_distractor_count.setRange(0,30); self.choice_distractor_count.setValue(int(app_settings.get("choice_distractor_count", 8))); l.addRow("选词干扰项数量", self.choice_distractor_count)
        self.fill_blank_count=QSpinBox(); self.fill_blank_count.setRange(1,12); self.fill_blank_count.setValue(int(app_settings.get("fill_blank_count", 2))); l.addRow("填空模式空格数量", self.fill_blank_count)
        self.fill_add_distractors=QCheckBox("填空模式加入干扰项（关闭=只使用被挖空的正确词）"); self.fill_add_distractors.setChecked(bool(app_settings.get("fill_add_distractors", False))); l.addRow(self.fill_add_distractors)
        self.fill_distractor_count=QSpinBox(); self.fill_distractor_count.setRange(0,30); self.fill_distractor_count.setValue(int(app_settings.get("fill_distractor_count", 6))); l.addRow("填空干扰项数量", self.fill_distractor_count)
        self.chunk_mode=QComboBox(); self.chunk_mode.addItems(["smart","word"]); self.chunk_mode.setCurrentText(str(app_settings.get("chunk_mode","smart"))); l.addRow("语块拆分引擎", self.chunk_mode)
        chunk_note = QLabel("当前内置为 Smart V2 启发式拆分：优先保留代词/助动词/动词核心结构，并尽量让介词短语连在一起。")
        chunk_note.setWordWrap(True); l.addRow(chunk_note)
        self.max_words=QSpinBox(); self.max_words.setRange(1,8); self.max_words.setValue(int(app_settings.get("max_words_per_chunk",3))); l.addRow("每语块最多单词", self.max_words)
        self.max_chars=QSpinBox(); self.max_chars.setRange(20,120); self.max_chars.setValue(int(app_settings.get("max_chars_per_line",54))); l.addRow("每行最大字符数", self.max_chars)
        self.show_resource=QCheckBox("显示资源库面板"); self.show_resource.setChecked(bool(app_settings.get("show_resource_library", True))); l.addRow(self.show_resource)
        self.auto_show_resource=QCheckBox("扫描完成后自动显示资源库"); self.auto_show_resource.setChecked(bool(app_settings.get("auto_show_resource_library_after_scan", True))); l.addRow(self.auto_show_resource)
        self.theme=QComboBox(); self.theme.addItems(THEMES); self.theme.setCurrentText(str(app_settings.get("theme","云青禅意"))); l.addRow("主题配色", self.theme)
        self.skin=QComboBox(); self.skin.addItems(SKINS); self.skin.setCurrentText(str(app_settings.get("skin","极简学习本"))); l.addRow("界面皮肤", self.skin)
        skin_note=QLabel("主题控制颜色；皮肤控制控件形态、标签页、横线、按钮和面板气质。推荐先试：极简学习本、胶片影视、商务绅士、赛博终端。")
        skin_note.setWordWrap(True); l.addRow(skin_note)
        return w

    def _tab_hint(self):
        w = QWidget(); l = QFormLayout(w)
        l.addRow(self._section_label("① 音标 / 横线 / 结构提示", "#2563eb"))
        self.show_structure_hint = QCheckBox("横线下方显示句子成分/词性兜底提示")
        self.show_structure_hint.setChecked(bool(app_settings.get("show_chunk_structure_hint", True)))
        l.addRow(self.show_structure_hint)
        self.show_ipa_above = QCheckBox("单词/语块横线上方显示音标")
        self.show_ipa_above.setChecked(bool(app_settings.get("show_word_ipa_above_line", True)))
        l.addRow(self.show_ipa_above)
        self.phonetic_display_type = QComboBox(); self.phonetic_display_type.addItems(["auto", "uk", "us", "both", "none"])
        self.phonetic_display_type.setCurrentText(str(app_settings.get("phonetic_display_type", "auto") or "auto"))
        l.addRow("音标显示类型", self.phonetic_display_type)
        self.chunk_line_color = QComboBox(); self.chunk_line_color.addItems(["theme", "gray", "blue", "green", "orange", "purple", "pink", "red", "gold", "cyan"])
        self.chunk_line_color.setCurrentText(str(app_settings.get("chunk_line_color", "theme") or "theme"))
        l.addRow("横线颜色", self.chunk_line_color)
        self.chunk_gap = QSpinBox(); self.chunk_gap.setRange(8, 36); self.chunk_gap.setValue(int(app_settings.get("chunk_gap", 18) or 18))
        l.addRow("横线之间间距", self.chunk_gap)
        self.chunk_min_width = QSpinBox(); self.chunk_min_width.setRange(90, 200); self.chunk_min_width.setValue(int(app_settings.get("chunk_min_width", 120) or 120))
        l.addRow("横线最小宽度", self.chunk_min_width)
        self.hint_full_display_mode = QComboBox(); self.hint_full_display_mode.addItems(["inline_scroll", "floating"]); self.hint_full_display_mode.setCurrentText(str(app_settings.get("hint_full_display_mode", "inline_scroll") or "inline_scroll"))
        l.addRow("完整提示显示方式", self.hint_full_display_mode)
        self.hint_panel_max_height = QSpinBox(); self.hint_panel_max_height.setRange(160, 520); self.hint_panel_max_height.setValue(int(app_settings.get("hint_panel_max_height", 260) or 260))
        l.addRow("内嵌滚动提示最大高度", self.hint_panel_max_height)
        line_note = QLabel("说明：横线长度已改为按语块内容自适应；完整提示可选内嵌滚动或置顶挂件。")
        line_note.setWordWrap(True); l.addRow(line_note)

        l.addRow(self._section_label("② 六步提示面板", "#7c3aed"))
        self.six_mode = QComboBox(); self.six_mode.addItems(["overlay", "step"])
        self.six_mode.setCurrentText(str(app_settings.get("six_step_display_mode", "overlay")))
        l.addRow("六步提示显示方式", self.six_mode)
        self.six_color = QCheckBox("六步提示使用彩色分层显示")
        self.six_color.setChecked(bool(app_settings.get("six_step_show_color", True)))
        l.addRow(self.six_color)
        self.six_reset = QCheckBox("切换句子时重置六步提示进度")
        self.six_reset.setChecked(bool(app_settings.get("six_step_auto_reset_on_sentence", True)))
        l.addRow(self.six_reset)
        self.six_default_visible = QCheckBox("加载句子后默认显示六步提示第1步")
        self.six_default_visible.setChecked(bool(app_settings.get("six_step_default_visible", False)))
        l.addRow(self.six_default_visible)
        self.auto_six_hint = QCheckBox("正确后自动显示六步提示")
        self.auto_six_hint.setChecked(bool(app_settings.get("auto_show_six_step_after_correct", False)))
        l.addRow(self.auto_six_hint)
        self.show_correct_full = QCheckBox("正确后显示完整彩色提示信息（含六步提示总览）")
        self.show_correct_full.setChecked(bool(app_settings.get("show_colored_hints_after_correct", True)))
        l.addRow(self.show_correct_full)
        note = QLabel("说明：overlay=叠加显示，Ctrl+H 会显示 1、1+2、1+2+3……直到第6步。正确后会把词性、音标、中文和六步提示一并展开。")
        note.setWordWrap(True); l.addRow(note)
        return w

    def _tab_playback(self):
        w=QWidget(); l=QFormLayout(w)
        self.auto_play_sentence=QCheckBox("加载/切换台词时自动播放整句"); self.auto_play_sentence.setChecked(bool(app_settings.get("auto_play_sentence_on_load", False))); l.addRow(self.auto_play_sentence)
        self.auto_play_chunk=QComboBox(); self.auto_play_chunk.addItems(["off","chunk","word"]); self.auto_play_chunk.setCurrentText(str(app_settings.get("auto_play_on_chunk_focus","off"))); l.addRow("跳转后自动播放", self.auto_play_chunk)
        self.loop_mode=QComboBox(); self.loop_mode.addItems(["none","single","list"]); self.loop_mode.setCurrentText(str(app_settings.get("play_loop_mode","none"))); l.addRow("播放循环", self.loop_mode)
        self.play_times=QSpinBox(); self.play_times.setRange(1,10); self.play_times.setValue(int(app_settings.get("play_times",1))); l.addRow("播放次数", self.play_times)
        self.play_speed=QDoubleSpinBox(); self.play_speed.setRange(0.5,2.0); self.play_speed.setSingleStep(0.1); self.play_speed.setValue(float(app_settings.get("play_speed",1.0))); l.addRow("播放速度", self.play_speed)
        return w

    def _line_path(self, form, key, label, is_dir=False):
        row=QHBoxLayout(); edit=QLineEdit(str(app_settings.get(key,""))); row.addWidget(edit); btn=QPushButton("浏览"); row.addWidget(btn)
        if is_dir: btn.clicked.connect(lambda: edit.setText(QFileDialog.getExistingDirectory(self,"选择目录") or edit.text()))
        else: btn.clicked.connect(lambda: edit.setText(QFileDialog.getOpenFileName(self,"选择文件")[0] or edit.text()))
        form.addRow(label,row); self._edits[key]=edit; return edit

    def _scan_kokoro_voices(self) -> list[str]:
        from pathlib import Path
        candidates = []
        try:
            if self._edits.get("kokoro_voices_dir"):
                candidates.append(self._edits.get("kokoro_voices_dir").text().strip())
            if self._edits.get("kokoro_model_dir"):
                candidates.append(str(Path(self._edits.get("kokoro_model_dir").text().strip()) / "voices"))
        except Exception:
            pass
        candidates.extend([
            str(app_settings.get("kokoro_voices_dir", "")),
            str(Path(str(app_settings.get("kokoro_model_dir", ""))) / "voices"),
            r"G:\TTS_Models\TTS_ModelsKokoro-82M\voices",
        ])
        voices = []
        seen = set()
        for raw in candidates:
            if not raw:
                continue
            d = Path(raw)
            if d.exists() and d.is_dir():
                for p in sorted(d.glob("*.pt")):
                    if p.stem not in seen:
                        seen.add(p.stem); voices.append(p.stem)
        return voices or ["af_heart", "af_bella", "af_alloy", "af_aoede"]

    def _refresh_kokoro_voice_combo(self):
        current = self.kokoro_voice.currentText().strip() if hasattr(self, "kokoro_voice") else str(app_settings.get("kokoro_voice", "af_heart"))
        voices = self._scan_kokoro_voices()
        self.kokoro_voice.blockSignals(True)
        self.kokoro_voice.clear()
        self.kokoro_voice.addItems(voices)
        self.kokoro_voice.setEditable(True)
        self.kokoro_voice.setCurrentText(current if current in voices else (voices[0] if voices else current))
        self.kokoro_voice.blockSignals(False)
        if hasattr(self, "kokoro_voice_count_label"):
            self.kokoro_voice_count_label.setText(f"已扫描到 {len(voices)} 个 Kokoro voice。af=美音女声，am=美音男声，bf=英音女声，bm=英音男声。")

    def _section_label(self, text: str, color: str = "#2563eb") -> QLabel:
        lab = QLabel(text)
        lab.setStyleSheet(f"font-size:16px;font-weight:900;color:white;background:{color};padding:6px 10px;border-radius:8px;margin-top:8px;")
        return lab

    def _edge_voice_for_ui(self) -> str:
        region = self.speech_voice_region.currentText() if hasattr(self, "speech_voice_region") else str(app_settings.get("speech_voice_region", "en-US"))
        gender = self.speech_voice_gender.currentText() if hasattr(self, "speech_voice_gender") else str(app_settings.get("speech_voice_gender", "female"))
        presets = {
            ("en-US", "female"): "en-US-AriaNeural",
            ("en-US", "male"): "en-US-GuyNeural",
            ("en-US", "neutral"): "en-US-JennyNeural",
            ("en-GB", "female"): "en-GB-SoniaNeural",
            ("en-GB", "male"): "en-GB-RyanNeural",
            ("en-GB", "neutral"): "en-GB-LibbyNeural",
            ("en-AU", "female"): "en-AU-NatashaNeural",
            ("en-AU", "male"): "en-AU-WilliamNeural",
            ("en-CA", "female"): "en-CA-ClaraNeural",
            ("en-CA", "male"): "en-CA-LiamNeural",
        }
        return presets.get((region, gender), "en-US-AriaNeural")

    def _sync_edge_voice_preset(self):
        if hasattr(self, "edge_voice_preset"):
            target = self._edge_voice_for_ui()
            if target:
                self.edge_voice_preset.setCurrentText(target)

    def _tab_speech_translation(self):
        w=QWidget(); l=QFormLayout(w)
        l.setVerticalSpacing(10)
        l.addRow(self._section_label("① 发音总控", "#334155"))
        self.speech_engine=QComboBox(); self.speech_engine.addItems(["local_audio","edge_tts","chattts","kokoro","melotts","styletts2"]); self.speech_engine.setCurrentText(str(app_settings.get("speech_engine","edge_tts"))); l.addRow("发音主引擎", self.speech_engine)
        self.speech_fallback_engine=QComboBox(); self.speech_fallback_engine.addItems(["edge_tts","kokoro","chattts","melotts","styletts2","none"]); self.speech_fallback_engine.setCurrentText(str(app_settings.get("speech_fallback_engine","edge_tts"))); l.addRow("发音兜底引擎", self.speech_fallback_engine)
        self.speech_voice_region=QComboBox(); self.speech_voice_region.addItems(["en-US","en-GB","en-AU","en-CA"]); self.speech_voice_region.setCurrentText(str(app_settings.get("speech_voice_region","en-US"))); l.addRow("发音区域/口音", self.speech_voice_region)
        self.speech_voice_gender=QComboBox(); self.speech_voice_gender.addItems(["female","male","neutral"]); self.speech_voice_gender.setCurrentText(str(app_settings.get("speech_voice_gender","female"))); l.addRow("声音性别", self.speech_voice_gender)
        self.speech_rate=QDoubleSpinBox(); self.speech_rate.setRange(0.5,2.0); self.speech_rate.setSingleStep(0.1); self.speech_rate.setValue(float(app_settings.get("speech_rate",1.0))); l.addRow("TTS语速", self.speech_rate)
        self.speech_volume=QDoubleSpinBox(); self.speech_volume.setRange(0.0,1.0); self.speech_volume.setSingleStep(0.1); self.speech_volume.setValue(float(app_settings.get("speech_volume",1.0))); l.addRow("TTS音量", self.speech_volume)

        l.addRow(self._section_label("② Edge-TTS 在线兜底", "#2563eb"))
        self.edge_voice_preset=QComboBox(); self.edge_voice_preset.addItems(["en-US-AriaNeural","en-US-JennyNeural","en-US-GuyNeural","en-GB-SoniaNeural","en-GB-RyanNeural","en-GB-LibbyNeural","en-AU-NatashaNeural","en-AU-WilliamNeural","en-CA-ClaraNeural","en-CA-LiamNeural"])
        current_edge = str(app_settings.get("speech_voice", "") or "") or self._edge_voice_for_ui()
        self.edge_voice_preset.setCurrentText(current_edge if current_edge in [self.edge_voice_preset.itemText(i) for i in range(self.edge_voice_preset.count())] else self._edge_voice_for_ui())
        l.addRow("Edge-TTS voice", self.edge_voice_preset)
        self.speech_voice=QLineEdit(""); self.speech_voice.setPlaceholderText("高级手动覆盖；留空则按上方 Edge-TTS voice/口音/性别生效"); l.addRow("Voice手动覆盖", self.speech_voice)
        self.speech_voice_region.currentTextChanged.connect(self._sync_edge_voice_preset)
        self.speech_voice_gender.currentTextChanged.connect(self._sync_edge_voice_preset)

        l.addRow(self._section_label("③ Kokoro 本地高质量发音", "#16a34a"))
        self._line_path(l,"kokoro_model_dir","Kokoro模型目录",True); self._line_path(l,"kokoro_weight_path","Kokoro权重文件"); self._line_path(l,"kokoro_voices_dir","Kokoro voices目录",True)
        self.kokoro_voice=QComboBox(); self.kokoro_voice.setEditable(True); l.addRow("Kokoro voice", self.kokoro_voice)
        self.refresh_kokoro_voice_btn=QPushButton("刷新Kokoro声音列表"); self.refresh_kokoro_voice_btn.clicked.connect(self._refresh_kokoro_voice_combo); l.addRow(self.refresh_kokoro_voice_btn)
        self.kokoro_voice_count_label=QLabel(""); self.kokoro_voice_count_label.setWordWrap(True); l.addRow(self.kokoro_voice_count_label)
        self._refresh_kokoro_voice_combo()
        self.kokoro_local_only=QCheckBox("Kokoro只使用本地模型/本地缓存，不主动联网下载（推荐开启）"); self.kokoro_local_only.setChecked(bool(app_settings.get("kokoro_local_only", True))); l.addRow(self.kokoro_local_only)

        l.addRow(self._section_label("④ ChatTTS 脚本/本地 asset（替代 Piper）", "#7c3aed"))
        chat_note=QLabel("ChatTTS 不再自动下载 HuggingFace asset。必须填写你已跑通的 ChatTTS 脚本，或本地模型/asset 根目录；失败会写 data/chattts_last_error.log 并走兜底。")
        chat_note.setWordWrap(True); l.addRow(chat_note)
        self._line_path(l,"chattts_python_path","ChatTTS Python"); self._line_path(l,"chattts_script_path","ChatTTS脚本"); self._line_path(l,"chattts_model_dir","ChatTTS模型目录",True); self._line_path(l,"chattts_asset_dir","ChatTTS asset目录",True)
        self.chattts_voice=QLineEdit(str(app_settings.get("chattts_voice","default"))); l.addRow("ChatTTS voice/seed", self.chattts_voice)

        l.addRow(self._section_label("⑤ MeloTTS 独立配置", "#ea580c"))
        self._line_path(l,"melotts_python_path","MeloTTS Python"); self._line_path(l,"melotts_script_path","MeloTTS脚本"); self._line_path(l,"melotts_model_dir","MeloTTS模型目录",True); self._line_path(l,"melotts_checkpoint_path","MeloTTS checkpoint"); self._line_path(l,"melotts_config_path","MeloTTS config")
        self.melotts_speaker=QLineEdit(str(app_settings.get("melotts_speaker","EN-US"))); l.addRow("MeloTTS speaker", self.melotts_speaker)

        l.addRow(self._section_label("⑥ StyleTTS2 独立环境", "#db2777"))
        st_note=QLabel("StyleTTS2 使用你测试成功的独立虚拟环境和调用方式：from styletts2 import tts；StyleTTS2(model_checkpoint_path, config_path).inference(...)")
        st_note.setWordWrap(True); l.addRow(st_note)
        self._line_path(l,"styletts2_python_path","StyleTTS2 Python"); self._line_path(l,"styletts2_model_dir","StyleTTS2模型目录",True); self._line_path(l,"styletts2_checkpoint_path","StyleTTS2 checkpoint"); self._line_path(l,"styletts2_config_path","StyleTTS2 config")
        self.styletts2_keep_alive=QCheckBox("StyleTTS2 常驻 worker（首次慢一次，后续语块复用模型；推荐开启）"); self.styletts2_keep_alive.setChecked(bool(app_settings.get("styletts2_keep_alive", True))); l.addRow(self.styletts2_keep_alive)
        self.styletts2_realtime_diffusion_steps=QSpinBox(); self.styletts2_realtime_diffusion_steps.setRange(3,30); self.styletts2_realtime_diffusion_steps.setValue(int(app_settings.get("styletts2_realtime_diffusion_steps",4))); l.addRow("实时语块 diffusion_steps（推荐 3-5；越小越快）", self.styletts2_realtime_diffusion_steps)
        self.styletts2_production_diffusion_steps=QSpinBox(); self.styletts2_production_diffusion_steps.setRange(5,50); self.styletts2_production_diffusion_steps.setValue(int(app_settings.get("styletts2_production_diffusion_steps",20))); l.addRow("制作台高质量 diffusion_steps", self.styletts2_production_diffusion_steps)
        self.styletts2_alpha=QDoubleSpinBox(); self.styletts2_alpha.setRange(0.0,1.0); self.styletts2_alpha.setSingleStep(0.05); self.styletts2_alpha.setValue(float(app_settings.get("styletts2_alpha",0.3))); l.addRow("alpha", self.styletts2_alpha)
        self.styletts2_beta=QDoubleSpinBox(); self.styletts2_beta.setRange(0.0,1.0); self.styletts2_beta.setSingleStep(0.05); self.styletts2_beta.setValue(float(app_settings.get("styletts2_beta",0.7))); l.addRow("beta", self.styletts2_beta)

        l.addRow(self._section_label("⑥-2 TTS 音频尾音/噪声后处理", "#7c3aed"))
        self.tts_postprocess_enabled=QCheckBox("启用 TTS 输出后处理：去静音 + 尾部淡出 + 音量归一化"); self.tts_postprocess_enabled.setChecked(bool(app_settings.get("tts_postprocess_enabled", True))); l.addRow(self.tts_postprocess_enabled)
        self.tts_trim_silence=QCheckBox("裁剪首尾明显静音/低噪声"); self.tts_trim_silence.setChecked(bool(app_settings.get("tts_trim_silence", True))); l.addRow(self.tts_trim_silence)
        self.tts_fade_out_ms=QSpinBox(); self.tts_fade_out_ms.setRange(0,300); self.tts_fade_out_ms.setValue(int(app_settings.get("tts_fade_out_ms",100))); l.addRow("尾部淡出 ms（StyleTTS2 推荐 80-140）", self.tts_fade_out_ms)
        self.tts_trim_pad_ms=QSpinBox(); self.tts_trim_pad_ms.setRange(0,300); self.tts_trim_pad_ms.setValue(int(app_settings.get("tts_trim_pad_ms",80))); l.addRow("裁剪保留尾部 padding ms", self.tts_trim_pad_ms)
        self.tts_append_silence_ms=QSpinBox(); self.tts_append_silence_ms.setRange(0,300); self.tts_append_silence_ms.setValue(int(app_settings.get("tts_append_silence_ms",80))); l.addRow("尾部补静音 ms（防截断）", self.tts_append_silence_ms)
        self.tts_normalize_peak=QDoubleSpinBox(); self.tts_normalize_peak.setRange(0.1,1.0); self.tts_normalize_peak.setSingleStep(0.05); self.tts_normalize_peak.setValue(float(app_settings.get("tts_normalize_peak",0.88))); l.addRow("归一化峰值", self.tts_normalize_peak)

        l.addRow(self._section_label("⑦ 本地原声 / FFMPEG / 词典 / 翻译", "#0891b2"))
        self.prefer_local_media=QCheckBox("优先播放本地视频/音频片段（测试 TTS 时建议关闭）"); self.prefer_local_media.setChecked(bool(app_settings.get("prefer_local_media_audio", True))); l.addRow(self.prefer_local_media)
        self.local_media_mode=QComboBox(); self.local_media_mode.addItems(["cached_segment","direct","off"]); self.local_media_mode.setCurrentText(str(app_settings.get("local_media_mode","cached_segment"))); l.addRow("本地媒体播放模式", self.local_media_mode)
        self._line_path(l,"ffmpeg_path","FFMPEG exe/bin目录",True)
        self.online_phonetic=QCheckBox("允许实时联网查询缺失音标（可能变慢；默认关闭，只读本地/缓存）"); self.online_phonetic.setChecked(bool(app_settings.get("online_phonetic_realtime", False))); l.addRow(self.online_phonetic)
        self.kaikki_enabled=QCheckBox("启用 Kaikki 百万级本地词典音标/词性/英文释义"); self.kaikki_enabled.setChecked(bool(app_settings.get("kaikki_enabled", True))); l.addRow(self.kaikki_enabled)
        self._line_path(l,"kaikki_jsonl_path","Kaikki JSONL词典文件"); self._line_path(l,"kaikki_index_path","Kaikki offset索引文件v1"); self._line_path(l,"kaikki_index_v2_path","Kaikki offset索引v2（推荐）")
        self.word_zh_realtime=QCheckBox("训练时允许单词中文实时翻译兜底（会卡；制作台优先，默认关）"); self.word_zh_realtime.setChecked(bool(app_settings.get("word_zh_realtime", False))); l.addRow(self.word_zh_realtime)
        self.translation_engine=QComboBox(); self.translation_engine.addItems(["auto_google_opus","api_google_opus","opus_google_api","api_online","google_online","opus_local","manual","none"]); self.translation_engine.setCurrentText(str(app_settings.get("translation_engine","auto_google_opus"))); l.addRow("中文翻译引擎", self.translation_engine)
        self.translation_api_provider=QComboBox(); self.translation_api_provider.addItems(["openai_compatible","deepl","none"]); self.translation_api_provider.setCurrentText(str(app_settings.get("translation_api_provider","openai_compatible"))); l.addRow("API翻译供应商", self.translation_api_provider)
        self.translation_api_base=QLineEdit(str(app_settings.get("translation_api_base",""))); l.addRow("API Base URL", self.translation_api_base)
        self.translation_api_key=QLineEdit(str(app_settings.get("translation_api_key",""))); self.translation_api_key.setEchoMode(QLineEdit.Password); l.addRow("API Key", self.translation_api_key)
        self.translation_api_model=QLineEdit(str(app_settings.get("translation_api_model","gpt-4o-mini"))); l.addRow("API Model", self.translation_api_model)
        self.auto_translate=QCheckBox("导入后/缺中文时后台补中文（不阻塞输入；Google/API失败后OPUS兜底）"); self.auto_translate.setChecked(bool(app_settings.get("auto_translate_on_import",True))); l.addRow(self.auto_translate)
        self.background_translate_missing_chinese=QCheckBox("当前句缺中文时后台补译（推荐开启；不会在输入事件中翻译）"); self.background_translate_missing_chinese.setChecked(bool(app_settings.get("background_translate_missing_chinese",True))); l.addRow(self.background_translate_missing_chinese)
        self._line_path(l,"opus_model_dir","OPUS本地模型目录",True)

        self.test_tts_btn=QPushButton("测试当前发音设置"); self.test_tts_btn.clicked.connect(lambda: self._test_tts()) ; l.addRow(self.test_tts_btn)
        return w

    def _test_tts(self):
        try:
            # Apply first so the test uses current widgets without closing the settings window.
            self.apply_settings()
            parent = self.parent()
            if parent and hasattr(parent, "_speech"):
                parent._speech.play_text("This is a voice test.", "")
                QMessageBox.information(self, "测试发音", "已发起测试发音。如果主引擎失败，会尝试兜底引擎。实际使用结果会写入 data/last_tts_engine_report.log。")
        except Exception as e:
            QMessageBox.critical(self, "测试发音失败", str(e))

    def _tab_shortcuts(self):
        w=QWidget(); l=QFormLayout(w); labels={"play_sentence":"播放整句","play_current_chunk":"播放当前语块","submit":"提交/下一句","show_hint":"六步提示","show_answer":"显示答案","fullscreen":"全屏","exit_fullscreen":"退出全屏","prev_sentence":"上一句","next_sentence":"下一句","import_material":"导入素材","favorite":"收藏","copy_sentence":"复制台词", "toggle_resource_library":"显示/隐藏资源库", "cycle_speech_engine":"切换发音模型", "cycle_speech_voice":"切换发音声音", "cycle_translation_engine":"切换翻译模型", "toggle_chinese_runtime":"显示/隐藏中文", "toggle_ipa_runtime":"显示/隐藏音标", "toggle_subhint_runtime":"显示/隐藏下方提示", "toggle_blind_mode":"盲听模式", "cycle_practice_mode":"切换练习模式", "intensive_play_current":"精听：播放当前句", "intensive_prev_line":"精听：上一句", "intensive_next_line":"精听：下一句", "intensive_pause_resume":"精听：暂停/继续", "intensive_stop":"精听：停止", "intensive_movie_mode":"精听：观影模式", "intensive_fullscreen":"精听：全屏", "intensive_exit_fullscreen":"精听：退出全屏", "intensive_copy_current":"精听：复制当前句"}
        note = QLabel("F1 发音模型，F2 发音声音，F3 翻译模型，F4/F5/F6 显示隐藏，F7 盲听，F8 听写/盲听/选词循环。精听弹窗的播放/切句/复制/观影也可在这里单独设置。修改后点应用立即生效；已打开的精听弹窗重新打开后生效。")
        note.setWordWrap(True); l.addRow(note)
        for k,label in labels.items():
            e=QLineEdit(app_settings.get_shortcut(k)); e.setPlaceholderText(DEFAULT_SHORTCUTS.get(k,"")); self._shortcut_edits[k]=e; l.addRow(label,e)
        return w

    def _tab_sounds(self):
        w=QWidget(); l=QFormLayout(w)
        self.sound_enabled=QCheckBox("启用打字/反馈音效"); self.sound_enabled.setChecked(bool(app_settings.get("typing_sound_enabled", True))); l.addRow(self.sound_enabled)
        self.sound_vol=QDoubleSpinBox(); self.sound_vol.setRange(0,1); self.sound_vol.setSingleStep(0.1); self.sound_vol.setValue(float(app_settings.get("typing_sound_volume",0.45))); l.addRow("sound volume", self.sound_vol)
        self.sound_boxes={}
        for key,label in [("sound_key","play sound on click"),("sound_correct","play sound on correct"),("sound_wrong","play sound on error"),("sound_complete","complete sound"),("sound_time_warning","play time warning")]:
            cb=QComboBox(); cb.addItems(SOUND_NAMES); cb.setCurrentText(str(app_settings.get(key,"off"))); self.sound_boxes[key]=cb; l.addRow(label, cb)
        return w

    def apply_settings(self):
        vals = {
            "font_size": self.font_size.value(),
            "show_chinese": self.show_chinese.isChecked(),
            "auto_next": self.auto_next.isChecked(),
            "practice_mode": self.practice_mode.currentText() if hasattr(self, "practice_mode") else str(app_settings.get("practice_mode", "dictation")),
            "blind_mode_active": (self.practice_mode.currentText() == "blind") if hasattr(self, "practice_mode") else bool(app_settings.get("blind_mode_active", False)),
            "choice_add_distractors": self.choice_add_distractors.isChecked() if hasattr(self, "choice_add_distractors") else bool(app_settings.get("choice_add_distractors", False)),
            "choice_distractor_count": self.choice_distractor_count.value() if hasattr(self, "choice_distractor_count") else int(app_settings.get("choice_distractor_count", 8)),
            "fill_blank_count": self.fill_blank_count.value() if hasattr(self, "fill_blank_count") else int(app_settings.get("fill_blank_count", 2)),
            "fill_add_distractors": self.fill_add_distractors.isChecked() if hasattr(self, "fill_add_distractors") else bool(app_settings.get("fill_add_distractors", False)),
            "fill_distractor_count": self.fill_distractor_count.value() if hasattr(self, "fill_distractor_count") else int(app_settings.get("fill_distractor_count", 6)),
            "show_colored_hints_after_correct": self.show_correct_full.isChecked(),
            "auto_show_six_step_after_correct": self.auto_six_hint.isChecked(),
            "show_chunk_structure_hint": self.show_structure_hint.isChecked(),
            "show_word_ipa_above_line": self.show_ipa_above.isChecked(),
            "phonetic_display_type": self.phonetic_display_type.currentText() if hasattr(self, "phonetic_display_type") else str(app_settings.get("phonetic_display_type", "auto")),
            "chunk_line_color": self.chunk_line_color.currentText() if hasattr(self, "chunk_line_color") else str(app_settings.get("chunk_line_color", "theme")),
            "chunk_gap": self.chunk_gap.value() if hasattr(self, "chunk_gap") else int(app_settings.get("chunk_gap", 18)),
            "chunk_min_width": self.chunk_min_width.value() if hasattr(self, "chunk_min_width") else int(app_settings.get("chunk_min_width", 120)),
            "hint_full_display_mode": self.hint_full_display_mode.currentText() if hasattr(self, "hint_full_display_mode") else str(app_settings.get("hint_full_display_mode", "inline_scroll")),
            "hint_panel_max_height": self.hint_panel_max_height.value() if hasattr(self, "hint_panel_max_height") else int(app_settings.get("hint_panel_max_height", 260)),
            "six_step_display_mode": self.six_mode.currentText(),
            "six_step_show_color": self.six_color.isChecked(),
            "six_step_auto_reset_on_sentence": self.six_reset.isChecked(),
            "six_step_default_visible": self.six_default_visible.isChecked(),
            "chunk_mode": self.chunk_mode.currentText(),
            "max_words_per_chunk": self.max_words.value(),
            "max_chars_per_line": self.max_chars.value(),
            "show_resource_library": self.show_resource.isChecked(),
            "auto_show_resource_library_after_scan": self.auto_show_resource.isChecked(),
            "theme": self.theme.currentText(),
            "skin": self.skin.currentText() if hasattr(self, "skin") else str(app_settings.get("skin", "极简学习本")),
            "auto_play_sentence_on_load": self.auto_play_sentence.isChecked(),
            "auto_play_on_chunk_focus": self.auto_play_chunk.currentText(),
            "play_loop_mode": self.loop_mode.currentText(),
            "play_times": self.play_times.value(),
            "play_speed": self.play_speed.value(),
            "speech_engine": self.speech_engine.currentText(),
            "speech_fallback_engine": self.speech_fallback_engine.currentText() if hasattr(self, "speech_fallback_engine") else str(app_settings.get("speech_fallback_engine", "edge_tts")),
            "speech_voice_region": self.speech_voice_region.currentText() if hasattr(self, "speech_voice_region") else str(app_settings.get("speech_voice_region", "en-US")),
            "speech_voice_gender": self.speech_voice_gender.currentText() if hasattr(self, "speech_voice_gender") else str(app_settings.get("speech_voice_gender", "female")),
            "prefer_local_media_audio": self.prefer_local_media.isChecked(),
            "local_media_mode": self.local_media_mode.currentText(),
            "ffmpeg_path": self._edits.get("ffmpeg_path").text().strip() if self._edits.get("ffmpeg_path") else str(app_settings.get("ffmpeg_path", "")),
            "online_phonetic_realtime": self.online_phonetic.isChecked(),
            "kaikki_enabled": self.kaikki_enabled.isChecked(),
            "word_zh_realtime": self.word_zh_realtime.isChecked() if hasattr(self, "word_zh_realtime") else False,
            "speech_voice": (self.speech_voice.text().strip() or (self.edge_voice_preset.currentText() if hasattr(self, "edge_voice_preset") else "en-US-AriaNeural")),
            "speech_rate": self.speech_rate.value(),
            "speech_volume": self.speech_volume.value(),
            "kokoro_voice": self.kokoro_voice.currentText().strip() if hasattr(self, "kokoro_voice") and hasattr(self.kokoro_voice, "currentText") else str(app_settings.get("kokoro_voice", "af_heart")),
            "chattts_voice": self.chattts_voice.text().strip() if hasattr(self, "chattts_voice") else str(app_settings.get("chattts_voice", "default")),
            "melotts_speaker": self.melotts_speaker.text().strip() if hasattr(self, "melotts_speaker") else str(app_settings.get("melotts_speaker", "EN-US")),
            "styletts2_keep_alive": self.styletts2_keep_alive.isChecked() if hasattr(self, "styletts2_keep_alive") else bool(app_settings.get("styletts2_keep_alive", True)),
            "styletts2_realtime_diffusion_steps": self.styletts2_realtime_diffusion_steps.value() if hasattr(self, "styletts2_realtime_diffusion_steps") else int(app_settings.get("styletts2_realtime_diffusion_steps", 6)),
            "styletts2_production_diffusion_steps": self.styletts2_production_diffusion_steps.value() if hasattr(self, "styletts2_production_diffusion_steps") else int(app_settings.get("styletts2_production_diffusion_steps", 20)),
            "styletts2_diffusion_steps": self.styletts2_realtime_diffusion_steps.value() if hasattr(self, "styletts2_realtime_diffusion_steps") else int(app_settings.get("styletts2_diffusion_steps", 6)),
            "styletts2_alpha": self.styletts2_alpha.value() if hasattr(self, "styletts2_alpha") else float(app_settings.get("styletts2_alpha", 0.3)),
            "styletts2_beta": self.styletts2_beta.value() if hasattr(self, "styletts2_beta") else float(app_settings.get("styletts2_beta", 0.7)),
            "tts_postprocess_enabled": self.tts_postprocess_enabled.isChecked() if hasattr(self, "tts_postprocess_enabled") else bool(app_settings.get("tts_postprocess_enabled", True)),
            "tts_trim_silence": self.tts_trim_silence.isChecked() if hasattr(self, "tts_trim_silence") else bool(app_settings.get("tts_trim_silence", True)),
            "tts_fade_out_ms": self.tts_fade_out_ms.value() if hasattr(self, "tts_fade_out_ms") else int(app_settings.get("tts_fade_out_ms", 100)),
            "tts_trim_pad_ms": self.tts_trim_pad_ms.value() if hasattr(self, "tts_trim_pad_ms") else int(app_settings.get("tts_trim_pad_ms", 80)),
            "tts_append_silence_ms": self.tts_append_silence_ms.value() if hasattr(self, "tts_append_silence_ms") else int(app_settings.get("tts_append_silence_ms", 80)),
            "tts_normalize_peak": self.tts_normalize_peak.value() if hasattr(self, "tts_normalize_peak") else float(app_settings.get("tts_normalize_peak", 0.88)),
            "translation_engine": self.translation_engine.currentText(),
            "translation_api_provider": self.translation_api_provider.currentText() if hasattr(self, "translation_api_provider") else str(app_settings.get("translation_api_provider", "openai_compatible")),
            "translation_api_base": self.translation_api_base.text().strip() if hasattr(self, "translation_api_base") else str(app_settings.get("translation_api_base", "")),
            "translation_api_key": self.translation_api_key.text().strip() if hasattr(self, "translation_api_key") else str(app_settings.get("translation_api_key", "")),
            "translation_api_model": self.translation_api_model.text().strip() if hasattr(self, "translation_api_model") else str(app_settings.get("translation_api_model", "gpt-4o-mini")),
            "auto_translate_on_import": self.auto_translate.isChecked(),
            "background_translate_missing_chinese": self.background_translate_missing_chinese.isChecked() if hasattr(self, "background_translate_missing_chinese") else bool(app_settings.get("background_translate_missing_chinese", True)),
            "kokoro_local_only": self.kokoro_local_only.isChecked() if hasattr(self, "kokoro_local_only") else bool(app_settings.get("kokoro_local_only", True)),
            "typing_sound_enabled": self.sound_enabled.isChecked(),
            "typing_sound_volume": self.sound_vol.value(),
        }
        for k, e in self._edits.items():
            vals[k] = e.text().strip()
        vals["shortcuts"] = {
            k: (e.text().strip() or DEFAULT_SHORTCUTS.get(k, ""))
            for k, e in self._shortcut_edits.items()
        }
        for k, cb in self.sound_boxes.items():
            vals[k] = cb.currentText()

        changed = set()
        for k, v in vals.items():
            if app_settings.get(k) != v:
                changed.add(k)

        # One save only. Repeated JSON writes caused slow settings apply on Windows.
        if hasattr(app_settings, "update_many"):
            app_settings.update_many(vals)
        else:
            for k, v in vals.items():
                app_settings.set(k, v)
        return changed

