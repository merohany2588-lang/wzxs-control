from __future__ import annotations

import argparse
import gc
import json
import os
import sys
import traceback
from pathlib import Path


def _write(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except Exception:
        pass


def _lang_code(voice_name: str, region: str = "en-US") -> str:
    v = (voice_name or "af_heart").lower()
    if v.startswith(("bf_", "bm_")):
        return "b"
    if v.startswith(("af_", "am_")):
        return "a"
    return "b" if (region or "").lower() in {"en-gb", "gb", "uk", "british"} else "a"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    args = parser.parse_args()

    req_path = Path(args.request)
    req = json.loads(req_path.read_text(encoding="utf-8"))

    text = str(req.get("text") or "")
    output = Path(str(req.get("output") or ""))
    data_dir = Path(str(req.get("data_dir") or Path.cwd() / "data"))
    report = data_dir / "kokoro_last_error.log"

    model_dir = Path(str(req.get("model_dir") or ""))
    weight_path = Path(str(req.get("weight_path") or ""))
    voices_dir = Path(str(req.get("voices_dir") or ""))
    voice_name = str(req.get("voice_name") or "af_heart").replace(".pt", "")
    voice_path = voices_dir / f"{voice_name}.pt"
    speed = float(req.get("rate") or 1.0)
    volume = float(req.get("volume") or 1.0)
    region = str(req.get("region") or "en-US")
    lang_code = _lang_code(voice_name, region)

    lines: list[str] = []
    def log(x: str) -> None:
        lines.append(str(x))

    log("worker=kokoro_subprocess_simple_pipeline")
    log(f"python={sys.executable}")
    log("call_style=KPipeline(lang_code)->pipeline(text, voice=voice_name)")
    log(f"model_dir={model_dir} exists={model_dir.exists()}")
    log(f"weight_path={weight_path} exists={weight_path.exists()}")
    log(f"voices_dir={voices_dir} exists={voices_dir.exists()}")
    log(f"voice_name={voice_name}")
    log(f"voice_path={voice_path} exists={voice_path.exists()}")
    log(f"lang_code={lang_code}")
    log(f"output={output}")

    if not text.strip():
        log("FAIL: empty text")
        _write(report, "\n".join(lines))
        return 10
    if not voice_path.exists():
        log("FAIL: voice file missing in voices_dir; Kokoro may still use cached voice by name, but app refuses ambiguous call.")
        _write(report, "\n".join(lines))
        return 12

    # The user-proven script does NOT manually bind KModel/voice_path. It scans local voices
    # only for choices, then calls KPipeline with voice_name. We intentionally mirror that.
    # Do not set HF_HUB_OFFLINE here: the installed Kokoro package resolves its own local HF cache.
    try:
        import inspect
        import numpy as np
        import soundfile as sf
        import torch
        from kokoro import KPipeline  # type: ignore

        log(f"kokoro.KPipeline_signature={inspect.signature(KPipeline)}")
        log(f"torch_version={getattr(torch, '__version__', 'unknown')}")
        log(f"torch_cuda_available={torch.cuda.is_available()}")

        if torch.cuda.is_available():
            try:
                torch.cuda.empty_cache()
            except Exception as e:
                log(f"torch.cuda.empty_cache warning={repr(e)}")
        gc.collect()

        pipeline = KPipeline(lang_code=lang_code)
        generator = pipeline(text, voice=voice_name, speed=speed)

        chunks = []
        sample_rate = 24000
        for i, item in enumerate(generator):
            audio = None
            if isinstance(item, tuple) and len(item) >= 3:
                # official/common tuple: (graphemes, phonemes, audio)
                audio = item[2]
            elif hasattr(item, "audio"):
                audio = item.audio
            elif isinstance(item, dict):
                audio = item.get("audio") or item.get("samples")
                sample_rate = int(item.get("sample_rate") or item.get("sr") or sample_rate)
            else:
                audio = item
            if audio is not None:
                chunks.append(np.asarray(audio, dtype="float32") * float(volume))
            if i >= 20:
                # Safety guard for accidentally huge generators.
                break

        if not chunks:
            log("FAIL: no audio chunks")
            _write(report, "\n".join(lines))
            return 20

        output.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output), np.concatenate(chunks) if len(chunks) > 1 else chunks[0], sample_rate)
        ok = output.exists() and output.stat().st_size > 100
        log(f"ok={ok} size={output.stat().st_size if output.exists() else 0}")
        _write(report, "\n".join(lines))
        return 0 if ok else 21
    except Exception as e:
        log("EXCEPTION: " + repr(e))
        log(traceback.format_exc())
        _write(report, "\n".join(lines))
        return 30


if __name__ == "__main__":
    raise SystemExit(main())
