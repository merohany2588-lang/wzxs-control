from __future__ import annotations

import argparse
import inspect
import json
import sys
import traceback
from pathlib import Path


def _write(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except Exception:
        pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    args = parser.parse_args()
    req_path = Path(args.request)
    req = json.loads(req_path.read_text(encoding="utf-8"))

    data_dir = Path(str(req.get("data_dir") or Path.cwd() / "data"))
    report = data_dir / "melotts_last_error.log"
    lines: list[str] = []
    def log(x: str) -> None:
        lines.append(str(x))

    text = str(req.get("text") or "")
    output = Path(str(req.get("output") or ""))
    speaker = str(req.get("speaker") or "EN-US")
    speed = float(req.get("speed") or 1.0)
    model_dir = Path(str(req.get("model_dir") or ""))
    checkpoint = Path(str(req.get("checkpoint") or ""))
    config = Path(str(req.get("config") or ""))
    device = str(req.get("device") or "cpu")

    log("worker=melotts_direct_api")
    log(f"python={sys.executable}")
    log(f"text_len={len(text)} speaker={speaker} speed={speed} device={device}")
    log(f"model_dir={model_dir} exists={model_dir.exists()}")
    log(f"checkpoint={checkpoint} exists={checkpoint.exists()}")
    log(f"config={config} exists={config.exists()}")
    log(f"output={output}")

    if not text.strip():
        log("FAIL: empty text")
        _write(report, "\n".join(lines))
        return 10

    try:
        from melo.api import TTS  # type: ignore
        import soundfile as sf  # noqa: F401
        sig = inspect.signature(TTS)
        log(f"melo.api.TTS_signature={sig}")

        # Different MeloTTS builds expose slightly different constructor kwargs.
        candidates: list[dict] = []
        base = {"language": "EN", "device": device}
        if checkpoint.exists() and config.exists():
            for ck in ["ckpt_path", "checkpoint_path", "model_path"]:
                for cf in ["config_path", "config"]:
                    d = dict(base)
                    d[ck] = str(checkpoint)
                    d[cf] = str(config)
                    candidates.append(d)
        candidates.append(base)

        model = None
        last_err = None
        for kw in candidates:
            try:
                log(f"try_constructor={kw}")
                model = TTS(**kw)
                log("constructor_ok")
                break
            except Exception as e:
                last_err = e
                log(f"constructor_failed={repr(e)}")
        if model is None:
            raise RuntimeError(f"MeloTTS constructor failed: {last_err!r}")

        speaker_ids = getattr(getattr(model, "hps", None), "data", None)
        speaker_map = getattr(speaker_ids, "spk2id", None) or getattr(model, "speaker_ids", None) or {}
        log(f"speaker_map={speaker_map}")
        spk = speaker
        if isinstance(speaker_map, dict):
            spk = speaker_map.get(speaker) or speaker_map.get("EN-US") or speaker_map.get("EN_Default") or next(iter(speaker_map.values()), speaker)
        log(f"speaker_used={spk}")

        output.parent.mkdir(parents=True, exist_ok=True)
        if hasattr(model, "tts_to_file"):
            model.tts_to_file(text, spk, str(output), speed=speed)
        elif hasattr(model, "infer"):
            wav = model.infer(text, speaker=spk, speed=speed)
            import soundfile as sf
            sf.write(str(output), wav, 24000)
        else:
            raise RuntimeError("MeloTTS object has neither tts_to_file nor infer")

        ok = output.exists() and output.stat().st_size > 100
        log(f"ok={ok} size={output.stat().st_size if output.exists() else 0}")
        _write(report, "\n".join(lines))
        return 0 if ok else 20
    except Exception as e:
        log("EXCEPTION: " + repr(e))
        log(traceback.format_exc())
        _write(report, "\n".join(lines))
        return 30


if __name__ == "__main__":
    raise SystemExit(main())
