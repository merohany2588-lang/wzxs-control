from __future__ import annotations
import math, wave, struct
from pathlib import Path
from PySide6.QtCore import QUrl
from PySide6.QtMultimedia import QSoundEffect
from .settings import app_settings

ROOT = Path(__file__).resolve().parents[1]
SOUNDS_DIR = ROOT / "assets" / "sounds"
SOUND_NAMES = ["off","click","beep","pop","typewriter","rubber_keys","nk_creams","osu","hitmarker","sine","sawtooth","square","triangle","pentatonic","wholetone","fist_fight","success","error_soft","damage","missed_punch","complete_bell"]

class SoundManager:
    def __init__(self) -> None:
        self.effects: dict[str,QSoundEffect] = {}
        self.ensure_builtin_sounds()
        for p in SOUNDS_DIR.glob("*.wav"):
            e = QSoundEffect(); e.setSource(QUrl.fromLocalFile(str(p.resolve()))); e.setLoopCount(1)
            self.effects[p.stem] = e

    def ensure_builtin_sounds(self) -> None:
        SOUNDS_DIR.mkdir(parents=True, exist_ok=True)
        for name in SOUND_NAMES:
            if name == "off":
                continue
            path = SOUNDS_DIR / f"{name}.wav"
            if path.exists():
                continue
            freq = {
                "click": 900, "beep": 700, "pop": 260, "typewriter": 1200,
                "success": 880, "complete_bell": 1040, "error_soft": 180, "damage": 130,
                "missed_punch": 160, "triangle": 520, "square": 420, "sine": 620,
                "sawtooth": 330, "pentatonic": 660, "wholetone": 740, "rubber_keys": 300,
                "nk_creams": 450, "osu": 980, "hitmarker": 1100, "fist_fight": 200,
            }.get(name, 600)
            dur = 0.035 if name in {"key","click","typewriter"} else 0.075
            self._write_tone(path, freq, dur, wave_type="sine")

    def _write_tone(self, path: Path, freq: float, dur: float, wave_type: str = "sine") -> None:
        rate = 22050
        frames = int(rate * dur)
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
            data = bytearray()
            for i in range(frames):
                t = i / rate
                amp = 0.35 * (1 - i / max(frames,1))
                val = math.sin(2*math.pi*freq*t)
                data += struct.pack("<h", int(32767 * amp * val))
            w.writeframes(bytes(data))

    def play(self, setting_key: str) -> None:
        if not app_settings.get("typing_sound_enabled", True):
            return
        name = str(app_settings.get(setting_key, "off") or "off")
        if name == "off":
            return
        e = self.effects.get(name)
        if not e:
            return
        e.setVolume(max(0.0, min(1.0, float(app_settings.get("typing_sound_volume", 0.45)))))
        e.play()
