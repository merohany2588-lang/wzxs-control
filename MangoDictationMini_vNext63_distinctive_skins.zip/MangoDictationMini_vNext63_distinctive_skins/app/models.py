from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Material:
    id: int = 0
    source_name: str = ""
    english: str = ""
    chinese: str = ""
    # Explicit per-line audio file; for TXT/CSV third column or pre-cut audio.
    audio_path: str = ""
    # Optional full local media file matched from scanned folder.  For SRT/VTT,
    # start_ms/end_ms are used to play only the current subtitle segment.
    media_path: str = ""
    start_ms: int = -1
    end_ms: int = -1
    favorite: bool = False
    wrong_count: int = 0
    correct_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    last_practiced_at: str = ""


@dataclass
class WrongItem:
    id: int = 0
    material_id: int = 0
    english: str = ""
    chinese: str = ""
    user_answer: str = ""
    wrong_count: int = 1
    last_wrong_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))


@dataclass
class Token:
    text: str
    is_word: bool = True


@dataclass
class Chunk:
    text: str
    words: list[str]
    trailing_punct: str = ""
    start_word_index: int = 0
    end_word_index: int = 0


@dataclass
class WordInfo:
    word: str = ""
    ipa_uk: str = ""
    ipa_us: str = ""
    phonetic: str = ""
    pos: str = ""
    zh: str = ""
    en_def: str = ""
    synonyms: str = ""
    antonyms: str = ""
    homophones: str = ""
    source: str = "local"
