from __future__ import annotations
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SETTINGS_PATH = ROOT / "data" / "settings.json"

DEFAULT_SHORTCUTS = {
    "play_sentence": "Ctrl+Up",
    "play_current_chunk": "Ctrl+Down",
    "submit": "Return",
    "show_hint": "Ctrl+H",
    "show_answer": "Ctrl+;",
    "fullscreen": "F11",
    "exit_fullscreen": "Escape",
    "prev_sentence": "Left",
    "next_sentence": "Right",
    "import_material": "Ctrl+O",
    "favorite": "Ctrl+M",
    "copy_sentence": "Ctrl+Shift+C",
    "scan_folder": "Ctrl+Shift+O",
    "toggle_resource_library": "Ctrl+L",
    "cycle_speech_engine": "F1",
    "cycle_speech_voice": "F2",
    "cycle_translation_engine": "F3",
    "toggle_chinese_runtime": "F4",
    "toggle_ipa_runtime": "F5",
    "toggle_subhint_runtime": "F6",
    "toggle_blind_mode": "F7",
    "cycle_practice_mode": "F8",
    "intensive_play_current": "Space",
    "intensive_prev_line": "Left",
    "intensive_next_line": "Right",
    "intensive_pause_resume": "Ctrl+Space",
    "intensive_stop": "S",
    "intensive_movie_mode": "M",
    "intensive_fullscreen": "F11",
    "intensive_exit_fullscreen": "Escape",
    "intensive_copy_current": "Ctrl+Shift+C",
}


CHINESE_THEMES = [
    '云青禅意',
    '烟雨姑苏',
    '松风竹影',
    '霜梅浅黛',
    '山河清砚',
    '琉璃清宵',
    '兰亭暮晚',
    '青梧栖月',
    '梵音渡川',
    '琼楼玉宇',
    '墨染江南',
    '云山听涛',
    '星穹深蓝',
    '深空极夜',
    '银河幻境',
    '暮光星轨',
    '星月沉寂',
    '星云幽梦',
    '破晓星穹',
    '暗夜星辉',
    '幻宇流光',
    '星落尘寰',
    '紫宸星落',
    '清霄星梦',
    '霓虹幻界',
    '机械都市',
    '紫电幻境',
    '废土赛博',
    '光电未来',
    '量子霓虹',
    '赤焰赛博',
    '冰蓝纪元',
    '幻彩代码',
    '暗夜机甲',
    '都市迷途',
    '次元流光',
    '林间朝露',
    '青野晚风',
    '浅夏清宁',
    '雾隐青森',
    '森屿暖阳',
    '春野溪风',
    '苔痕青径',
    '山野清欢',
    '浅林薄雾',
    '青芜流年',
    '溪涧草木',
    '晚风林汐',
    '鎏金雅灰',
    '焦糖拿铁',
    '摩卡极简',
    '琥珀时光',
    '暖棕素简',
    '檀木清奢',
    '雅金流年',
    '轻奢茶褐',
    '金棕暮色',
    '复古奶咖',
    '素棕雅韵',
    '浅金素雅',
]

THEMES = list(CHINESE_THEMES)

SKINS = [
    "极简学习本",
    "国风雅卷",
    "商务绅士",
    "赛博终端",
    "轻奢奶油",
    "胶片影视",
    "学霸练习册",
    "悬浮挂件",
]

DEFAULT_SETTINGS: dict[str, Any] = {
    "font_size": 20,
    "show_chinese": True,
    "ignore_case": True,
    "ignore_punctuation": True,
    "auto_next": False,
    "theme": "云青禅意",
    "skin": "极简学习本",
    "chunk_mode": "smart",       # smart / word
    "max_words_per_chunk": 3,
    "max_chars_per_line": 54,
    "require_input_before_space_jump": True,
    "show_answer_after_wrong_submit": False,
    "show_colored_hints_after_correct": True,
    "auto_show_six_step_after_correct": False,
    "six_step_default_visible": False,

    # Hint / six-step behavior
    "show_chunk_structure_hint": True,
    "show_word_ipa_above_line": True,
    "six_step_display_mode": "overlay",  # overlay / step
    "six_step_overlay_default": True,
    "six_step_show_color": True,
    "six_step_auto_reset_on_sentence": True,
    "phonetic_display_type": "auto",  # auto / uk / us / both / none
    "chunk_line_color": "theme",
    "chunk_gap": 28,
    "chunk_min_width": 36,
    "practice_mode": "dictation",  # dictation / blind / choice / fill_blank
    "blind_mode_active": False,
    "choice_add_distractors": False,
    "choice_distractor_count": 8,
    "choice_show_chinese": True,
    "fill_blank_count": 2,
    "fill_add_distractors": False,
    "fill_distractor_count": 6,
    "ui_workspace_tabs": True,
    "lightweight_hint_render": True,
    "hint_full_display_mode": "inline_scroll",  # inline_scroll / floating
    "hint_panel_max_height": 260,
    "main_splitter_sizes": [520, 260],

    # Playback
    "auto_play_sentence_on_load": False,
    "auto_play_on_chunk_focus": "off",  # off / chunk / word
    "play_loop_mode": "none",           # none / single / list
    "play_times": 1,
    "play_speed": 1.0,
    "stop_playback_on_settings_apply": True,

    # Speech
    "speech_engine": "edge_tts",  # local_audio / edge_tts / chattts / kokoro / melotts / styletts2
    "prefer_local_media_audio": True,
    "local_media_mode": "cached_segment",  # cached_segment / direct / off
    "ffmpeg_path": r"C:\ffmpeg\ffmpeg-2026-03-30-git-e54e117998-full_build\ffmpeg-2026-03-30-git-e54e117998-full_build\bin\ffmpeg.exe",
    "online_phonetic_realtime": False,
    # Kaikki 百万级本地词典：优先用 offset index 秒级定位 JSONL 行，避免全文件扫描。
    "kaikki_enabled": True,
    "kaikki_jsonl_path": r"F:\\pythons\\aaaphrasekit\\dict\\kaikki.org-dictionary-English.jsonl",
    "kaikki_index_path": r"F:\\pythons\\aaaphrasekit\\dict\\kaikki.org-dictionary-English.jsonl.offset_index.json",
    "kaikki_index_v2_path": r"F:\\pythons\\aaaphrasekit\\dict\\kaikki.org-dictionary-English.jsonl.offset_index_v2.json",
    "word_zh_realtime": False,
    "speech_voice": "en-US-AriaNeural",
    "speech_fallback_engine": "edge_tts",
    "speech_voice_region": "en-US",
    "speech_voice_gender": "female",
    "speech_rate": 1.0,
    "speech_volume": 1.0,
    # Piper removed from UI; ChatTTS replaces its slot.
    "chattts_python_path": "",
    "chattts_script_path": "",
    "chattts_model_dir": "",
    "chattts_asset_dir": "",
    "chattts_voice": "default",
    "chattts_temperature": 0.3,
    "kokoro_model_dir": r"G:\\TTS_Models\\TTS_ModelsKokoro-82M",
    "kokoro_weight_path": r"G:\\TTS_Models\\TTS_ModelsKokoro-82M\\kokoro-v1_0.pth",
    "kokoro_config_path": r"G:\\TTS_Models\\TTS_ModelsKokoro-82M\\config.json",
    "kokoro_voices_dir": r"G:\\TTS_Models\\TTS_ModelsKokoro-82M\\voices",
    "kokoro_voice": "af_heart",
    "kokoro_voice_mode": "american_female",
    "kokoro_local_only": True,
    "kokoro_keep_alive": True,
    "kokoro_prewarm_on_start": True,
    "kokoro_daemon_timeout": 180,
    "melotts_python_path": "",
    "melotts_script_path": "",
    "melotts_model_dir": r"G:\\TTS_Models\\MeloTTS-English",
    "melotts_checkpoint_path": r"G:\\TTS_Models\\MeloTTS-English\\checkpoint.pth",
    "melotts_config_path": r"G:\\TTS_Models\\MeloTTS-English\\config.json",
    "melotts_speaker": "EN-US",

    "styletts2_python_path": r"G:\Python_Env\StyleTTS2_Env\Scripts\python.exe",
    "styletts2_model_dir": r"G:\TTS_Models\StyleTTS2\models\LibriTTS",
    "styletts2_checkpoint_path": r"G:\TTS_Models\StyleTTS2\models\LibriTTS\epochs_2nd_00020.pth",
    "styletts2_config_path": r"G:\TTS_Models\StyleTTS2\models\LibriTTS\config.yml",
    # StyleTTS2: live playback must be faster than production rendering.
    # Real-time chunks use fewer diffusion steps; production workbench can use higher quality.
    "styletts2_keep_alive": True,
    "styletts2_realtime_diffusion_steps": 4,
    "styletts2_production_diffusion_steps": 20,
    "styletts2_diffusion_steps": 4,
    "styletts2_alpha": 0.3,
    "styletts2_beta": 0.7,
    "styletts2_daemon_timeout": 300,
    # StyleTTS2 short phrases often have unstable tails if aggressively trimmed.
    "styletts2_trim_silence": False,
    "styletts2_fade_out_ms": 160,
    "styletts2_trim_pad_ms": 160,
    "styletts2_append_silence_ms": 220,
    "styletts2_normalize_peak": 0.80,

    # TTS audio cleanup: fixes short-phrase tail noise/clicks and uneven volume.
    "tts_postprocess_enabled": True,
    "tts_trim_silence": True,
    "tts_trim_threshold": 0.003,
    "tts_fade_in_ms": 8,
    "tts_fade_out_ms": 100,
    "tts_normalize_peak": 0.88,
    "tts_trim_pad_ms": 80,
    "tts_append_silence_ms": 80,

    # Translation
    "translation_engine": "auto_google_opus",  # auto_google_opus / google_online / opus_local / api_online / manual / none
    "translation_api_provider": "openai_compatible",  # openai_compatible / deepl / none
    "translation_api_base": "",
    "translation_api_key": "",
    "translation_api_model": "gpt-4o-mini",
    "auto_translate_on_import": True,
    "background_translate_missing_chinese": True,
    "opus_model_dir": r"G:\\AI_Models\\translation\\opus-mt-en-zh",

    # Production Workbench
    "production_tts_primary_engine": "kokoro",
    "production_tts_fallback_engine": "edge_tts",
    "production_make_sentence_tts": True,
    "production_make_chunk_tts": True,
    "production_make_word_tts": False,
    "production_make_word_cache": True,
    "production_tts_max_workers": 1,
    "production_translation_workers": 8,
    "production_translation_batch_size": 24,
    "production_skip_existing": True,

    # Sounds
    "typing_sound_enabled": True,
    "typing_sound_volume": 0.45,
    "sound_key": "typewriter",
    "sound_correct": "success",
    "sound_wrong": "missed_punch",
    "sound_complete": "complete_bell",
    "sound_time_warning": "off",

    "last_source": "",
    "last_index": 0,
    "last_scan_root": "",
    "scan_supported_extensions": [".txt", ".csv", ".srt", ".vtt"],
    "show_resource_library": True,
    "auto_show_resource_library_after_scan": True,
    "shortcuts": dict(DEFAULT_SHORTCUTS),
}

class Settings:
    def __init__(self) -> None:
        self.data = dict(DEFAULT_SETTINGS)
        self.data["shortcuts"] = dict(DEFAULT_SHORTCUTS)
        self.load()

    def load(self) -> None:
        if not SETTINGS_PATH.exists():
            return
        try:
            saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            if not isinstance(saved, dict):
                return
            shortcuts_saved = saved.pop("shortcuts", None)
            self.data.update(saved)
            merged = dict(DEFAULT_SHORTCUTS)
            if isinstance(shortcuts_saved, dict):
                merged.update({k: str(v) for k, v in shortcuts_saved.items()})
            self.data["shortcuts"] = merged
            # Theme/Skin migration: old English or deprecated Chinese theme names
            # should not leave the combo box blank or fall back silently.
            if self.data.get("theme") not in THEMES:
                self.data["theme"] = DEFAULT_SETTINGS.get("theme", "云青禅意")
            if self.data.get("skin") not in SKINS:
                self.data["skin"] = DEFAULT_SETTINGS.get("skin", "极简学习本")
        except Exception:
            pass

    def save(self) -> None:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, DEFAULT_SETTINGS.get(key, default))

    def set(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.save()


    def update_many(self, values: dict[str, Any]) -> None:
        self.data.update(values)
        self.save()

    def get_shortcut(self, action: str) -> str:
        shortcuts = self.data.get("shortcuts", {})
        value = ""
        if isinstance(shortcuts, dict):
            value = str(shortcuts.get(action, "")).strip()
        return value or DEFAULT_SHORTCUTS.get(action, "")

    def set_shortcut(self, action: str, key_sequence: str) -> None:
        shortcuts = dict(self.data.get("shortcuts", DEFAULT_SHORTCUTS))
        shortcuts[action] = key_sequence.strip() or DEFAULT_SHORTCUTS.get(action, "")
        self.data["shortcuts"] = shortcuts
        self.save()

    def get_all_shortcuts(self) -> dict[str, str]:
        merged = dict(DEFAULT_SHORTCUTS)
        val = self.data.get("shortcuts")
        if isinstance(val, dict):
            merged.update({k: str(v) for k, v in val.items()})
        return merged

app_settings = Settings()
