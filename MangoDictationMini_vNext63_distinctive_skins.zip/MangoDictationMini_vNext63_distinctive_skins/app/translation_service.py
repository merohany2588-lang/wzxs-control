from __future__ import annotations
from pathlib import Path
import json
import threading
from .settings import app_settings

_translator_cache = {}
_translation_cache = None
_cache_lock = threading.RLock()
ROOT = Path(__file__).resolve().parents[1]
WORD_CACHE = ROOT / "data" / "translation_cache.json"

def _load_cache() -> dict[str, str]:
    global _translation_cache
    if _translation_cache is not None:
        return _translation_cache
    try:
        if WORD_CACHE.exists():
            data = json.loads(WORD_CACHE.read_text(encoding="utf-8"))
            _translation_cache = {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}
        else:
            _translation_cache = {}
    except Exception:
        _translation_cache = {}
    return _translation_cache

def _save_cache() -> None:
    try:
        with _cache_lock:
            WORD_CACHE.parent.mkdir(parents=True, exist_ok=True)
            WORD_CACHE.write_text(json.dumps(_load_cache(), ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

def _model_dir() -> str:
    model_dir = str(app_settings.get("opus_model_dir", "") or "").strip()
    if model_dir and Path(model_dir).exists():
        return model_dir
    for alt in [r"G:\AI_Models\translation\opus-mt-en-zh", r"G:\AI_Models\translation\opus-mt-zh-en"]:
        if Path(alt).exists():
            return alt
    return model_dir

def translate_google(text: str) -> str:
    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source="en", target="zh-CN").translate(text) or ""
    except Exception:
        return ""

def translate_opus(text: str) -> str:
    model_dir = _model_dir()
    if not model_dir:
        return ""
    try:
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
        import torch
        key = str(Path(model_dir).resolve())
        if key not in _translator_cache:
            tok = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
            model = AutoModelForSeq2SeqLM.from_pretrained(model_dir, local_files_only=True)
            _translator_cache[key] = (tok, model)
        tok, model = _translator_cache[key]
        inputs = tok([text], return_tensors="pt", truncation=True, max_length=256)
        with torch.no_grad():
            out = model.generate(**inputs, max_new_tokens=160)
        return tok.decode(out[0], skip_special_tokens=True).strip()
    except Exception:
        return ""

def translate_api(text: str) -> str:
    """Optional user API translation. Supports OpenAI-compatible and DeepL.

    Nothing is hardcoded: provider/base/key/model are read from settings. If not configured,
    it returns an empty string and the caller can fall back to Google/OPUS.
    """
    provider = str(app_settings.get("translation_api_provider", "openai_compatible") or "openai_compatible")
    key = str(app_settings.get("translation_api_key", "") or "").strip()
    base = str(app_settings.get("translation_api_base", "") or "").strip().rstrip("/")
    model = str(app_settings.get("translation_api_model", "gpt-4o-mini") or "gpt-4o-mini")
    if not key or provider in {"", "none"}:
        return ""
    try:
        import requests
        if provider == "deepl":
            url = base or "https://api-free.deepl.com/v2/translate"
            r = requests.post(url, data={"auth_key": key, "text": text, "source_lang": "EN", "target_lang": "ZH"}, timeout=20)
            if r.ok:
                data = r.json()
                arr = data.get("translations") or []
                if arr:
                    return str(arr[0].get("text") or "").strip()
            return ""
        # OpenAI-compatible Chat Completions
        url = (base or "https://api.openai.com/v1") + "/chat/completions"
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Translate English subtitles into natural concise Simplified Chinese. Return translation only."},
                {"role": "user", "content": text},
            ],
            "temperature": 0.2,
        }
        r = requests.post(url, headers=headers, json=payload, timeout=30)
        if r.ok:
            data = r.json()
            return str(data.get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
    except Exception:
        return ""
    return ""


def _split_api_batch_response(text: str, expected: int) -> list[str]:
    """Parse JSON-list API batch translation response with safe fallback."""
    try:
        data = json.loads((text or "").strip())
        if isinstance(data, list):
            arr = [str(x or "").strip() for x in data]
            if len(arr) == expected:
                return arr
    except Exception:
        pass
    lines = [x.strip() for x in (text or "").splitlines() if x.strip()]
    if len(lines) == expected:
        return lines
    return []


def translate_api_batch(texts: list[str]) -> list[str]:
    provider = str(app_settings.get("translation_api_provider", "openai_compatible") or "openai_compatible")
    key = str(app_settings.get("translation_api_key", "") or "").strip()
    base = str(app_settings.get("translation_api_base", "") or "").strip().rstrip("/")
    model = str(app_settings.get("translation_api_model", "gpt-4o-mini") or "gpt-4o-mini")
    texts = [str(x or "").strip() for x in texts]
    if not key or provider in {"", "none"} or not texts:
        return []
    try:
        import requests
        if provider == "deepl":
            url = base or "https://api-free.deepl.com/v2/translate"
            data = [("text", t) for t in texts]
            data += [("auth_key", key), ("source_lang", "EN"), ("target_lang", "ZH")]
            r = requests.post(url, data=data, timeout=60)
            if r.ok:
                arr = r.json().get("translations") or []
                out = [str(x.get("text") or "").strip() for x in arr]
                if len(out) == len(texts):
                    return out
            return []
        url = (base or "https://api.openai.com/v1") + "/chat/completions"
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Translate each English subtitle line into natural concise Simplified Chinese. Return a pure JSON array of strings only. Keep the same order and same item count."},
                {"role": "user", "content": json.dumps(texts, ensure_ascii=False)},
            ],
            "temperature": 0.1,
        }
        r = requests.post(url, headers=headers, json=payload, timeout=90)
        if r.ok:
            content = str(r.json().get("choices", [{}])[0].get("message", {}).get("content", "")).strip()
            return _split_api_batch_response(content, len(texts))
    except Exception:
        return []
    return []


def translate_google_batch(texts: list[str]) -> list[str]:
    texts = [str(x or "").strip() for x in texts]
    if not texts:
        return []
    try:
        from deep_translator import GoogleTranslator
        tr = GoogleTranslator(source="en", target="zh-CN")
        if hasattr(tr, "translate_batch"):
            out = tr.translate_batch(texts) or []
            out = [str(x or "").strip() for x in out]
            if len(out) == len(texts):
                return out
    except Exception:
        return []
    return []


def translate_many(texts: list[str], engine: str | None = None, batch_size: int = 24) -> list[str]:
    """Cache-aware batch translation. Falls back to per-line translation when needed."""
    engine = engine or str(app_settings.get("translation_engine", "auto_google_opus"))
    texts = [str(x or "").strip() for x in texts]
    out = ["" for _ in texts]
    cache = _load_cache()
    missing: list[tuple[int, str]] = []
    with _cache_lock:
        for i, text in enumerate(texts):
            if not text:
                continue
            key = f"{engine}::{text.lower()}"
            if key in cache and cache[key]:
                out[i] = cache[key]
            else:
                missing.append((i, text))
    if not missing or engine in {"manual", "none"}:
        return out
    batch_size = max(1, min(100, int(batch_size or 24)))
    for start in range(0, len(missing), batch_size):
        group = missing[start:start+batch_size]
        group_texts = [x[1] for x in group]
        res: list[str] = []
        if engine == "api_online":
            res = translate_api_batch(group_texts)
        elif engine == "google_online":
            res = translate_google_batch(group_texts)
        elif engine == "api_google_opus":
            res = translate_api_batch(group_texts) or translate_google_batch(group_texts)
        elif engine == "auto_google_opus":
            res = translate_google_batch(group_texts) or translate_api_batch(group_texts)
        # OPUS local is intentionally not batched here; existing translate_text handles local model cache.
        if not res or len(res) != len(group_texts):
            res = [translate_text(t, engine) for t in group_texts]
        with _cache_lock:
            for (idx, src), zh in zip(group, res):
                zh = str(zh or "").strip()
                out[idx] = zh
                if zh:
                    cache[f"{engine}::{src.lower()}"] = zh
    _save_cache()
    return out


def translate_text(text: str, engine: str | None = None) -> str:
    text = (text or "").strip()
    if not text:
        return ""
    engine = engine or str(app_settings.get("translation_engine", "auto_google_opus"))
    cache = _load_cache()
    key = f"{engine}::{text.lower()}"
    with _cache_lock:
        if key in cache and cache[key]:
            return cache[key]
    if engine in {"manual", "none"}:
        return ""

    # Not hardcoded: order is fully controlled by engine mode from settings.
    if engine == "google_online":
        result = translate_google(text)
    elif engine == "opus_local":
        result = translate_opus(text)
    elif engine == "api_online":
        result = translate_api(text)
    elif engine == "api_google_opus":
        result = translate_api(text) or translate_google(text) or translate_opus(text)
    elif engine == "opus_google_api":
        result = translate_opus(text) or translate_google(text) or translate_api(text)
    else:  # auto_google_opus: safer for your current OPUS warning; Google first, OPUS fallback.
        result = translate_google(text) or translate_opus(text) or translate_api(text)

    if result:
        with _cache_lock:
            cache[key] = result
        _save_cache()
    return result
