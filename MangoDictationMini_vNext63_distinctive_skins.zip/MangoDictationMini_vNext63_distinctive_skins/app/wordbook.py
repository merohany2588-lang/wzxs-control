from __future__ import annotations

import csv
import json
import re
import urllib.parse
import urllib.request
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from .models import WordInfo
from .settings import app_settings

ROOT = Path(__file__).resolve().parents[1]
WORDBOOK_PATH = ROOT / "data" / "local_words.csv"
ONLINE_CACHE_PATH = ROOT / "data" / "online_phonetic_cache.json"
WORD_ZH_CACHE_PATH = ROOT / "data" / "word_zh_cache.json"
BUNDLED_KAIKKI_INDEX = ROOT / "data" / "kaikki.org-dictionary-English.jsonl.offset_index.json"

_online_cache: dict[str, dict[str, str]] | None = None
_word_zh_cache: dict[str, str] | None = None
_kaikki_index: dict[str, list[int]] | None = None
_kaikki_index_path_loaded: str = ""
_kaikki_file_handle = None
_kaikki_file_path_loaded: str = ""
_kaikki_index_format: str = "none"

WORD_KEYS = ["word", "#word", "headword", "entry", "term", "lemma", "en", "english", "单词", "词条", "英文"]
UK_KEYS = ["ipa_uk", "uk_ipa", "british_ipa", "uk_phonetic", "phonetic_uk", "英式音标", "英音"]
US_KEYS = ["ipa_us", "us_ipa", "american_ipa", "us_phonetic", "phonetic_us", "美式音标", "美音"]
PHON_KEYS = ["phonetic", "ipa", "pronunciation", "音标"]
POS_KEYS = ["pos", "part", "part_of_speech", "词性"]
ZH_KEYS = ["zh", "cn", "chinese", "translation", "meaning", "释义", "中文", "中文释义", "意思"]
DEF_KEYS = ["definition", "en_def", "english_definition", "英文释义", "英英释义"]
SYN_KEYS = ["synonyms", "syn", "近义词", "同义词"]
ANT_KEYS = ["antonyms", "ant", "反义词"]
HOMO_KEYS = ["homophones", "homophone", "同音词"]

BUILTIN = {
    "oh": WordInfo("oh", "/əʊ/", "/oʊ/", "/oʊ/", "interj.", "哦；噢", "used to express surprise or understanding", homophones="owe"),
    "yeah": WordInfo("yeah", "/jeə/", "/jeə/", "/jeə/", "adv./interj.", "是的；嗯", "informal yes"),
    "is": WordInfo("is", "/ɪz/", "/ɪz/", "/ɪz/", "v.", "是；be 的三单现在式", "third-person singular present of be"),
    "are": WordInfo("are", "/ɑː/", "/ɑːr/", "/ɑːr/", "v.", "是；be 的复数现在式", "present plural of be"),
    "was": WordInfo("was", "/wɒz/", "/wʌz/", "/wʌz/", "v.", "是；be 的过去式", "past tense of be"),
    "were": WordInfo("were", "/wɜː/", "/wɜːr/", "/wɜːr/", "v.", "是；be 的过去式", "past tense plural of be"),
    "this": WordInfo("this", "/ðɪs/", "/ðɪs/", "/ðɪs/", "det./pron.", "这个；这", "the thing near or being mentioned"),
    "that": WordInfo("that", "/ðæt/", "/ðæt/", "/ðæt/", "det./pron./conj.", "那个；那；引导从句", "used to identify a specific person or thing"),
    "gonna": WordInfo("gonna", "/ˈɡɒnə/", "/ˈɡʌnə/", "/ˈɡʌnə/", "phrase", "将要；打算", "informal going to"),
    "then": WordInfo("then", "/ðen/", "/ðen/", "/ðen/", "adv.", "然后；那么", "after that; in that case"),
    "you": WordInfo("you", "/juː/", "/juː/", "/juː/", "pron.", "你；你们", "the person or people being spoken to"),
    "you're": WordInfo("you're", "/jɔː/", "/jʊr/", "/jʊr/", "contraction", "你是；你会", "short form of you are"),
    "your": WordInfo("your", "/jɔː/", "/jʊr/", "/jʊr/", "det.", "你的；你们的", "belonging to you"),
    "have": WordInfo("have", "/hæv/", "/hæv/", "/hæv/", "v.", "有；必须；使", "to own, hold, or experience something"),
    "to": WordInfo("to", "/tuː/", "/tuː/", "/tuː/", "prep.", "向；到；为了；不定式标记", "used before a verb or destination"),
    "of": WordInfo("of", "/ɒv/", "/əv/", "/əv/", "prep.", "……的；属于", "belonging to or connected with"),
    "in": WordInfo("in", "/ɪn/", "/ɪn/", "/ɪn/", "prep.", "在……里面；在……期间", "inside or within"),
    "on": WordInfo("on", "/ɒn/", "/ɑːn/", "/ɑːn/", "prep./adv.", "在……上；关于；继续", "on the surface of"),
    "get": WordInfo("get", "/ɡet/", "/ɡet/", "/ɡet/", "v.", "得到；变得；去取", "to receive, obtain, or become"),
    "gets": WordInfo("gets", "/ɡets/", "/ɡets/", "/ɡets/", "v.", "得到；get 的三单", "third-person singular of get"),
    "yourself": WordInfo("yourself", "/jɔːˈself/", "/jʊrˈself/", "/jʊrˈself/", "pron.", "你自己", "the reflexive form of you"),
    "a": WordInfo("a", "/ə/", "/ə/", "/ə/", "art.", "一个；某个", "indefinite article"),
    "the": WordInfo("the", "/ðə/", "/ðə/", "/ðə/", "art.", "这个；那个；定冠词", "definite article"),
    "female": WordInfo("female", "/ˈfiːmeɪl/", "/ˈfiːmeɪl/", "/ˈfiːmeɪl/", "adj./n.", "女性的；女性", "relating to women or girls"),
    "partner": WordInfo("partner", "/ˈpɑːtnə/", "/ˈpɑːrtnər/", "/ˈpɑːrtnər/", "n.", "搭档；伴侣", "one of two or more people doing something together"),
    "research": WordInfo("research", "/rɪˈsɜːtʃ/", "/ˈriːsɜːrtʃ/", "/rɪˈsɜːtʃ/", "n./v.", "研究；调查", "careful study of a subject"),
    "project": WordInfo("project", "/ˈprɒdʒekt/", "/ˈprɑːdʒekt/", "/ˈprɑːdʒekt/", "n./v.", "项目；计划；投射", "a planned piece of work"),
    "name": WordInfo("name", "/neɪm/", "/neɪm/", "/neɪm/", "n./v.", "名字；命名", "a word by which a person or thing is known"),
}


COMMON_ZH = {
    "the": "这个；那个；这/那", "that": "那个；那；以至于", "my": "我的", "name": "名字；命名",
    "research": "研究", "project": "项目；计划", "of": "……的", "and": "和；并且", "or": "或者",
    "but": "但是", "not": "不", "no": "不；没有", "yes": "是的", "very": "非常", "really": "真的；非常",
    "what": "什么", "why": "为什么", "how": "怎样；如何", "where": "哪里", "when": "什么时候",
    "who": "谁", "which": "哪一个", "make": "制作；使得", "take": "拿；带；花费", "go": "去", "come": "来",
    "see": "看见", "look": "看", "say": "说", "tell": "告诉", "think": "认为；想", "know": "知道",
    "good": "好的", "bad": "坏的", "right": "正确；右边", "wrong": "错误的", "people": "人们",
    "man": "男人", "woman": "女人", "thing": "事情；东西", "because": "因为", "about": "关于；大约",
}

_cache: dict[str, WordInfo] = {}
_loaded = False


def _clean(s: Any) -> str:
    return str(s or "").replace("\ufeff", "").strip()


def _norm_key(s: str) -> str:
    s = _clean(s).lower()
    s = s.replace("’", "'").replace("`", "'").replace("´", "'").replace("ʹ", "'")
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"^[^a-z0-9']+|[^a-z0-9']+$", "", s)
    return s.strip(" .,!?;:，。！？；：\"'()[]{}“”‘’—–-…")


def _first(row: dict[str, Any], keys: list[str]) -> str:
    low = {str(k).strip().lower(): k for k in row.keys()}
    for k in keys:
        real = low.get(k.lower())
        if real is not None:
            v = _clean(row.get(real, ""))
            if v:
                return v
    return ""


def _read_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk"):
        try:
            text = path.read_text(encoding=enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    if not lines:
        return []
    delim = "\t" if "\t" in lines[0] and lines[0].count("\t") >= lines[0].count(",") else ","
    try:
        return [dict(r) for r in csv.DictReader(lines, delimiter=delim)]
    except Exception:
        return []


def reload_wordbook() -> None:
    try:
        lookup_word.cache_clear()
    except Exception:
        pass
    global _loaded, _kaikki_index, _kaikki_index_path_loaded, _kaikki_file_handle, _kaikki_file_path_loaded, _kaikki_index_format
    _cache.clear()
    _loaded = False
    _kaikki_index = None
    _kaikki_index_path_loaded = ""
    _kaikki_index_format = "none"
    try:
        if _kaikki_file_handle:
            _kaikki_file_handle.close()
    except Exception:
        pass
    _kaikki_file_handle = None
    _kaikki_file_path_loaded = ""
    _load()


def _load() -> None:
    global _loaded
    if _loaded:
        return
    _loaded = True
    _cache.update({k: v for k, v in BUILTIN.items()})
    for _w, _zh in COMMON_ZH.items():
        if _w not in _cache:
            _cache[_w] = WordInfo(word=_w, zh=_zh, source="builtin_zh")
        elif not _cache[_w].zh:
            _cache[_w].zh = _zh
    for row in _read_rows(WORDBOOK_PATH):
        word = _first(row, WORD_KEYS)
        if not word:
            continue
        phon = _first(row, PHON_KEYS)
        info = WordInfo(
            word=word,
            ipa_uk=_first(row, UK_KEYS) or phon,
            ipa_us=_first(row, US_KEYS) or phon,
            phonetic=phon,
            pos=_first(row, POS_KEYS),
            zh=_first(row, ZH_KEYS),
            en_def=_first(row, DEF_KEYS),
            synonyms=_first(row, SYN_KEYS),
            antonyms=_first(row, ANT_KEYS),
            homophones=_first(row, HOMO_KEYS),
            source="local_csv",
        )
        key = _norm_key(word)
        old = _cache.get(key)
        _cache[key] = _merge_wordinfo(old, info) if old else info


def _merge_wordinfo(base: WordInfo | None, extra: WordInfo | None) -> WordInfo | None:
    if not base:
        return extra
    if not extra:
        return base
    for f in base.__dataclass_fields__:
        if f == "word":
            continue
        if not getattr(base, f) and getattr(extra, f):
            setattr(base, f, getattr(extra, f))
    if extra.source and extra.source not in (base.source or ""):
        base.source = (base.source + "+" + extra.source).strip("+")
    return base


def _has_ipa(info: WordInfo | None) -> bool:
    return bool(info and (info.ipa_uk or info.ipa_us or info.phonetic))


def _has_learning_data(info: WordInfo | None) -> bool:
    if not info:
        return False
    return any([info.ipa_uk, info.ipa_us, info.phonetic, info.pos, info.zh, info.en_def, info.synonyms, info.antonyms, info.homophones])


def _candidates(word: str) -> list[str]:
    k = _norm_key(word)
    out = [k]
    if not k:
        return []
    # contractions / curly apostrophes already normalized
    if k.endswith("ies") and len(k) > 4:
        out.append(k[:-3] + "y")
    if k.endswith("ied") and len(k) > 4:
        out.append(k[:-3] + "y")
    if k.endswith("ves") and len(k) > 4:
        out.extend([k[:-3] + "f", k[:-3] + "fe"])
    if k.endswith("ing") and len(k) > 5:
        stem = k[:-3]
        out.extend([stem, stem + "e"])
        if len(stem) > 2 and stem[-1] == stem[-2]:
            out.append(stem[:-1])
    if k.endswith("ed") and len(k) > 4:
        stem = k[:-2]
        out.extend([stem, stem + "e"])
        if len(stem) > 2 and stem[-1] == stem[-2]:
            out.append(stem[:-1])
    if k.endswith("es") and len(k) > 3:
        out.append(k[:-2])
    if k.endswith("s") and len(k) > 3:
        out.append(k[:-1])
    return list(dict.fromkeys([x for x in out if x]))


def _load_online_cache() -> dict[str, dict[str, str]]:
    global _online_cache
    if _online_cache is not None:
        return _online_cache
    try:
        if ONLINE_CACHE_PATH.exists():
            data = json.loads(ONLINE_CACHE_PATH.read_text(encoding="utf-8"))
            _online_cache = {str(k): dict(v) for k, v in data.items() if isinstance(v, dict)} if isinstance(data, dict) else {}
        else:
            _online_cache = {}
    except Exception:
        _online_cache = {}
    return _online_cache


def _save_online_cache() -> None:
    try:
        ONLINE_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        ONLINE_CACHE_PATH.write_text(json.dumps(_load_online_cache(), ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _load_word_zh_cache() -> dict[str, str]:
    global _word_zh_cache
    if _word_zh_cache is not None:
        return _word_zh_cache
    try:
        if WORD_ZH_CACHE_PATH.exists():
            data = json.loads(WORD_ZH_CACHE_PATH.read_text(encoding="utf-8"))
            _word_zh_cache = {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}
        else:
            _word_zh_cache = {}
    except Exception:
        _word_zh_cache = {}
    return _word_zh_cache


def _fill_word_zh(word: str, info: WordInfo | None) -> WordInfo | None:
    if not word:
        return info
    key = _norm_key(word)
    cache = _load_word_zh_cache()
    if not info:
        info = WordInfo(word=word)
    if info.zh:
        cache[key] = info.zh
        return info
    if key in cache and cache[key]:
        info.zh = cache[key]
        return info
    # Do NOT call OPUS/Google during training by default. That was a major input-lag source.
    if not bool(app_settings.get("word_zh_realtime", False)):
        return info
    if " " in key or len(key) > 32:
        return info
    try:
        from .translation_service import translate_text
        zh = translate_text(word)
    except Exception:
        zh = ""
    if zh:
        info.zh = zh
        cache[key] = zh
        try:
            WORD_ZH_CACHE_PATH.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    return info


def _path_from_setting(key: str) -> Path | None:
    val = str(app_settings.get(key, "") or "").strip()
    if not val:
        return None
    try:
        return Path(val)
    except Exception:
        return None


def _kaikki_jsonl_path() -> Path | None:
    p = _path_from_setting("kaikki_jsonl_path")
    if p and p.exists():
        return p
    for alt in [ROOT / "dict" / "kaikki.org-dictionary-English.jsonl", ROOT / "data" / "kaikki.org-dictionary-English.jsonl"]:
        if alt.exists():
            return alt
    return None


def _kaikki_index_path(jsonl_path: Path | None) -> Path | None:
    # Prefer v2 multi-offset index. v1 single-offset index caused many common words to point at entries without IPA.
    v2 = _path_from_setting("kaikki_index_v2_path")
    if v2 and v2.exists():
        return v2
    if jsonl_path:
        beside_v2 = Path(str(jsonl_path) + ".offset_index_v2.json")
        if beside_v2.exists():
            return beside_v2
    p = _path_from_setting("kaikki_index_path")
    if p and p.exists():
        return p
    if jsonl_path:
        beside = Path(str(jsonl_path) + ".offset_index.json")
        if beside.exists():
            return beside
    if BUNDLED_KAIKKI_INDEX.exists():
        return BUNDLED_KAIKKI_INDEX
    return None


def _load_kaikki_index() -> dict[str, list[int]] | None:
    global _kaikki_index, _kaikki_index_path_loaded, _kaikki_index_format
    if not bool(app_settings.get("kaikki_enabled", True)):
        return None
    jsonl = _kaikki_jsonl_path()
    idx_path = _kaikki_index_path(jsonl)
    if not jsonl or not idx_path:
        return None
    key = str(idx_path.resolve())
    if _kaikki_index is not None and _kaikki_index_path_loaded == key:
        return _kaikki_index
    try:
        data = json.loads(idx_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        if isinstance(data.get("words"), dict):
            words = data["words"]
            _kaikki_index_format = "v2_multi_offset"
        else:
            words = data
            _kaikki_index_format = "v1_single_offset"
        out: dict[str, list[int]] = {}
        for k, v in words.items():
            kk = str(k).lower()
            if isinstance(v, list):
                vals = []
                for x in v[:64]:
                    try:
                        vals.append(int(x))
                    except Exception:
                        pass
                if vals:
                    out[kk] = vals
            else:
                try:
                    out[kk] = [int(v)]
                except Exception:
                    pass
        _kaikki_index = out
        _kaikki_index_path_loaded = key
        return _kaikki_index
    except Exception:
        return None


def _kaikki_file():
    global _kaikki_file_handle, _kaikki_file_path_loaded
    p = _kaikki_jsonl_path()
    if not p:
        return None
    key = str(p.resolve())
    if _kaikki_file_handle is not None and _kaikki_file_path_loaded == key:
        return _kaikki_file_handle
    try:
        if _kaikki_file_handle:
            _kaikki_file_handle.close()
    except Exception:
        pass
    try:
        _kaikki_file_handle = open(p, "rb")
        _kaikki_file_path_loaded = key
        return _kaikki_file_handle
    except Exception:
        _kaikki_file_handle = None
        _kaikki_file_path_loaded = ""
        return None


def _list_words(items: Any, limit: int = 8) -> str:
    words: list[str] = []
    if isinstance(items, list):
        for x in items:
            if isinstance(x, dict):
                w = _clean(x.get("word") or x.get("english") or x.get("text") or "")
            else:
                w = _clean(x)
            if w and w not in words:
                words.append(w)
            if len(words) >= limit:
                break
    return ", ".join(words)


def _extract_kaikki_info(data: dict[str, Any], query: str) -> WordInfo:
    word = _clean(data.get("word") or query)
    pos = _clean(data.get("pos") or "")
    ipa_any = ""
    ipa_uk = ""
    ipa_us = ""
    homophones: list[str] = []

    for snd in data.get("sounds", []) or []:
        if not isinstance(snd, dict):
            continue
        ipa = _clean(snd.get("ipa") or snd.get("enpr") or snd.get("pronunciation") or "")
        tags = " ".join(str(t).lower() for t in (snd.get("tags") or []))
        if ipa:
            ipa_any = ipa_any or ipa
            if any(x in tags for x in ["uk", "britain", "british", "received", "rp"]):
                ipa_uk = ipa_uk or ipa
            elif any(x in tags for x in ["us", "america", "american", "genam"]):
                ipa_us = ipa_us or ipa
        h = snd.get("homophones")
        if isinstance(h, list):
            for item in h:
                hw = _clean(item.get("word") if isinstance(item, dict) else item)
                if hw and hw not in homophones:
                    homophones.append(hw)

    en_def = ""
    synonyms: list[str] = []
    antonyms: list[str] = []
    for sense in data.get("senses", []) or []:
        if not isinstance(sense, dict):
            continue
        if not en_def:
            glosses = sense.get("glosses") or sense.get("raw_glosses") or []
            if isinstance(glosses, list) and glosses:
                en_def = _clean(glosses[0])
        syn = _list_words(sense.get("synonyms"), 10)
        ant = _list_words(sense.get("antonyms"), 10)
        if syn:
            synonyms += [x.strip() for x in syn.split(",") if x.strip()]
        if ant:
            antonyms += [x.strip() for x in ant.split(",") if x.strip()]
    top_syn = _list_words(data.get("synonyms"), 10)
    top_ant = _list_words(data.get("antonyms"), 10)
    if top_syn:
        synonyms += [x.strip() for x in top_syn.split(",") if x.strip()]
    if top_ant:
        antonyms += [x.strip() for x in top_ant.split(",") if x.strip()]

    return WordInfo(
        word=word,
        ipa_uk=ipa_uk or ipa_any,
        ipa_us=ipa_us or ipa_any,
        phonetic=ipa_any or ipa_uk or ipa_us,
        pos=pos,
        zh="",
        en_def=en_def,
        synonyms=", ".join(list(dict.fromkeys(synonyms))[:10]),
        antonyms=", ".join(list(dict.fromkeys(antonyms))[:10]),
        homophones=", ".join(homophones[:10]),
        source="kaikki",
    )


def _read_kaikki_entry(f, off: int) -> dict[str, Any] | None:
    try:
        f.seek(int(off))
        line = f.readline()
        if not line:
            return None
        data = json.loads(line)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _lookup_kaikki(word: str) -> WordInfo | None:
    idx = _load_kaikki_index()
    if not idx:
        return None
    f = _kaikki_file()
    if not f:
        return None
    best: WordInfo | None = None
    for c in _candidates(word):
        offsets = idx.get(c) or []
        # v2 can have many entries. Read enough to find an IPA-bearing one, then merge definitions/pos.
        for off in offsets[:48]:
            data = _read_kaikki_entry(f, off)
            if not data:
                continue
            info = _extract_kaikki_info(data, c)
            if not _has_learning_data(info):
                continue
            best = _merge_wordinfo(best, info)
            if _has_ipa(best) and best.en_def and best.pos:
                return best
        if best and _has_ipa(best):
            return best
    return best


def _online_lookup(word: str) -> WordInfo | None:
    key = _norm_key(word)
    if not key or len(key) > 50 or " " in key:
        return None
    cache = _load_online_cache()
    if key in cache:
        v = cache[key]
        return WordInfo(
            word=v.get("word", word), ipa_uk=v.get("ipa_uk", ""), ipa_us=v.get("ipa_us", ""), phonetic=v.get("phonetic", ""),
            pos=v.get("pos", ""), zh=v.get("zh", ""), en_def=v.get("en_def", ""), synonyms=v.get("synonyms", ""), antonyms=v.get("antonyms", ""), homophones=v.get("homophones", ""), source="online_cache")
    if not bool(app_settings.get("online_phonetic_realtime", False)):
        return None
    try:
        url = "https://api.dictionaryapi.dev/api/v2/entries/en/" + urllib.parse.quote(key)
        req = urllib.request.Request(url, headers={"User-Agent": "MangoDictationMini/1.0"})
        with urllib.request.urlopen(req, timeout=1.8) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        if not isinstance(data, list) or not data:
            return None
        entry = data[0]
        phonetic = uk = us = ""
        for ph in entry.get("phonetics", []) or []:
            txt = str(ph.get("text", "") or "").strip()
            if not txt:
                continue
            audio = str(ph.get("audio", "") or "").lower()
            if "uk" in audio or "gb" in audio:
                uk = uk or txt
            elif "us" in audio:
                us = us or txt
            phonetic = phonetic or txt
        pos = definition = synonyms = antonyms = ""
        for meaning in entry.get("meanings", []) or []:
            pos = pos or str(meaning.get("partOfSpeech", "") or "")
            synonyms = synonyms or ", ".join(str(x) for x in (meaning.get("synonyms") or [])[:8])
            antonyms = antonyms or ", ".join(str(x) for x in (meaning.get("antonyms") or [])[:8])
            defs = meaning.get("definitions", []) or []
            if defs:
                definition = definition or str(defs[0].get("definition", "") or "")
            if pos and definition:
                break
        if not (phonetic or uk or us or definition or pos):
            return None
        raw = {"word": str(entry.get("word", word)), "ipa_uk": uk or phonetic, "ipa_us": us or phonetic, "phonetic": phonetic or uk or us, "pos": pos, "zh": "", "en_def": definition, "synonyms": synonyms, "antonyms": antonyms, "homophones": ""}
        cache[key] = raw
        _save_online_cache()
        return WordInfo(**raw, source="online")
    except Exception:
        return None


@lru_cache(maxsize=20000)
def lookup_word(word: str) -> WordInfo | None:
    _load()
    word = (word or "").strip()
    local_info: WordInfo | None = None
    for c in _candidates(word):
        if c in _cache:
            local_info = _cache[c]
            break
    kinfo = _lookup_kaikki(word)
    if local_info:
        merged = _merge_wordinfo(local_info, kinfo)
    elif kinfo:
        merged = kinfo
    else:
        merged = _online_lookup(word)
    return _fill_word_zh(word, merged)


def split_words(text: str) -> list[str]:
    return re.findall(r"[A-Za-z]+(?:['’`´][A-Za-z]+)?|\d+(?:\.\d+)?", str(text or ""))


def get_chunk_infos(words: list[str]) -> list[tuple[str, WordInfo | None]]:
    out: list[tuple[str, WordInfo | None]] = []
    for item in words:
        tokens = split_words(item) or [str(item or "")]
        for t in tokens:
            out.append((t, lookup_word(t)))
    return out


def lookup_sentence_words(text: str) -> dict[str, WordInfo | None]:
    return {w: lookup_word(w) for w in split_words(text)}


def diagnose_kaikki_words(words: Iterable[str] | None = None) -> str:
    words = list(words or ["the", "that", "research", "name", "project", "admitted", "deceiving", "masters", "you're", "female", "partner"])
    jsonl = _kaikki_jsonl_path()
    idx_path = _kaikki_index_path(jsonl)
    idx = _load_kaikki_index()
    f = _kaikki_file()
    lines = []
    lines.append("Kaikki dictionary diagnosis")
    lines.append(f"JSONL: {jsonl} | exists={bool(jsonl and jsonl.exists())}")
    lines.append(f"Index: {idx_path} | exists={bool(idx_path and idx_path.exists())}")
    lines.append(f"Index format: {_kaikki_index_format}; words={len(idx) if idx else 0}")
    lines.append("NOTE: v1_single_offset is expected to miss many IPA entries. Build v2 multi-offset index if shown here.")
    lines.append("")
    for w in words:
        cands = _candidates(w)
        hit = []
        if idx:
            for c in cands:
                hit.extend(idx.get(c) or [])
        info = lookup_word(w)
        ipa = (info.ipa_uk or info.ipa_us or info.phonetic) if info else ""
        lines.append(f"{w:14s} clean={cands[:4]} offsets={len(hit)} ipa={ipa or '?'} pos={(info.pos if info else '')} src={(info.source if info else '')}")
        if f and hit:
            sample = []
            for off in hit[:5]:
                data = _read_kaikki_entry(f, off)
                if isinstance(data, dict):
                    has_ipa = any(isinstance(s, dict) and (s.get('ipa') or s.get('enpr')) for s in (data.get('sounds') or []))
                    sample.append(f"{off}:{data.get('pos','?')}:ipa={has_ipa}")
            if sample:
                lines.append("  entries: " + "; ".join(sample))
    return "\n".join(lines)


def build_kaikki_index_v2(jsonl_path: str | Path | None = None, output_path: str | Path | None = None, max_offsets_per_word: int = 64, progress_callback=None) -> Path:
    jsonl = Path(jsonl_path) if jsonl_path else _kaikki_jsonl_path()
    if not jsonl or not jsonl.exists():
        raise FileNotFoundError("Kaikki JSONL not found")
    out_path = Path(output_path) if output_path else Path(str(jsonl) + ".offset_index_v2.json")
    index: dict[str, list[int]] = {}
    with open(jsonl, "rb") as f:
        offset = 0
        count = 0
        for line in f:
            try:
                data = json.loads(line)
                word = _norm_key(data.get("word", "")) if isinstance(data, dict) else ""
                if word:
                    sounds = data.get("sounds") or []
                    has_ipa = any(isinstance(s, dict) and (s.get("ipa") or s.get("enpr")) for s in sounds)
                    arr = index.setdefault(word, [])
                    if len(arr) < max_offsets_per_word:
                        if has_ipa:
                            arr.insert(0, offset)
                        else:
                            arr.append(offset)
                count += 1
                if progress_callback and count % 50000 == 0:
                    progress_callback(count, len(index))
            except Exception:
                pass
            offset += len(line)
    payload = {"_meta": {"format": "kaikki_offset_index_v2", "jsonl": str(jsonl), "max_offsets_per_word": max_offsets_per_word, "words": len(index)}, "words": index}
    out_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return out_path
