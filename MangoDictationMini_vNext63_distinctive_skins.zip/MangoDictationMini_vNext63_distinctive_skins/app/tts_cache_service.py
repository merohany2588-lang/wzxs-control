from __future__ import annotations

import asyncio
import hashlib
import json
import os
import subprocess
import traceback
from pathlib import Path
from typing import Callable, Optional
import threading
import queue
import sys

from .settings import app_settings

LogFn = Optional[Callable[[str], None]]


def safe_name(text: str, max_len: int = 48) -> str:
    import re
    s = re.sub(r"[^A-Za-z0-9_\-]+", "_", (text or "").strip().lower())
    return (s[:max_len].strip("_") or "item")


def text_hash(text: str, engine: str, voice: str, rate: float = 1.0) -> str:
    raw = f"{engine}|{voice}|{rate}|{text}".encode("utf-8")
    return hashlib.md5(raw).hexdigest()


async def _edge_save_async(text: str, out_path: Path, voice: str, rate_percent: int = 0, volume_percent: int = 0) -> None:
    import edge_tts
    rate = f"{int(rate_percent):+d}%"
    volume = f"{int(volume_percent):+d}%"
    communicate = edge_tts.Communicate(text=text, voice=voice or "en-US-AriaNeural", rate=rate, volume=volume)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    await communicate.save(str(out_path))


def synthesize_edge(text: str, out_path: Path, voice: str, rate: float = 1.0, volume: float = 1.0, log: LogFn = None) -> bool:
    try:
        pct = int((float(rate) - 1.0) * 100)
        vol_pct = int((float(volume) - 1.0) * 100)
        asyncio.run(_edge_save_async(text, out_path, voice or str(app_settings.get("speech_voice", "en-US-AriaNeural")), pct, vol_pct))
        return out_path.exists() and out_path.stat().st_size > 100
    except Exception as e:
        if log:
            log(f"Edge-TTS failed: {e}")
        return False


def _kokoro_paths() -> tuple[Path, Path, Path, str]:
    model_dir = Path(str(app_settings.get("kokoro_model_dir", "") or ""))
    weight_path = Path(str(app_settings.get("kokoro_weight_path", "") or ""))
    voices_dir = Path(str(app_settings.get("kokoro_voices_dir", "") or ""))
    voice_name = str(app_settings.get("kokoro_voice", "af_heart") or "af_heart").strip() or "af_heart"
    if not weight_path.exists() and model_dir.exists():
        cand = model_dir / "kokoro-v1_0.pth"
        if cand.exists():
            weight_path = cand
    if not voices_dir.exists() and model_dir.exists():
        cand = model_dir / "voices"
        if cand.exists():
            voices_dir = cand
    return model_dir, weight_path, voices_dir, voice_name


def _write_tts_debug(name: str, content: str) -> None:
    try:
        path = Path(__file__).resolve().parents[1] / "data" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    except Exception:
        pass

def _postprocess_settings() -> dict:
    return {
        "enabled": bool(app_settings.get("tts_postprocess_enabled", True)),
        "trim": bool(app_settings.get("tts_trim_silence", True)),
        "trim_threshold": float(app_settings.get("tts_trim_threshold", 0.004) or 0.004),
        "fade_in_ms": int(app_settings.get("tts_fade_in_ms", 8) or 8),
        "fade_out_ms": int(app_settings.get("tts_fade_out_ms", 100) or 100),
        "normalize_peak": float(app_settings.get("tts_normalize_peak", 0.88) or 0.88),
        "trim_pad_ms": int(app_settings.get("tts_trim_pad_ms", 80) or 80),
        "append_silence_ms": int(app_settings.get("tts_append_silence_ms", 80) or 80),
    }


def _styletts2_postprocess_settings() -> dict:
    """StyleTTS2 needs a softer tail policy than generic TTS.

    The previous generic trim could cut the end of very short phrases and create
    a clipped/zi-zi tail.  For StyleTTS2 live chunks we preserve the tail, fade it
    more gradually, and append a short silence buffer.
    """
    base = _postprocess_settings()
    base.update({
        "trim": bool(app_settings.get("styletts2_trim_silence", False)),
        "fade_out_ms": int(app_settings.get("styletts2_fade_out_ms", 160) or 160),
        "normalize_peak": float(app_settings.get("styletts2_normalize_peak", 0.80) or 0.80),
        "trim_pad_ms": int(app_settings.get("styletts2_trim_pad_ms", 160) or 160),
        "append_silence_ms": int(app_settings.get("styletts2_append_silence_ms", 220) or 220),
    })
    return base


def _postprocess_wav_file(path: Path, log: LogFn = None) -> bool:
    """Trim silence, normalize, and fade out short TTS clips to remove tail clicks/noise.

    This intentionally only processes WAV/PCM-like files. MP3 from Edge-TTS is left
    untouched to avoid slow ffmpeg conversions during live practice.
    """
    cfg = _postprocess_settings()
    if not cfg["enabled"]:
        return True
    try:
        if not path.exists() or path.suffix.lower() not in {".wav", ".flac", ".ogg"}:
            return True
        import numpy as np
        import soundfile as sf
        data, sr = sf.read(str(path), dtype="float32", always_2d=False)
        x = np.asarray(data, dtype="float32")
        if x.ndim > 1:
            x = x.mean(axis=1).astype("float32")
        if x.size == 0:
            return True
        if cfg["trim"]:
            y = np.abs(x)
            idx = np.where(y > cfg["trim_threshold"])[0]
            if idx.size:
                pad = int(max(0.025, cfg.get("trim_pad_ms", 80) / 1000.0) * sr)
                start = max(0, int(idx[0]) - pad)
                end = min(x.size, int(idx[-1]) + pad)
                if end > start:
                    x = x[start:end]
        if x.size == 0:
            return True
        fade_in = min(int(sr * max(0, cfg["fade_in_ms"]) / 1000), max(0, x.size // 3))
        fade_out = min(int(sr * max(0, cfg["fade_out_ms"]) / 1000), max(0, x.size // 2))
        if fade_in > 1:
            x[:fade_in] *= np.linspace(0.0, 1.0, fade_in, dtype="float32")
        if fade_out > 1:
            x[-fade_out:] *= np.linspace(1.0, 0.0, fade_out, dtype="float32")
        append_silence = min(int(sr * max(0, cfg.get("append_silence_ms", 0)) / 1000), sr)
        if append_silence > 0:
            x = np.concatenate([x, np.zeros(append_silence, dtype="float32")])
        mx = float(np.max(np.abs(x))) if x.size else 0.0
        peak = cfg["normalize_peak"]
        if mx > 1e-6 and peak > 0:
            x = x * min(float(peak) / mx, 10.0)
        x = np.clip(x, -1.0, 1.0).astype("float32")
        sf.write(str(path), x, sr)
        if log:
            log(f"postprocess_ok={path.name} fade_out_ms={cfg['fade_out_ms']} trim={cfg['trim']} pad_ms={cfg.get('trim_pad_ms')} append_silence_ms={cfg.get('append_silence_ms')}")
        return True
    except Exception as e:
        if log:
            log(f"postprocess_failed={e}")
        return False


def _find_hf_cached_kokoro_config() -> Path | None:
    """Find config.json already downloaded by Hugging Face cache, without network."""
    home = Path.home()
    candidates = []
    for base in [
        home / ".cache" / "huggingface" / "hub" / "models--hexgrad--Kokoro-82M" / "snapshots",
        home / ".cache" / "huggingface" / "hub" / "models--hexgrad--Kokoro-82M-v1.1-zh" / "snapshots",
    ]:
        if base.exists():
            candidates.extend(base.glob("*/config.json"))
    for c in candidates:
        try:
            if c.exists() and c.stat().st_size > 50:
                return c
        except Exception:
            pass
    return None


def _kokoro_config_path(model_dir: Path) -> Path | None:
    raw = str(app_settings.get("kokoro_config_path", "") or "").strip()
    if raw and Path(raw).exists():
        return Path(raw)
    if model_dir.exists():
        for name in ["config.json", "kokoro_config.json"]:
            c = model_dir / name
            if c.exists():
                return c
    return _find_hf_cached_kokoro_config()


def _kokoro_lang_code(voice_name: str) -> str:
    v = (voice_name or "af_heart").lower()
    # Kokoro official language codes: a=American English, b=British English.
    if v.startswith("bf_") or v.startswith("bm_"):
        return "b"
    if v.startswith("af_") or v.startswith("am_"):
        return "a"
    # fallback from UI region
    region = str(app_settings.get("speech_voice_region", "en-US") or "en-US").lower()
    return "b" if "gb" in region or "uk" in region else "a"



_KOKORO_DAEMON_PROC = None
_KOKORO_DAEMON_LOCK = threading.Lock()
_KOKORO_DAEMON_STDERR = None


def _readline_with_timeout(pipe, timeout: float = 180.0):
    q: queue.Queue[str | None] = queue.Queue(maxsize=1)
    def reader():
        try:
            q.put(pipe.readline())
        except Exception:
            q.put(None)
    t = threading.Thread(target=reader, daemon=True)
    t.start()
    try:
        return q.get(timeout=timeout)
    except queue.Empty:
        return None


def _kokoro_daemon_stop() -> None:
    global _KOKORO_DAEMON_PROC, _KOKORO_DAEMON_STDERR
    with _KOKORO_DAEMON_LOCK:
        try:
            if _KOKORO_DAEMON_PROC and _KOKORO_DAEMON_PROC.poll() is None:
                _KOKORO_DAEMON_PROC.terminate()
        except Exception:
            pass
        _KOKORO_DAEMON_PROC = None
        try:
            if _KOKORO_DAEMON_STDERR:
                _KOKORO_DAEMON_STDERR.close()
        except Exception:
            pass
        _KOKORO_DAEMON_STDERR = None


def _kokoro_daemon_ensure(data_dir: Path, log: LogFn = None):
    global _KOKORO_DAEMON_PROC, _KOKORO_DAEMON_STDERR
    if _KOKORO_DAEMON_PROC is not None and _KOKORO_DAEMON_PROC.poll() is None:
        return _KOKORO_DAEMON_PROC
    worker = Path(__file__).resolve().parent / "kokoro_daemon_worker.py"
    if not worker.exists():
        return None
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    data_dir.mkdir(parents=True, exist_ok=True)
    err_path = data_dir / "kokoro_daemon_stderr.log"
    _KOKORO_DAEMON_STDERR = err_path.open("a", encoding="utf-8", errors="replace")
    cmd = [sys.executable, str(worker), "--data-dir", str(data_dir)]
    if log:
        log("start_kokoro_daemon=" + " ".join(cmd))
    _KOKORO_DAEMON_PROC = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=_KOKORO_DAEMON_STDERR,
        text=True,
        bufsize=1,
        creationflags=flags,
    )
    return _KOKORO_DAEMON_PROC


def _try_kokoro_daemon(text: str, out_path: Path, voice: str, rate: float, volume: float, log: LogFn = None) -> bool:
    """Persistent Kokoro worker. First call is model warm-up; following calls avoid
    Python+Torch+KPipeline cold start and should be much faster.
    """
    if not bool(app_settings.get("kokoro_keep_alive", True)):
        return False
    data_dir = Path(__file__).resolve().parents[1] / "data"
    model_dir, weight_path, voices_dir, default_voice = _kokoro_paths()
    voice_name = (voice or default_voice or "af_heart").strip().replace(".pt", "")
    voice_file = voices_dir / f"{voice_name}.pt"
    lines = [
        "requested_engine=kokoro",
        "call_style=persistent_daemon_KPipeline_voice_name",
        f"model_dir={model_dir}",
        f"weight_path={weight_path} exists={weight_path.exists()}",
        f"voices_dir={voices_dir} exists={voices_dir.exists()}",
        f"voice_name={voice_name}",
        f"voice_path={voice_file} exists={voice_file.exists()}",
        f"output={out_path}",
    ]
    if not voice_file.exists():
        lines.append("FAIL: selected local voice .pt missing")
        _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
        return False
    req = {
        "text": text,
        "output": str(out_path),
        "model_dir": str(model_dir),
        "weight_path": str(weight_path),
        "voices_dir": str(voices_dir),
        "voice_name": voice_name,
        "rate": float(rate),
        "volume": float(volume),
        "region": str(app_settings.get("speech_voice_region", "en-US") or "en-US"),
        "lang_code": _kokoro_lang_code(voice_name),
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with _KOKORO_DAEMON_LOCK:
        try:
            proc = _kokoro_daemon_ensure(data_dir, log)
            if not proc or not proc.stdin or not proc.stdout:
                lines.append("FAIL: daemon not available")
                _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
                return False
            proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
            proc.stdin.flush()
            line = _readline_with_timeout(proc.stdout, timeout=float(app_settings.get("kokoro_daemon_timeout", 180)))
            if not line:
                lines.append("FAIL: daemon timeout/no response")
                _kokoro_daemon_stop()
                _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
                return False
            lines.append("response=" + line.strip())
            try:
                resp = json.loads(line)
            except Exception:
                # Skip non-json noise if library printed to stdout. Try a few more lines.
                resp = None
                for _ in range(8):
                    line2 = _readline_with_timeout(proc.stdout, timeout=5)
                    if not line2:
                        break
                    lines.append("response_extra=" + line2.strip())
                    try:
                        resp = json.loads(line2)
                        break
                    except Exception:
                        continue
                if resp is None:
                    lines.append("FAIL: no json response from daemon")
                    _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
                    return False
            ok = bool(resp.get("ok")) and out_path.exists() and out_path.stat().st_size > 100
            lines.append(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
            _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
            return ok
        except Exception as e:
            lines.append("EXCEPTION: " + repr(e))
            lines.append(traceback.format_exc())
            _kokoro_daemon_stop()
            _write_tts_debug("kokoro_last_error.log", "\n".join(lines))
            return False


def prewarm_kokoro(log: LogFn = None) -> None:
    """Warm the persistent Kokoro daemon without touching the UI thread."""
    if not bool(app_settings.get("kokoro_keep_alive", True)):
        return
    try:
        data_dir = Path(__file__).resolve().parents[1] / "data"
        out_dir = Path(__file__).resolve().parents[1] / "cache" / "tts" / "kokoro" / "_prewarm"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / "prewarm.wav"
        _try_kokoro_daemon("OK.", out, str(app_settings.get("kokoro_voice", "af_heart") or "af_heart"), 1.0, 1.0, log)
    except Exception:
        pass

def _try_kokoro_pipeline(text: str, out_path: Path, voice: str, rate: float, volume: float, log: LogFn = None) -> bool:
    """Kokoro adapter fixed from user's proven working script.

    Important: the user's successful test_kokoro.py uses:
        pipeline = KPipeline(lang_code='a')
        generator = pipeline(text, voice=voice_name, speed=speed)

    It does NOT manually pass KModel(model=pth) or voice_path. The previous adapter
    over-bound KModel/voice_path and could route/crash incorrectly. This function now
    runs that proven call style in a subprocess, so Torch/Kokoro native failures do
    not kill the Qt GUI process.
    """
    debug_lines: list[str] = []
    def dbg(msg: str):
        debug_lines.append(str(msg))
        if log:
            log(str(msg))

    model_dir, weight_path, voices_dir, default_voice = _kokoro_paths()
    voice_name = (voice or default_voice or "af_heart").strip().replace(".pt", "")
    voice_file = voices_dir / f"{voice_name}.pt"
    data_dir = Path(__file__).resolve().parents[1] / "data"
    req_dir = data_dir / "tmp"
    req_dir.mkdir(parents=True, exist_ok=True)
    req_path = req_dir / ("kokoro_request_" + hashlib.md5(f"{text}|{voice_name}|{rate}".encode('utf-8')).hexdigest() + ".json")
    worker = Path(__file__).resolve().parent / "kokoro_worker.py"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    dbg("requested_engine=kokoro")
    dbg("call_style=subprocess_simple_KPipeline_voice_name")
    dbg(f"model_dir={model_dir}")
    dbg(f"weight_path={weight_path} exists={weight_path.exists()}")
    dbg(f"voices_dir={voices_dir} exists={voices_dir.exists()}")
    dbg(f"voice_name={voice_name}")
    dbg(f"voice_path={voice_file} exists={voice_file.exists()}")
    dbg(f"output={out_path}")

    if not worker.exists():
        dbg("FAIL: kokoro_worker.py missing")
        _write_tts_debug("kokoro_last_error.log", "\n".join(debug_lines))
        return False
    if not voice_file.exists():
        dbg("FAIL: selected local voice .pt missing")
        _write_tts_debug("kokoro_last_error.log", "\n".join(debug_lines))
        return False

    req = {
        "text": text,
        "output": str(out_path),
        "data_dir": str(data_dir),
        "model_dir": str(model_dir),
        "weight_path": str(weight_path),
        "voices_dir": str(voices_dir),
        "voice_name": voice_name,
        "rate": float(rate),
        "volume": float(volume),
        "region": str(app_settings.get("speech_voice_region", "en-US") or "en-US"),
    }
    req_path.write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")

    try:
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        cmd = [os.sys.executable, str(worker), "--request", str(req_path)]
        dbg("cmd=" + " ".join(cmd))
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=240, creationflags=flags)
        dbg(f"returncode={p.returncode}")
        if p.stdout:
            dbg("stdout=" + p.stdout[-2000:])
        if p.stderr:
            dbg("stderr=" + p.stderr[-4000:])
        ok = p.returncode == 0 and out_path.exists() and out_path.stat().st_size > 100
        dbg(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
        _write_tts_debug("kokoro_subprocess_route.log", "\n".join(debug_lines))
        if not ok:
            # keep worker's detailed kokoro_last_error.log; also summarize route.
            _write_tts_debug("kokoro_last_error_summary.log", "\n".join(debug_lines))
        return ok
    except Exception as e:
        dbg("EXCEPTION: " + repr(e))
        dbg(traceback.format_exc())
        _write_tts_debug("kokoro_last_error_summary.log", "\n".join(debug_lines))
        return False

def synthesize_kokoro(text: str, out_path: Path, voice: str, rate: float = 1.0, volume: float = 1.0, log: LogFn = None) -> bool:
    # Preferred route: persistent daemon avoids 10s+ cold start per phrase.
    if _try_kokoro_daemon(text, out_path, voice, rate, volume, log):
        _postprocess_wav_file(out_path, log)
        return True
    # Fallback route: one-shot subprocess keeps the Qt GUI safe if the daemon fails.
    if _try_kokoro_pipeline(text, out_path, voice, rate, volume, log):
        _postprocess_wav_file(out_path, log)
        return True
    return False


def synthesize_chattts(text: str, out_path: Path, voice: str, rate: float = 1.0, volume: float = 1.0, log: LogFn = None) -> bool:
    """ChatTTS adapter replacing the unused Piper slot.

    Preferred: call a user-provided script with --text/--output.
    Fallback: try direct ChatTTS Python API. ChatTTS builds differ, so failures are
    written to data/chattts_last_error.log and Edge-TTS can still be used as fallback.
    """
    debug = []
    def dbg(x):
        debug.append(str(x))
        if log:
            log(str(x))
    py = str(app_settings.get("chattts_python_path", "") or "").strip() or os.sys.executable
    script = str(app_settings.get("chattts_script_path", "") or "").strip()
    model_dir = str(app_settings.get("chattts_model_dir", "") or "").strip()
    asset_dir = str(app_settings.get("chattts_asset_dir", "") or "").strip()
    voice = voice or str(app_settings.get("chattts_voice", "default") or "default")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    dbg(f"requested_engine=chattts")
    dbg(f"python={py}")
    dbg(f"script={script}")
    dbg(f"model_dir={model_dir}")
    dbg(f"asset_dir={asset_dir}")
    dbg(f"voice={voice}")
    dbg(f"output={out_path}")
    try:
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        if script and Path(script).exists():
            cmd = [py, script, "--text", text, "--output", str(out_path), "--speed", str(rate)]
            if model_dir: cmd += ["--model_dir", model_dir]
            if asset_dir: cmd += ["--asset_dir", asset_dir]
            if voice and voice != "default": cmd += ["--voice", voice]
            dbg("cmd=" + " ".join(cmd))
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=240, creationflags=flags)
            dbg(f"returncode={p.returncode}")
            if p.stdout: dbg("stdout=" + p.stdout[-2000:])
            if p.stderr: dbg("stderr=" + p.stderr[-4000:])
            ok = p.returncode == 0 and out_path.exists() and out_path.stat().st_size > 100
            if ok:
                _postprocess_wav_file(out_path, log)
            dbg(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
            _write_tts_debug("chattts_last_error.log", "\n".join(debug))
            return ok

        # Direct API fallback. This mirrors common ChatTTS examples but is conservative
        # because ChatTTS versions differ.
        import numpy as np
        import soundfile as sf
        import ChatTTS
        chat = ChatTTS.Chat()
        loaded = False
        if not model_dir and not asset_dir:
            dbg("FAIL: ChatTTS direct API requires local model_dir or asset_dir; auto-download is disabled to avoid stalls.")
            _write_tts_debug("chattts_last_error.log", "\n".join(debug))
            return False
        try:
            if model_dir:
                chat.load(source="local", custom_path=model_dir, compile=False)
            elif asset_dir:
                asset_path = Path(asset_dir)
                # ChatTTS expects the model root; if user selected the asset folder, use its parent.
                root_path = asset_path.parent if asset_path.name.lower() == "asset" else asset_path
                chat.load(source="local", custom_path=str(root_path), compile=False)
            loaded = True
        except TypeError:
            if model_dir:
                chat.load(source="local", custom_path=model_dir)
            elif asset_dir:
                asset_path = Path(asset_dir)
                root_path = asset_path.parent if asset_path.name.lower() == "asset" else asset_path
                chat.load(source="local", custom_path=str(root_path))
            loaded = True
        dbg(f"direct_api_loaded={loaded}")
        wavs = chat.infer([text])
        audio = wavs[0] if isinstance(wavs, (list, tuple)) else wavs
        sf.write(str(out_path), np.asarray(audio).squeeze(), 24000)
        ok = out_path.exists() and out_path.stat().st_size > 100
        if ok:
            _postprocess_wav_file(out_path, log)
        dbg(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
        _write_tts_debug("chattts_last_error.log", "\n".join(debug))
        return ok
    except Exception as e:
        dbg("EXCEPTION: " + repr(e))
        dbg(traceback.format_exc())
        _write_tts_debug("chattts_last_error.log", "\n".join(debug))
        return False




_STYLETTS2_DAEMON_PROC = None
_STYLETTS2_DAEMON_LOCK = threading.Lock()
_STYLETTS2_DAEMON_STDERR = None


def _styletts2_daemon_stop() -> None:
    global _STYLETTS2_DAEMON_PROC, _STYLETTS2_DAEMON_STDERR
    with _STYLETTS2_DAEMON_LOCK:
        try:
            if _STYLETTS2_DAEMON_PROC and _STYLETTS2_DAEMON_PROC.poll() is None:
                _STYLETTS2_DAEMON_PROC.terminate()
        except Exception:
            pass
        _STYLETTS2_DAEMON_PROC = None
        try:
            if _STYLETTS2_DAEMON_STDERR:
                _STYLETTS2_DAEMON_STDERR.close()
        except Exception:
            pass
        _STYLETTS2_DAEMON_STDERR = None


def _styletts2_daemon_ensure(data_dir: Path, log: LogFn = None):
    global _STYLETTS2_DAEMON_PROC, _STYLETTS2_DAEMON_STDERR
    if _STYLETTS2_DAEMON_PROC is not None and _STYLETTS2_DAEMON_PROC.poll() is None:
        return _STYLETTS2_DAEMON_PROC
    worker = Path(__file__).resolve().parent / "styletts2_daemon_worker.py"
    py = str(app_settings.get("styletts2_python_path", "") or "").strip() or sys.executable
    if not worker.exists() or not Path(py).exists():
        return None
    data_dir.mkdir(parents=True, exist_ok=True)
    err_path = data_dir / "styletts2_daemon_stderr.log"
    _STYLETTS2_DAEMON_STDERR = err_path.open("a", encoding="utf-8", errors="replace")
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    cmd = [py, str(worker), "--data-dir", str(data_dir)]
    if log:
        log("start_styletts2_daemon=" + " ".join(cmd))
    _STYLETTS2_DAEMON_PROC = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=_STYLETTS2_DAEMON_STDERR,
        text=True,
        bufsize=1,
        creationflags=flags,
    )
    return _STYLETTS2_DAEMON_PROC


def _try_styletts2_daemon(text: str, out_path: Path, diffusion_steps: int, alpha: float, beta: float, log: LogFn = None) -> bool:
    """Persistent StyleTTS2 worker. Avoids reloading torch/model per short phrase."""
    if not bool(app_settings.get("styletts2_keep_alive", True)):
        return False
    data_dir = Path(__file__).resolve().parents[1] / "data"
    model_dir = str(app_settings.get("styletts2_model_dir", "") or "").strip()
    checkpoint = str(app_settings.get("styletts2_checkpoint_path", "") or "").strip()
    config = str(app_settings.get("styletts2_config_path", "") or "").strip()
    debug = []
    def dbg(x):
        debug.append(str(x))
        if log:
            log(str(x))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    dbg("requested_engine=styletts2")
    dbg("call_style=persistent_daemon_styletts2")
    dbg(f"python={app_settings.get('styletts2_python_path','')}")
    dbg(f"checkpoint={checkpoint} exists={Path(checkpoint).exists()}")
    dbg(f"config={config} exists={Path(config).exists()}")
    dbg(f"diffusion_steps={diffusion_steps} alpha={alpha} beta={beta}")
    dbg(f"output={out_path}")
    if not Path(checkpoint).exists() or not Path(config).exists():
        dbg("FAIL: checkpoint/config missing")
        _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
        return False
    req = {
        "text": text,
        "output": str(out_path),
        "model_dir": model_dir,
        "checkpoint": checkpoint,
        "config": config,
        "diffusion_steps": int(diffusion_steps),
        "alpha": float(alpha),
        "beta": float(beta),
        "postprocess": _styletts2_postprocess_settings(),
    }
    with _STYLETTS2_DAEMON_LOCK:
        try:
            proc = _styletts2_daemon_ensure(data_dir, log)
            if not proc or not proc.stdin or not proc.stdout:
                dbg("FAIL: daemon not available")
                _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
                return False
            proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
            proc.stdin.flush()
            line = _readline_with_timeout(proc.stdout, timeout=float(app_settings.get("styletts2_daemon_timeout", 300)))
            if not line:
                dbg("FAIL: daemon timeout/no response")
                _styletts2_daemon_stop()
                _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
                return False
            dbg("response=" + line.strip())
            try:
                resp = json.loads(line)
            except Exception:
                resp = None
                for _ in range(8):
                    line2 = _readline_with_timeout(proc.stdout, timeout=5)
                    if not line2:
                        break
                    dbg("response_extra=" + line2.strip())
                    try:
                        resp = json.loads(line2)
                        break
                    except Exception:
                        continue
                if resp is None:
                    dbg("FAIL: no json response from daemon")
                    _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
                    return False
            ok = bool(resp.get("ok")) and out_path.exists() and out_path.stat().st_size > 100
            dbg(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
            _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
            return ok
        except Exception as e:
            dbg("EXCEPTION: " + repr(e))
            dbg(traceback.format_exc())
            _styletts2_daemon_stop()
            _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
            return False


def synthesize_styletts2(text: str, out_path: Path, voice: str = "", rate: float = 1.0, volume: float = 1.0, log: LogFn = None, mode: str = "live") -> bool:
    """StyleTTS2 adapter using the user's verified Python environment.

    v36 changes:
    - live playback uses a persistent daemon and low diffusion steps by default
    - production can use higher diffusion steps
    - WAV output is post-processed to trim/fade/normalize tail noise
    """
    debug = []
    def dbg(x):
        debug.append(str(x))
        if log:
            log(str(x))
    py = str(app_settings.get("styletts2_python_path", "") or "").strip() or os.sys.executable
    model_dir = str(app_settings.get("styletts2_model_dir", "") or "").strip()
    checkpoint = str(app_settings.get("styletts2_checkpoint_path", "") or "").strip()
    config = str(app_settings.get("styletts2_config_path", "") or "").strip()
    if mode == "production":
        diffusion_steps = int(app_settings.get("styletts2_production_diffusion_steps", app_settings.get("styletts2_diffusion_steps", 20)) or 20)
    else:
        diffusion_steps = int(app_settings.get("styletts2_realtime_diffusion_steps", app_settings.get("styletts2_diffusion_steps", 6)) or 6)
    alpha = float(app_settings.get("styletts2_alpha", 0.3) or 0.3)
    beta = float(app_settings.get("styletts2_beta", 0.7) or 0.7)
    data_dir = Path(__file__).resolve().parents[1] / "data"
    tmp_dir = data_dir / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    worker = Path(__file__).resolve().parent / "styletts2_worker.py"
    req_path = tmp_dir / ("styletts2_request_" + hashlib.md5(f"{text}|{checkpoint}|{config}|{diffusion_steps}|{alpha}|{beta}|{mode}".encode("utf-8")).hexdigest() + ".json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    dbg("requested_engine=styletts2")
    dbg(f"mode={mode}")
    dbg(f"python={py}")
    dbg(f"worker={worker} exists={worker.exists()}")
    dbg(f"model_dir={model_dir}")
    dbg(f"checkpoint={checkpoint} exists={Path(checkpoint).exists()}")
    dbg(f"config={config} exists={Path(config).exists()}")
    dbg(f"diffusion_steps={diffusion_steps} alpha={alpha} beta={beta}")
    dbg(f"output={out_path}")
    if not Path(py).exists() or not Path(checkpoint).exists() or not Path(config).exists():
        dbg("FAIL: StyleTTS2 python/checkpoint/config missing")
        _write_tts_debug("styletts2_last_error.log", "\n".join(debug))
        return False

    # Fast path: keep model loaded in a persistent worker.
    if _try_styletts2_daemon(text, out_path, diffusion_steps, alpha, beta, log):
        # daemon already applied StyleTTS2-specific softer tail cleanup
        return True

    # Safe fallback: one-shot worker, still isolated from the Qt GUI process.
    if not worker.exists():
        dbg("FAIL: StyleTTS2 worker missing")
        _write_tts_debug("styletts2_last_error.log", "\n".join(debug))
        return False
    req = {
        "text": text,
        "output": str(out_path),
        "data_dir": str(data_dir),
        "model_dir": model_dir,
        "checkpoint": checkpoint,
        "config": config,
        "diffusion_steps": diffusion_steps,
        "alpha": alpha,
        "beta": beta,
    }
    req_path.write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        cmd = [py, str(worker), "--request", str(req_path)]
        dbg("cmd=" + " ".join(cmd))
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=360, creationflags=flags)
        dbg(f"returncode={p.returncode}")
        if p.stdout: dbg("stdout=" + p.stdout[-2000:])
        if p.stderr: dbg("stderr=" + p.stderr[-4000:])
        ok = p.returncode == 0 and out_path.exists() and out_path.stat().st_size > 100
        if ok:
            _postprocess_wav_file(out_path, log)
        dbg(f"ok={ok} size={out_path.stat().st_size if out_path.exists() else 0}")
        _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
        return ok
    except Exception as e:
        dbg("EXCEPTION: " + repr(e))
        dbg(traceback.format_exc())
        _write_tts_debug("styletts2_last_error_summary.log", "\n".join(debug))
        return False


def synthesize_melotts(text: str, out_path: Path, voice: str, rate: float = 1.0, volume: float = 1.0, log: LogFn = None) -> bool:
    """Synthesize with MeloTTS.

    Priority:
    1) user-supplied script adapter, if configured;
    2) built-in subprocess worker that tries `from melo.api import TTS`.

    We intentionally do NOT silently call Edge-TTS here. Fallback is handled by
    SpeechEngineManager, so last_tts_engine_report can tell whether MeloTTS
    actually ran or whether Edge-TTS was used.
    """
    py = str(app_settings.get("melotts_python_path", "") or "").strip() or sys.executable
    script = str(app_settings.get("melotts_script_path", "") or "").strip()
    model_dir = str(app_settings.get("melotts_model_dir", "") or "").strip()
    checkpoint = str(app_settings.get("melotts_checkpoint_path", "") or "").strip()
    config = str(app_settings.get("melotts_config_path", "") or "").strip()
    data_dir = Path(__file__).resolve().parents[1] / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

    def _run_cmd(cmd: list[str], timeout: int = 240) -> bool:
        if log:
            log("MeloTTS cmd=" + " ".join(cmd))
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=flags)
        if p.returncode == 0 and out_path.exists() and out_path.stat().st_size > 100:
            _postprocess_wav_file(out_path, log)
            return True
        detail = (p.stderr or p.stdout or f"MeloTTS failed returncode={p.returncode}")
        _write_tts_debug("melotts_last_error_summary.log", detail[:4000])
        if log:
            log(detail[:800])
        return False

    try:
        if script and Path(script).exists():
            cmd = [py, script, "--text", text, "--output", str(out_path), "--speaker", voice or str(app_settings.get("melotts_speaker", "EN-US")), "--speed", str(rate)]
            if model_dir: cmd += ["--model_dir", model_dir]
            if checkpoint: cmd += ["--checkpoint", checkpoint]
            if config: cmd += ["--config", config]
            if _run_cmd(cmd):
                return True
            # If custom script failed, continue to built-in worker for diagnosis.

        worker = Path(__file__).resolve().parent / "melotts_worker.py"
        req_path = data_dir / ("melotts_request_" + hashlib.md5(f"{text}|{model_dir}|{checkpoint}|{config}|{voice}|{rate}".encode("utf-8")).hexdigest() + ".json")
        req = {
            "text": text, "output": str(out_path), "speaker": voice or str(app_settings.get("melotts_speaker", "EN-US")),
            "speed": rate, "model_dir": model_dir, "checkpoint": checkpoint, "config": config,
            "device": "cuda" if str(app_settings.get("melotts_device", "cuda")).lower() == "cuda" else "cpu",
            "data_dir": str(data_dir),
        }
        req_path.write_text(json.dumps(req, ensure_ascii=False, indent=2), encoding="utf-8")
        cmd = [py, str(worker), "--request", str(req_path)]
        if _run_cmd(cmd, timeout=300):
            return True
    except Exception as e:
        err = f"MeloTTS failed: {e}\n{traceback.format_exc()}"
        _write_tts_debug("melotts_last_error_summary.log", err)
        if log:
            log(err[:800])
    return False


def synthesize_text(text: str, out_path: Path, engine: str, fallback_engine: str = "edge_tts", voice: str = "", rate: float = 1.0, volume: float = 1.0, log: LogFn = None, tts_mode: str = "live") -> tuple[bool, str]:
    engine = (engine or "edge_tts").lower()
    fallback_engine = (fallback_engine or "edge_tts").lower()
    engines = [engine]
    if fallback_engine and fallback_engine not in engines and fallback_engine != "none":
        engines.append(fallback_engine)
    for e in engines:
        tmp = out_path.with_suffix("." + e + out_path.suffix)
        if e == "edge_tts":
            ok = synthesize_edge(text, tmp, voice or str(app_settings.get("speech_voice", "en-US-AriaNeural")), rate, volume, log)
        elif e == "kokoro":
            ok = synthesize_kokoro(text, tmp, voice or str(app_settings.get("kokoro_voice", "af_heart")), rate, volume, log)
        elif e == "chattts":
            ok = synthesize_chattts(text, tmp, voice or str(app_settings.get("chattts_voice", "default")), rate, volume, log)
        elif e == "melotts":
            ok = synthesize_melotts(text, tmp, voice or str(app_settings.get("melotts_speaker", "EN-US")), rate, volume, log)
        elif e == "styletts2":
            ok = synthesize_styletts2(text, tmp, voice, rate, volume, log, mode=tts_mode)
        else:
            ok = False
        if ok:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                if out_path.exists():
                    out_path.unlink()
                tmp.replace(out_path)
            except Exception:
                import shutil
                shutil.copyfile(tmp, out_path)
            try:
                report = Path(__file__).resolve().parents[1] / "data" / "last_tts_engine_report.log"
                report.parent.mkdir(parents=True, exist_ok=True)
                report.write_text(f"requested={engine}\nactual={e}\nvoice={voice}\noutput={out_path}\nkokoro_local_only={app_settings.get('kokoro_local_only', True)}", encoding="utf-8")
            except Exception:
                pass
            return True, e
    return False, ""
