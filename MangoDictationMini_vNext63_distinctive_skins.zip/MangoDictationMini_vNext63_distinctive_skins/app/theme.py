
from __future__ import annotations

from typing import Any

# -----------------------------------------------------------------------------
# MangoDictationMini Theme/Skin Engine v63
# 主题 = 60 套真实差异化配色；皮肤 = 控件形态/密度/字体/面板气质。
# 注意：Qt QSS 不是浏览器 CSS，本文件只使用 Qt 稳定支持的写法。
# -----------------------------------------------------------------------------

THEME_TOKENS: dict[str, dict[str, str]] = {
    # 国风清雅：保留中文名，但每套都有不同主色、辅色、强调色与背景倾向
    "云青禅意": dict(primary="#2F6F73", secondary="#A7C7C9", accent="#D6A84F", bg="#F3FAF9", text="#294145", title="#123033"),
    "烟雨姑苏": dict(primary="#557A8B", secondary="#C8D8DF", accent="#C9927A", bg="#F7FAFB", text="#42545D", title="#243C47"),
    "松风竹影": dict(primary="#3E7C59", secondary="#BBD8C4", accent="#C49A46", bg="#F5FBF7", text="#35493C", title="#1D3B2A"),
    "霜梅浅黛": dict(primary="#7C4F63", secondary="#D9B8C8", accent="#D45B73", bg="#FCF6F9", text="#55424A", title="#3C2330"),
    "山河清砚": dict(primary="#304D6D", secondary="#9FB5CA", accent="#C68E4A", bg="#F3F7FC", text="#334455", title="#172B40"),
    "琉璃清宵": dict(primary="#168AAD", secondary="#BFE8F2", accent="#F4A261", bg="#F5FCFF", text="#2F4B55", title="#073B4C"),
    "兰亭暮晚": dict(primary="#486B5D", secondary="#ADC9BD", accent="#B88746", bg="#F6F8F4", text="#3F4A45", title="#263A33"),
    "青梧栖月": dict(primary="#4267AC", secondary="#B8C9EA", accent="#E6B566", bg="#F6F8FF", text="#39465C", title="#203767"),
    "梵音渡川": dict(primary="#76624B", secondary="#CFC1AE", accent="#8FB996", bg="#FAF7F1", text="#544A3D", title="#3C2F22"),
    "琼楼玉宇": dict(primary="#6D91B9", secondary="#D8E8F6", accent="#D9A441", bg="#F7FBFF", text="#3A5168", title="#244563"),
    "墨染江南": dict(primary="#384B48", secondary="#93A7A2", accent="#BFA36B", bg="#F1F5F4", text="#38433F", title="#1C2A27"),
    "云山听涛": dict(primary="#4B6D78", secondary="#A9C1C9", accent="#74A57F", bg="#F4F8F9", text="#34474D", title="#223B43"),

    # 星空暗夜：暗色系内部也拉开蓝、紫、金、青、灰、红差异
    "星穹深蓝": dict(primary="#233B7A", secondary="#4F6FC4", accent="#FFD166", bg="#10182D", text="#C9D6F2", title="#F4F8FF"),
    "深空极夜": dict(primary="#141D2F", secondary="#2E405F", accent="#7FDBFF", bg="#0A1020", text="#B8C7DD", title="#E7F0FF"),
    "银河幻境": dict(primary="#463AA8", secondary="#7D70D6", accent="#C4F1FF", bg="#17142B", text="#D6D2F2", title="#F5F2FF"),
    "暮光星轨": dict(primary="#5E3A6E", secondary="#9270A6", accent="#FFB199", bg="#211629", text="#D9C8E0", title="#FFF1F7"),
    "星月沉寂": dict(primary="#1E3A5F", secondary="#4F79A6", accent="#C8E7F5", bg="#111B2A", text="#C5D8E8", title="#EFF8FF"),
    "星云幽梦": dict(primary="#3D2F6E", secondary="#6C5CA8", accent="#E7B7FF", bg="#191429", text="#D7CDED", title="#FBF4FF"),
    "破晓星穹": dict(primary="#556DA8", secondary="#91A7D7", accent="#FFCF70", bg="#26334F", text="#D6E0F3", title="#FFFFFF"),
    "暗夜星辉": dict(primary="#10253A", secondary="#245377", accent="#67E8F9", bg="#071522", text="#B9D7E6", title="#E8FBFF"),
    "幻宇流光": dict(primary="#263D8F", secondary="#4F7DFF", accent="#FF7AB6", bg="#111A36", text="#C9D4F2", title="#F8FAFF"),
    "星落尘寰": dict(primary="#394150", secondary="#687386", accent="#D6A76C", bg="#1E232B", text="#D0D4DC", title="#FAF7F1"),
    "紫宸星落": dict(primary="#4C2F69", secondary="#8A5FBF", accent="#F0A6CA", bg="#1B1024", text="#DFD0EA", title="#FFF5FF"),
    "清霄星梦": dict(primary="#214E7A", secondary="#5C8FC0", accent="#BEE3DB", bg="#0E1D2E", text="#CBE0EF", title="#F0FBFF"),

    # 赛博朋克：每套以不同霓虹强调色为主，避免同质化
    "霓虹幻界": dict(primary="#111827", secondary="#FF2DAA", accent="#00E5FF", bg="#070A13", text="#D5D9F0", title="#FFFFFF"),
    "机械都市": dict(primary="#202733", secondary="#3AA0FF", accent="#FF6B6B", bg="#10151D", text="#CCD6E0", title="#F7FAFC"),
    "紫电幻境": dict(primary="#1A1633", secondary="#8B5CF6", accent="#00FFD1", bg="#0D0A1B", text="#D6D0F0", title="#FAF8FF"),
    "废土赛博": dict(primary="#2D2535", secondary="#E64980", accent="#C9F31D", bg="#15111B", text="#D6CDD9", title="#FFF8E8"),
    "光电未来": dict(primary="#0F2233", secondary="#00A8E8", accent="#FFB703", bg="#071521", text="#C8E6F4", title="#F4FCFF"),
    "量子霓虹": dict(primary="#17252A", secondary="#2DD4BF", accent="#F97316", bg="#081416", text="#C7E6E2", title="#EDFFFB"),
    "赤焰赛博": dict(primary="#2B1115", secondary="#FF3131", accent="#FFD60A", bg="#12080A", text="#F0C9C9", title="#FFF5F5"),
    "冰蓝纪元": dict(primary="#0B2545", secondary="#00B4D8", accent="#80FFDB", bg="#05101F", text="#C3E6F0", title="#F2FFFF"),
    "幻彩代码": dict(primary="#171C2E", secondary="#7C3AED", accent="#22C55E", bg="#0B0F1B", text="#CDD4E8", title="#FAFAFF"),
    "暗夜机甲": dict(primary="#22222F", secondary="#64748B", accent="#FF4081", bg="#11111A", text="#D1D5DB", title="#FFFFFF"),
    "都市迷途": dict(primary="#25172A", secondary="#EF4444", accent="#38BDF8", bg="#130C16", text="#E2D7E8", title="#FFF7FF"),
    "次元流光": dict(primary="#0F172A", secondary="#5294FF", accent="#FF6E99", bg="#050A16", text="#D4DDF2", title="#FFFFFF"),

    # 森系治愈：拉开薄荷、橄榄、森林、海盐、花园、土棕等方向
    "林间朝露": dict(primary="#2F855A", secondary="#BDE5CE", accent="#F2C078", bg="#F4FBF7", text="#2F4A3B", title="#17402A"),
    "青野晚风": dict(primary="#4D7C0F", secondary="#C9E4B5", accent="#E7B76A", bg="#F7FBF2", text="#405233", title="#2F4A13"),
    "浅夏清宁": dict(primary="#0E9F6E", secondary="#BFEEDB", accent="#F6D365", bg="#F5FFFA", text="#2B5142", title="#0E5F48"),
    "雾隐青森": dict(primary="#5F7F5F", secondary="#CAD8C6", accent="#A68A64", bg="#F4F7F2", text="#455244", title="#314731"),
    "森屿暖阳": dict(primary="#6BAA75", secondary="#D9EDD2", accent="#F7B267", bg="#FAFCF5", text="#46543F", title="#315D37"),
    "春野溪风": dict(primary="#2A9D8F", secondary="#B9E4DD", accent="#E9C46A", bg="#F2FBFA", text="#31504B", title="#14645C"),
    "苔痕青径": dict(primary="#607D3B", secondary="#C9D9B6", accent="#D0A85C", bg="#F6F8F1", text="#47513A", title="#364F1F"),
    "山野清欢": dict(primary="#386641", secondary="#A7C957", accent="#F2E8CF", bg="#FAFCF4", text="#3F4D34", title="#1F3B25"),
    "浅林薄雾": dict(primary="#78A083", secondary="#DCEADD", accent="#C08552", bg="#F8FBF8", text="#4C5A4D", title="#3A6744"),
    "青芜流年": dict(primary="#2D6A4F", secondary="#95D5B2", accent="#F4A261", bg="#F4FAF6", text="#344C40", title="#1B4332"),
    "溪涧草木": dict(primary="#0077B6", secondary="#BDE0FE", accent="#90BE6D", bg="#F5FBFF", text="#344A56", title="#023E8A"),
    "晚风林汐": dict(primary="#52796F", secondary="#CAD2C5", accent="#E76F51", bg="#F5F8F5", text="#3D4D49", title="#2F4F46"),

    # 极简轻奢：咖、金、灰、黑、奶油、玫瑰金、墨绿等不同质感
    "鎏金雅灰": dict(primary="#6B6259", secondary="#D0C7BD", accent="#C8A45D", bg="#F7F5F2", text="#4A4642", title="#2D2925"),
    "焦糖拿铁": dict(primary="#8A5A44", secondary="#D9B99B", accent="#E0A458", bg="#FAF5EF", text="#58483E", title="#3B2A20"),
    "摩卡极简": dict(primary="#5C4033", secondary="#B89B88", accent="#D6A77A", bg="#F5EFEA", text="#51433C", title="#34241C"),
    "琥珀时光": dict(primary="#9A6700", secondary="#F1C27D", accent="#D97706", bg="#FFF8ED", text="#57422A", title="#5F3B00"),
    "暖棕素简": dict(primary="#7B5E57", secondary="#CDB4A5", accent="#B08968", bg="#F8F2EE", text="#544744", title="#3E2F2A"),
    "檀木清奢": dict(primary="#4A2C2A", secondary="#8D6E63", accent="#C9A227", bg="#F3ECE8", text="#493937", title="#2C1816"),
    "雅金流年": dict(primary="#7C6A46", secondary="#D9CFB3", accent="#B88A2D", bg="#FAF8F0", text="#4C4736", title="#3F351B"),
    "轻奢茶褐": dict(primary="#6F4E37", secondary="#BFA58A", accent="#8FB996", bg="#F6F2EB", text="#50463D", title="#37251A"),
    "金棕暮色": dict(primary="#8B5E34", secondary="#D4A373", accent="#588157", bg="#FBF4EC", text="#5A4634", title="#4A2E16"),
    "复古奶咖": dict(primary="#A47148", secondary="#E3C5A8", accent="#9D8189", bg="#FFF7EF", text="#5A493E", title="#603A22"),
    "素棕雅韵": dict(primary="#5E503F", secondary="#C6AC8F", accent="#C9ADA7", bg="#F5F1EA", text="#4A4036", title="#30261F"),
    "浅金素雅": dict(primary="#A68A64", secondary="#E7D8BD", accent="#D4AF37", bg="#FCF9F2", text="#534C3E", title="#5F4A22"),
}

THEME_NAMES = list(THEME_TOKENS.keys())

LINE_COLOR_PRESETS = {
    "theme": None, "gray": "#94a3b8", "blue": "#3b82f6", "green": "#22c55e", "orange": "#f59e0b",
    "purple": "#8b5cf6", "pink": "#ec4899", "red": "#ef4444", "gold": "#d4af37", "cyan": "#06b6d4",
}

SKIN_NAMES = ["极简学习本", "国风雅卷", "商务绅士", "赛博终端", "轻奢奶油", "胶片影视", "学霸练习册", "悬浮挂件"]

# v63：皮肤不再只是圆角/密度微调，而是 8 套明显不同的控件形态。
# 仍坚持 Qt QSS 稳定语法：不用 rgba / box-shadow / transition / nth-child 等浏览器 CSS。
SKIN_TOKENS: dict[str, dict[str, Any]] = {
    "极简学习本": dict(radius=8, button_radius=6, tab_radius=6, density=0.92, font="Microsoft YaHei UI", border_width=1, chip=6, line_width=2, line_style="solid"),
    "国风雅卷": dict(radius=4, button_radius=3, tab_radius=2, density=1.12, font="KaiTi", border_width=2, chip=3, line_width=3, line_style="solid"),
    "商务绅士": dict(radius=2, button_radius=2, tab_radius=2, density=0.94, font="Microsoft YaHei UI", border_width=1, chip=2, line_width=2, line_style="solid"),
    "赛博终端": dict(radius=0, button_radius=0, tab_radius=0, density=0.88, font="Consolas", border_width=2, chip=0, line_width=3, line_style="dashed"),
    "轻奢奶油": dict(radius=28, button_radius=22, tab_radius=20, density=1.16, font="Microsoft YaHei UI", border_width=1, chip=20, line_width=2, line_style="solid"),
    "胶片影视": dict(radius=12, button_radius=18, tab_radius=4, density=1.04, font="Georgia", border_width=2, chip=18, line_width=3, line_style="solid"),
    "学霸练习册": dict(radius=1, button_radius=1, tab_radius=1, density=0.86, font="Microsoft YaHei UI", border_width=1, chip=1, line_width=2, line_style="dotted"),
    "悬浮挂件": dict(radius=18, button_radius=16, tab_radius=16, density=0.78, font="Microsoft YaHei UI", border_width=1, chip=14, line_width=2, line_style="solid"),
}


def _hex_to_rgb(s: str) -> tuple[int, int, int]:
    s = str(s).strip().lstrip("#")
    return int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)


def _rgb_to_hex(rgb: tuple[float, float, float]) -> str:
    return "#" + "".join(f"{max(0, min(255, int(round(x)))):02X}" for x in rgb)


def mix(a: str, b: str, t: float) -> str:
    ar, ag, ab = _hex_to_rgb(a)
    br, bg, bb = _hex_to_rgb(b)
    return _rgb_to_hex((ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t))


def luminance(hex_color: str) -> float:
    r, g, b = _hex_to_rgb(hex_color)
    def f(c: int) -> float:
        x = c / 255.0
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def theme_profile(name: str) -> dict[str, str]:
    t = THEME_TOKENS.get(name) or THEME_TOKENS[THEME_NAMES[0]]
    bg = t["bg"]
    dark = luminance(bg) < 0.25
    white = "#FFFFFF"
    black = "#000000"
    panel = mix(bg, white if not dark else "#1F2937", 0.72 if not dark else 0.28)
    panel2 = mix(bg, t["primary"], 0.10 if not dark else 0.25)
    card = mix(bg, white if not dark else "#111827", 0.62 if not dark else 0.18)
    soft = mix(bg, t["secondary"], 0.18 if not dark else 0.22)
    border = mix(t["primary"], bg, 0.62 if not dark else 0.40)
    selected = mix(t["accent"], bg, 0.76 if not dark else 0.55)
    dim = mix(t["text"], bg, 0.35 if not dark else 0.22)
    return {
        "bg": bg,
        "fg": t["text"],
        "title": t["title"],
        "primary": t["primary"],
        "secondary": t["secondary"],
        "accent": t["accent"],
        "panel": panel,
        "panel2": panel2,
        "card": card,
        "soft": soft,
        "border": border,
        "selected": selected,
        "dim": dim,
        "line": t["primary"],
        "success": "#16A34A" if not dark else "#86EFAC",
        "danger": "#DC2626" if not dark else "#FCA5A5",
        "wrong_bg": "#FEE2E2" if not dark else "#3B1515",
        "input_text": "#111827" if not dark else "#F8FAFC",
        "is_dark": "1" if dark else "0",
    }


def _skin_qss(skin: str, p: dict[str, str], r: int, br: int, tr: int, bw: int, font: str, density: float) -> str:
    pad = max(4, int(8 * density))
    min_btn = max(24, int(30 * density))
    q: list[str] = []

    # 通用皮肤增强：让“工作区、全文浏览、精听弹窗、制作台弹窗”等窗口也吃到皮肤。
    common_tables = "QTableWidget#transcriptTable, QTableWidget#intensiveTable"
    common_panels = "QWidget#dictationPanel, QWidget#choicePanel, QWidget#fillPanel, QFrame#hintBox, QFrame#intensiveVideoHost"

    if skin == "极简学习本":
        # 白纸感：扁平、清爽、窄边框、少装饰。
        q += [
            f"QMainWindow, QDialog {{ background-color:{p['bg']}; }}",
            f"QLabel#titleLabel {{ font-size:22px; font-weight:850; color:{p['title']}; }}",
            f"QFrame#separator {{ max-height:1px; background-color:{p['border']}; }}",
            f"{common_panels} {{ border:1px solid {p['border']}; border-radius:8px; background-color:{p['card']}; }}",
            f"QLabel#chineseLabel {{ border:1px solid {p['border']}; border-radius:8px; padding:16px; font-size:26px; }}",
            f"QPushButton {{ border-radius:6px; min-height:{min_btn}px; padding:{pad}px {pad+8}px; background-color:{p['card']}; }}",
            f"QPushButton:hover {{ background-color:{p['soft']}; border-color:{p['accent']}; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:6px; margin-right:4px; min-width:92px; }}",
            f"{common_tables} {{ border:1px solid {p['border']}; border-radius:8px; alternate-background-color:{p['panel']}; }}",
        ]
    elif skin == "国风雅卷":
        # 卷轴感：细长、边框重、左侧色条、标题用楷体，台词区像纸笺。
        q += [
            f"QWidget {{ font-family:'KaiTi','Microsoft YaHei UI'; }}",
            f"QLabel#titleLabel {{ font-family:'KaiTi','Microsoft YaHei UI'; font-size:28px; font-weight:900; color:{p['primary']}; padding:4px 0; }}",
            f"QFrame#separator {{ max-height:3px; background-color:{p['accent']}; margin:4px 0; }}",
            f"QLabel#chineseLabel {{ border:2px solid {p['accent']}; border-left:8px solid {p['primary']}; border-right:8px solid {p['primary']}; border-radius:4px; padding:22px; font-size:30px; font-family:'KaiTi','Microsoft YaHei UI'; }}",
            f"{common_panels} {{ border:2px solid {p['border']}; border-left:6px solid {p['accent']}; border-radius:4px; background-color:{p['panel']}; }}",
            f"QFrame#hintBox {{ border-left:8px solid {p['accent']}; padding:6px; }}",
            f"QPushButton {{ border-radius:3px; border:2px solid {p['border']}; padding:{pad+2}px {pad+12}px; min-height:{min_btn+6}px; font-family:'KaiTi','Microsoft YaHei UI'; }}",
            f"QPushButton:hover {{ background-color:{p['selected']}; border-color:{p['primary']}; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:2px; min-width:118px; padding:{pad+2}px {pad+12}px; }}",
            f"QTabBar::tab:selected, QTabBar#modeBar::tab:selected {{ background-color:{p['primary']}; color:{p['bg']}; }}",
            f"{common_tables} {{ border:2px solid {p['border']}; border-radius:4px; gridline-color:{p['secondary']}; }}",
            f"QHeaderView::section {{ padding:8px; border-bottom:2px solid {p['accent']}; }}",
        ]
    elif skin == "商务绅士":
        # 商务仪表盘：直角、深分隔线、宽按钮、紧凑且利落。
        q += [
            f"QLabel#titleLabel {{ font-size:24px; font-weight:950; padding:2px 0; }}",
            f"QFrame#separator {{ max-height:4px; background-color:{p['primary']}; margin:2px 0 8px 0; }}",
            f"{common_panels} {{ border:1px solid {p['primary']}; border-radius:2px; background-color:{p['card']}; }}",
            f"QLabel#chineseLabel {{ border:1px solid {p['primary']}; border-bottom:4px solid {p['accent']}; border-radius:2px; padding:14px; font-size:27px; }}",
            f"QPushButton {{ border-radius:2px; min-height:{min_btn+6}px; min-width:92px; padding:{pad}px {pad+14}px; border:1px solid {p['primary']}; }}",
            f"QPushButton:hover {{ border:2px solid {p['accent']}; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:2px; min-width:124px; padding:{pad+1}px {pad+14}px; margin-right:2px; }}",
            f"QTabBar::tab:selected, QTabBar#modeBar::tab:selected {{ border-top:4px solid {p['accent']}; }}",
            f"QGroupBox {{ border-radius:2px; border:1px solid {p['primary']}; }}",
            f"{common_tables} {{ border:1px solid {p['primary']}; border-radius:2px; gridline-color:{p['border']}; }}",
            f"QHeaderView::section {{ border-bottom:3px solid {p['accent']}; }}",
        ]
    elif skin == "赛博终端":
        # 终端霓虹：黑底、方角、等宽字、虚线输入，强烈区分。
        q += [
            f"QWidget {{ font-family:'Consolas','Microsoft YaHei UI'; }}",
            f"QMainWindow, QDialog, QWidget#root {{ background-color:{mix(p['bg'], '#000000', 0.35)}; }}",
            f"QLabel#titleLabel {{ font-family:'Consolas'; font-size:24px; color:{p['accent']}; padding:4px; }}",
            f"QFrame#separator {{ max-height:2px; background-color:{p['accent']}; }}",
            f"{common_panels} {{ border:2px solid {p['accent']}; border-radius:0px; background-color:{mix(p['bg'], '#000000', 0.20)}; }}",
            f"QLabel#chineseLabel {{ border:2px solid {p['accent']}; border-radius:0px; padding:16px; font-family:'Consolas','Microsoft YaHei UI'; font-size:25px; color:{p['title']}; }}",
            f"QFrame#hintBox {{ border:2px dashed {p['secondary']}; }}",
            f"QPushButton {{ border-radius:0px; border:2px solid {p['secondary']}; min-height:{min_btn+2}px; padding:{pad}px {pad+10}px; background-color:{mix(p['bg'], '#000000', 0.18)}; color:{p['title']}; }}",
            f"QPushButton:hover {{ border-color:{p['accent']}; color:{p['accent']}; background-color:{p['panel2']}; }}",
            f"QLineEdit#chunkInput {{ font-family:'Consolas'; border-bottom:3px dashed {p['accent']}; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:0px; min-width:106px; border:2px solid {p['secondary']}; margin-right:3px; }}",
            f"QTabBar::tab:selected, QTabBar#modeBar::tab:selected {{ background-color:{p['accent']}; color:{mix(p['bg'], '#000000', 0.55)}; border-color:{p['accent']}; }}",
            f"{common_tables} {{ border:2px solid {p['accent']}; border-radius:0px; gridline-color:{p['accent']}; background-color:{mix(p['bg'], '#000000', 0.25)}; }}",
            f"QHeaderView::section {{ border:1px solid {p['accent']}; font-family:'Consolas'; }}",
            f"QScrollBar::handle:vertical, QScrollBar::handle:horizontal {{ background-color:{p['accent']}; border-radius:0px; }}",
        ]
    elif skin == "轻奢奶油":
        # 圆润轻奢：大圆角、大留白、胶囊按钮、柔软卡片。
        q += [
            f"QLabel#titleLabel {{ font-size:25px; font-weight:900; padding:6px 0; }}",
            f"QFrame#separator {{ max-height:1px; background-color:{p['selected']}; margin:6px 0 10px 0; }}",
            f"{common_panels} {{ border:1px solid {p['selected']}; border-radius:28px; background-color:{p['panel']}; }}",
            f"QLabel#chineseLabel {{ border:1px solid {p['selected']}; border-radius:28px; padding:26px; font-size:29px; background-color:{p['card']}; }}",
            f"QFrame#hintBox {{ border-radius:24px; padding:10px; }}",
            f"QPushButton {{ border-radius:22px; min-height:{min_btn+10}px; padding:{pad+3}px {pad+18}px; border:1px solid {p['selected']}; background-color:{p['panel2']}; }}",
            f"QPushButton:hover {{ background-color:{p['selected']}; border-color:{p['accent']}; }}",
            f"QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit,QTextEdit,QPlainTextEdit {{ border-radius:18px; padding:8px 12px; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:20px; min-width:112px; margin-right:8px; padding:{pad+2}px {pad+18}px; }}",
            f"{common_tables} {{ border:1px solid {p['selected']}; border-radius:22px; alternate-background-color:{p['soft']}; }}",
            f"QHeaderView::section {{ padding:9px; border:0px; }}",
        ]
    elif skin == "胶片影视":
        # 影视字幕台：暗场视频感、宽标题、字幕区突出，适合精听/观影。
        dark_panel = mix(p['bg'], '#000000', 0.55)
        q += [
            f"QWidget {{ font-family:'Georgia','Microsoft YaHei UI'; }}",
            f"QLabel#titleLabel {{ font-family:'Georgia','Microsoft YaHei UI'; font-size:26px; font-weight:900; color:{p['title']}; padding:5px 0; }}",
            f"QFrame#separator {{ max-height:5px; background-color:{p['accent']}; margin:4px 0 8px 0; }}",
            f"QFrame#intensiveVideoHost, QVideoWidget#intensiveVideoWidget, QWidget#intensiveVideoCanvas {{ background-color:#000000; border:2px solid {p['accent']}; border-radius:12px; }}",
            f"QLabel#videoSubtitleOverlay {{ background-color:#000000; color:{p['accent']}; font-size:24px; font-weight:900; padding:10px; }}",
            f"QLabel#chineseLabel {{ background-color:{dark_panel}; color:{p['title']}; border:2px solid {p['accent']}; border-radius:12px; padding:20px; font-size:30px; }}",
            f"{common_panels} {{ border:2px solid {p['border']}; border-radius:12px; background-color:{p['card']}; }}",
            f"QLabel#intensiveEnglish {{ font-family:'Georgia','Microsoft YaHei UI'; font-size:20px; font-weight:900; border-bottom:3px solid {p['accent']}; }}",
            f"QLabel#intensiveChinese {{ font-size:17px; }}",
            f"QPushButton {{ border-radius:18px; min-height:{min_btn+6}px; padding:{pad+1}px {pad+14}px; border:2px solid {p['border']}; }}",
            f"QPushButton#choiceWordButton, QPushButton#fillWordButton {{ border-radius:20px; min-height:44px; font-size:18px; padding:8px 20px; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:4px; min-width:110px; border-bottom:4px solid {p['border']}; }}",
            f"QTabBar::tab:selected, QTabBar#modeBar::tab:selected {{ border-bottom:5px solid {p['accent']}; }}",
            f"{common_tables} {{ font-family:'Georgia','Microsoft YaHei UI'; font-size:15px; border:2px solid {p['border']}; border-radius:12px; }}",
        ]
    elif skin == "学霸练习册":
        # 练习册：方格纸感、直角、点线、紧凑，可见“做题工具”气质。
        q += [
            f"QLabel#titleLabel {{ font-size:21px; font-weight:950; color:{p['primary']}; padding:1px 0; }}",
            f"QFrame#separator {{ max-height:1px; background-color:{p['primary']}; }}",
            f"{common_panels} {{ border:1px solid {p['primary']}; border-radius:1px; background-color:{p['card']}; }}",
            f"QLabel#chineseLabel {{ border:1px solid {p['primary']}; border-left:5px solid {p['accent']}; border-radius:1px; padding:12px; font-size:25px; }}",
            f"QFrame#hintBox {{ border:1px dotted {p['primary']}; border-left:5px solid {p['accent']}; border-radius:1px; }}",
            f"QPushButton {{ border-radius:1px; min-height:{min_btn}px; padding:5px 10px; border:1px solid {p['primary']}; }}",
            f"QPushButton:hover {{ border:2px solid {p['accent']}; }}",
            f"QLineEdit#chunkInput {{ border-bottom:2px dotted {p['primary']}; font-size:21px; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:1px; min-width:86px; padding:5px 10px; margin-right:1px; }}",
            f"QTabBar::tab:selected, QTabBar#modeBar::tab:selected {{ border-bottom:4px solid {p['accent']}; }}",
            f"QLabel#hintText, QLabel#chunkSubHint, QLabel#footerLabel {{ font-size:12px; }}",
            f"{common_tables} {{ border:1px solid {p['primary']}; border-radius:1px; gridline-color:{p['secondary']}; alternate-background-color:{p['soft']}; }}",
            f"QHeaderView::section {{ padding:5px; border:1px solid {p['primary']}; }}",
        ]
    elif skin == "悬浮挂件":
        # 悬浮小组件：更紧凑、胶囊形、适合小窗/分屏，不占空间但视觉明显。
        q += [
            f"QLabel#titleLabel {{ font-size:19px; font-weight:900; padding:0; }}",
            f"QLabel#progressLabel {{ font-size:13px; }}",
            f"QFrame#separator {{ max-height:1px; background-color:{p['selected']}; }}",
            f"{common_panels} {{ border:1px solid {p['selected']}; border-radius:18px; background-color:{p['panel']}; }}",
            f"QLabel#chineseLabel {{ border:1px solid {p['selected']}; border-radius:18px; padding:12px; font-size:22px; min-height:56px; }}",
            f"QFrame#hintBox {{ border-radius:16px; padding:5px; }}",
            f"QPushButton {{ border-radius:16px; min-height:26px; padding:5px 10px; border:1px solid {p['selected']}; }}",
            f"QPushButton#navButton {{ min-width:68px; }}",
            f"QLineEdit#chunkInput {{ font-size:18px; min-height:34px; max-height:44px; }}",
            f"QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit,QTextEdit,QPlainTextEdit {{ border-radius:14px; min-height:24px; padding:4px 8px; }}",
            f"QTabBar::tab, QTabBar#modeBar::tab {{ border-radius:16px; min-width:76px; padding:5px 10px; margin-right:5px; }}",
            f"{common_tables} {{ border:1px solid {p['selected']}; border-radius:16px; }}",
            f"QTableWidget#transcriptTable::item, QTableWidget#intensiveTable::item {{ padding:4px 6px; }}",
        ]
    else:
        q += [
            f"QWidget#dictationPanel {{ border-width:1px; }}",
            f"QLabel#chineseLabel {{ font-weight:750; }}",
        ]
    return "\n".join(q)


def make_qss(name: str, line_color: str | None = None, skin_name: str | None = None) -> str:
    p = theme_profile(name)
    skin = skin_name if skin_name in SKIN_TOKENS else "极简学习本"
    s = SKIN_TOKENS[skin]
    r = int(s["radius"])
    br = int(s["button_radius"])
    tr = int(s["tab_radius"])
    bw = int(s["border_width"])
    density = float(s["density"])
    font = str(s["font"])
    line = LINE_COLOR_PRESETS.get((line_color or "theme").lower(), None) or p["line"]
    line_focus = p["accent"] if (line_color or "theme").lower() == "theme" else line
    line_width = int(s.get("line_width", 2))
    line_style = str(s.get("line_style", "solid"))
    pad = max(4, int(8 * density))
    min_btn = max(24, int(30 * density))
    tab_y = max(6, int(8 * density))
    tab_x = max(12, int(18 * density))

    base = f"""
QWidget {{ background-color:{p['bg']}; color:{p['fg']}; font-family:'{font}', 'Microsoft YaHei UI'; }}
QMainWindow, QDialog {{ background-color:{p['bg']}; color:{p['fg']}; }}
QWidget#root {{ background-color:{p['bg']}; color:{p['fg']}; }}
QMenuBar, QMenu {{ background-color:{p['panel']}; color:{p['fg']}; border:1px solid {p['border']}; }}
QMenu::item:selected {{ background-color:{p['selected']}; color:{p['title']}; }}
QDockWidget::title {{ background-color:{p['panel2']}; color:{p['title']}; padding:6px 10px; font-weight:900; border-bottom:{bw}px solid {p['accent']}; }}
QLabel#titleLabel {{ color:{p['title']}; font-size:24px; font-weight:900; }}
QLabel#progressLabel {{ color:{p['dim']}; font-size:16px; font-weight:800; }}
QFrame#separator {{ background-color:{p['border']}; max-height:1px; }}
QLabel#chineseLabel {{ background-color:{p['card']}; color:{p['title']}; border:{bw}px solid {p['border']}; border-radius:{r}px; padding:18px; font-size:28px; font-weight:650; }}
QWidget#dictationPanel {{ background-color:{p['soft']}; border:{bw}px solid {p['border']}; border-radius:{r}px; }}
QWidget#choicePanel, QWidget#fillPanel {{ background-color:{p['soft']}; border:{bw}px solid {p['border']}; border-radius:{r}px; }}
QFrame#hintBox {{ background-color:{p['card']}; border:{bw}px solid {p['border']}; border-radius:{r}px; }}
QLabel#hintWord {{ color:{p['title']}; font-size:20px; font-weight:900; }}
QLabel#hintText {{ color:{p['fg']}; font-size:14px; }}
QLabel#intensiveEnglish {{ background-color:{p['card']}; color:{p['title']}; border:{bw}px solid {p['border']}; border-radius:{max(4, r//2)}px; padding:10px; font-size:18px; font-weight:850; }}
QLabel#intensiveChinese {{ background-color:{p['soft']}; color:{p['fg']}; border:1px solid {p['border']}; border-radius:{max(4, r//2)}px; padding:9px; font-size:15px; }}
QFrame#intensiveVideoHost {{ background-color:{p['card']}; border:{bw}px solid {p['border']}; border-radius:{r}px; }}
QVideoWidget#intensiveVideoWidget {{ background-color:#000000; border-radius:{max(4, r//2)}px; }}
QLabel#statusLabel {{ color:{p['dim']}; font-size:15px; padding:4px; }}
QLabel#statusLabel[state='correct'] {{ color:{p['success']}; font-weight:900; }}
QLabel#statusLabel[state='wrong'] {{ color:{p['danger']}; font-weight:900; }}
QLabel#footerLabel {{ color:{p['dim']}; font-size:13px; padding:6px; }}
QLabel#punctLabel {{ color:{p['dim']}; font-size:24px; padding:0 4px; }}
QLabel#chunkIpaHint {{ color:{p['dim']}; font-size:12px; padding:0 0 8px 0; font-weight:800; min-height:22px; max-height:32px; }}
QLabel#chunkSubHint {{ color:{p['dim']}; font-size:11px; padding:7px 0 0 0; min-height:24px; max-height:38px; }}
QLineEdit#chunkInput {{ border:none; border-bottom:{line_width}px {line_style} {line}; border-radius:0; background-color:transparent; color:{p['input_text']}; padding:4px 4px 8px 4px; font-size:22px; font-family:'Consolas'; selection-background-color:{p['selected']}; min-height:44px; max-height:58px; }}
QLineEdit#chunkInput[state='focus'] {{ border:none; border-bottom:{line_width + 1}px {line_style} {line_focus}; background-color:transparent; color:{p['input_text']}; }}
QLineEdit#chunkInput[state='correct'] {{ border:none; border-bottom:{line_width + 1}px {line_style} {p['success']}; color:{p['success']}; background-color:transparent; }}
QLineEdit#chunkInput[state='wrong'] {{ border:none; border-bottom:{line_width + 1}px {line_style} {p['danger']}; color:{p['danger']}; background-color:{p['wrong_bg']}; }}
QLineEdit#chunkInput[state='prefix'] {{ border:none; border-bottom:{line_width + 1}px {line_style} {line_focus}; color:{p['input_text']}; background-color:transparent; }}
QPushButton {{ background-color:{p['panel2']}; color:{p['title']}; border:{bw}px solid {p['border']}; border-radius:{br}px; padding:{pad}px {pad + 5}px; min-height:{min_btn}px; font-weight:800; }}
QPushButton:hover {{ border-color:{p['accent']}; background-color:{p['selected']}; }}
QPushButton:pressed {{ background-color:{p['accent']}; color:{p['bg']}; }}
QPushButton#navButton {{ font-weight:900; min-width:82px; }}
QComboBox,QSpinBox,QDoubleSpinBox,QLineEdit,QTextEdit,QPlainTextEdit {{ background-color:{p['card']}; color:{p['fg']}; border:1px solid {p['border']}; border-radius:{max(4, r//2)}px; min-height:27px; padding:5px 7px; selection-background-color:{p['selected']}; }}
QComboBox::drop-down {{ border:0; width:25px; }}
QComboBox QAbstractItemView, QListView, QTreeView, QTableView {{ background-color:{p['card']}; color:{p['fg']}; border:1px solid {p['border']}; selection-background-color:{p['selected']}; selection-color:{p['title']}; }}
QTreeWidget {{ background-color:{p['card']}; color:{p['fg']}; border:{bw}px solid {p['border']}; border-radius:{r}px; padding:4px; }}
QTreeWidget::item {{ min-height:22px; padding:2px 4px; }}
QTreeWidget::item:selected {{ background-color:{p['selected']}; color:{p['title']}; }}
QTableWidget#transcriptTable {{ background-color:{p['card']}; color:{p['fg']}; border:{bw}px solid {p['border']}; border-radius:{r}px; gridline-color:{p['border']}; selection-background-color:{p['selected']}; selection-color:{p['title']}; alternate-background-color:{p['soft']}; }}
QTableWidget#transcriptTable::item, QTableWidget#intensiveTable::item {{ padding:7px 8px; }}
QTableWidget#transcriptTable::item, QTableWidget#intensiveTable::item:selected {{ background-color:{p['selected']}; color:{p['title']}; }}
QHeaderView::section {{ background-color:{p['panel2']}; color:{p['title']}; border:1px solid {p['border']}; padding:6px; font-weight:900; }}
QScrollArea {{ border:none; background-color:transparent; }}
QSplitter#mainVerticalSplitter::handle:vertical {{ background-color:{p['border']}; min-height:9px; margin:2px 0; }}
QSplitter#mainVerticalSplitter::handle:vertical:hover {{ background-color:{p['accent']}; }}
QSplitter#intensiveSplitter::handle:horizontal {{ background-color:{p['border']}; min-width:8px; margin:0 2px; }}
QSplitter#intensiveSplitter::handle:horizontal:hover {{ background-color:{p['accent']}; }}
QGroupBox {{ background-color:{p['panel']}; color:{p['title']}; font-weight:900; margin-top:10px; border:{bw}px solid {p['border']}; border-radius:{r}px; padding-top:12px; }}
QGroupBox::title {{ subcontrol-origin: margin; left:12px; padding:0 6px; color:{p['accent']}; }}
QTabWidget::pane {{ background-color:{p['panel']}; border:{bw}px solid {p['border']}; border-radius:{r}px; top:-1px; }}
QTabBar::tab {{ background-color:{p['panel2']}; color:{p['fg']}; border:{bw}px solid {p['border']}; border-bottom:none; padding:{tab_y}px {tab_x}px; min-width:94px; border-top-left-radius:{tr}px; border-top-right-radius:{tr}px; margin-right:4px; font-weight:900; }}
QTabBar::tab:selected {{ background-color:{p['accent']}; color:{p['bg']}; border-color:{p['accent']}; }}
QTabBar::tab:hover {{ background-color:{p['selected']}; border-color:{p['accent']}; }}
QTabBar#modeBar::tab {{ background-color:{p['panel2']}; color:{p['fg']}; border:{bw}px solid {p['border']}; padding:{tab_y + 1}px {tab_x + 4}px; min-width:112px; border-radius:{tr}px; margin-right:8px; font-weight:900; }}
QTabBar#modeBar::tab:selected {{ background-color:{p['accent']}; color:{p['bg']}; border-color:{p['accent']}; }}
QScrollBar:vertical {{ background-color:{p['bg']}; width:13px; margin:12px 0; }}
QScrollBar::handle:vertical {{ background-color:{p['panel2']}; min-height:26px; border-radius:6px; }}
QScrollBar::handle:vertical:hover {{ background-color:{p['accent']}; }}
QScrollBar:horizontal {{ background-color:{p['bg']}; height:13px; margin:0 12px; }}
QScrollBar::handle:horizontal {{ background-color:{p['panel2']}; min-width:26px; border-radius:6px; }}
QScrollBar::handle:horizontal:hover {{ background-color:{p['accent']}; }}
"""
    return base + "\n" + _skin_qss(skin, p, r, br, tr, bw, font, density)
