from __future__ import annotations

import json
import re
import traceback
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QFileDialog, QListWidget, QListWidgetItem, QCheckBox, QComboBox,
    QLineEdit, QProgressBar, QTextEdit, QGroupBox, QSpinBox, QMessageBox,
    QTabWidget, QWidget, QApplication
)

from .settings import app_settings
from .translation_service import translate_text, translate_many
from .dictation_engine import segment_chunks
from .wordbook import lookup_sentence_words
from .tts_cache_service import synthesize_text, text_hash, safe_name


@dataclass
class SrtBlock:
    index: str
    timecode: str
    lines: list[str]

    @property
    def text(self) -> str:
        return " ".join(x.strip() for x in self.lines if x.strip())


ENG_RE = re.compile(r"[A-Za-z]")
CJK_RE = re.compile(r"[\u4e00-\u9fff]")
WORD_RE = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)?")


def read_text_auto(path: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "gb18030", "gbk", "utf-16"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def parse_srt(path: Path) -> list[SrtBlock]:
    text = read_text_auto(path).replace("\r\n", "\n").replace("\r", "\n")
    parts = re.split(r"\n\s*\n", text.strip())
    blocks: list[SrtBlock] = []
    for part in parts:
        lines = [x.strip("\ufeff ") for x in part.split("\n") if x.strip()]
        if not lines:
            continue
        idx = lines[0] if lines and lines[0].strip().isdigit() else str(len(blocks) + 1)
        tc_i = 1 if lines and lines[0].strip().isdigit() else 0
        if tc_i >= len(lines) or "-->" not in lines[tc_i]:
            continue
        timecode = lines[tc_i]
        body = lines[tc_i + 1 :]
        body = [re.sub(r"<[^>]+>", "", x).replace("\\N", " ").strip() for x in body]
        blocks.append(SrtBlock(idx, timecode, body))
    return blocks


def is_english_line(line: str) -> bool:
    return bool(ENG_RE.search(line)) and not CJK_RE.search(line)


def extract_english(lines: list[str]) -> str:
    eng = [x for x in lines if is_english_line(x)]
    if eng:
        return " ".join(eng).strip()
    non_cjk = [x for x in lines if not CJK_RE.search(x)]
    return " ".join(non_cjk).strip()


def extract_chinese(lines: list[str]) -> str:
    zh = [x for x in lines if CJK_RE.search(x)]
    return " ".join(zh).strip()


def format_srt(blocks: list[tuple[SrtBlock, str]], mode: str) -> str:
    out: list[str] = []
    for n, (block, zh) in enumerate(blocks, 1):
        english = extract_english(block.lines)
        out.append(str(n))
        out.append(block.timecode)
        if mode == "zh":
            out.append(zh or "")
        else:
            if english:
                out.append(english)
            if zh:
                out.append(zh)
        out.append("")
    return "\n".join(out).strip() + "\n"


def extract_plain_translation_lines(text: str) -> list[str]:
    """Extract one Chinese translation per subtitle item.

    V62 fix:
    - Plain TXT/manual paste mode: every non-empty Chinese line is one subtitle translation;
      blank lines are ignored, not treated as block separators. This matches the common
      workflow: copy all English lines -> translate -> paste many Chinese lines with extra
      blank lines.
    - SRT/VTT mode: if timestamp lines exist, parse by subtitle blocks and join wrapped
      Chinese lines within each block.
    - English source lines, numeric indexes, timestamps and tags are ignored.
    """
    src = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    src = src.replace("\ufeff", "")
    has_timecode = "-->" in src

    def clean_line(line: str) -> str:
        return re.sub(r"<[^>]+>", "", line).replace("\\N", " ").strip()

    if has_timecode:
        out: list[str] = []
        parts = re.split(r"\n\s*\n", src.strip())
        for part in parts:
            zh_parts: list[str] = []
            for raw in part.split("\n"):
                t = clean_line(raw)
                if not t or t.isdigit() or "-->" in t:
                    continue
                if CJK_RE.search(t):
                    zh_parts.append(t)
            txt = " ".join(zh_parts).strip()
            if txt:
                out.append(txt)
        return out

    # Plain text mode: do NOT merge lines across blank lines. User may paste 1000+
    # translated lines with many blank lines; each meaningful Chinese line must count.
    out: list[str] = []
    for raw in src.split("\n"):
        t = clean_line(raw)
        if not t or t.isdigit() or "-->" in t:
            continue
        if is_english_line(t) and not CJK_RE.search(t):
            continue
        if CJK_RE.search(t):
            out.append(t)
    return out

def write_manual_translation_outputs(src_path: Path, zh_lines: list[str], make_zh: bool = True, make_bilingual: bool = True) -> tuple[Path|None, Path|None, int, int]:
    blocks = parse_srt(src_path)
    pairs = []
    for i, block in enumerate(blocks):
        pairs.append((block, zh_lines[i].strip() if i < len(zh_lines) else ""))
    zh_path = src_path.with_name(src_path.stem + ".zh.srt") if make_zh else None
    bi_path = src_path.with_name(src_path.stem + ".bilingual.srt") if make_bilingual else None
    if zh_path:
        zh_path.write_text(format_srt(pairs, "zh"), encoding="utf-8-sig")
    if bi_path:
        bi_path.write_text(format_srt(pairs, "bilingual"), encoding="utf-8-sig")
    return zh_path, bi_path, min(len(blocks), len(zh_lines)), len(blocks)


class ProductionWorker(QThread):
    progress = Signal(int, int, str)
    log = Signal(str)
    done = Signal(str)
    error = Signal(str)

    def __init__(
        self,
        files: list[str],
        make_zh: bool,
        make_bilingual: bool,
        make_sentence_tts: bool,
        make_chunk_tts: bool,
        make_word_tts: bool,
        make_word_cache: bool,
        translation_engine: str,
        tts_primary_engine: str,
        tts_fallback_engine: str,
        voice: str,
        rate_percent: int,
        volume_percent: int,
        skip_existing: bool,
        max_words_per_chunk: int,
        max_translation_workers: int = 8,
        translation_batch_size: int = 24,
    ):
        super().__init__()
        self.files = files
        self.make_zh = make_zh
        self.make_bilingual = make_bilingual
        self.make_sentence_tts = make_sentence_tts
        self.make_chunk_tts = make_chunk_tts
        self.make_word_tts = make_word_tts
        self.make_word_cache = make_word_cache
        self.translation_engine = translation_engine
        self.tts_primary_engine = tts_primary_engine
        self.tts_fallback_engine = tts_fallback_engine
        self.voice = voice
        self.rate = 1.0 + rate_percent / 100.0
        self.volume = 1.0 + volume_percent / 100.0
        self.skip_existing = skip_existing
        self.max_words_per_chunk = max(1, int(max_words_per_chunk))
        self.max_translation_workers = max(1, min(32, int(max_translation_workers or 1)))
        self.translation_batch_size = max(1, min(100, int(translation_batch_size or 24)))
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def _tts(self, text: str, out: Path) -> tuple[bool, str]:
        if self.skip_existing and out.exists() and out.stat().st_size > 100:
            return True, "skip"
        return synthesize_text(
            text=text,
            out_path=out,
            engine=self.tts_primary_engine,
            fallback_engine=self.tts_fallback_engine,
            voice=self.voice,
            rate=self.rate,
            volume=self.volume,
            log=self.log.emit,
            tts_mode="production",
        )

    def _translate_blocks(self, path: Path, blocks: list[SrtBlock]) -> list[tuple[SrtBlock, str]]:
        """Translate subtitle blocks with cache-aware parallel mode for online/API engines.

        V57 optimization:
        - Existing Chinese lines are reused directly.
        - manual/none does zero translation.
        - opus_local stays single-threaded because local transformer models are heavy and not always thread-safe.
        - google/api/auto modes can translate missing lines concurrently, controlled by 制作台“翻译并发”.
        """
        translated: list[tuple[SrtBlock, str]] = []
        total = len(blocks)
        need_jobs: list[tuple[int, str]] = []
        zh_map: dict[int, str] = {}
        for i, block in enumerate(blocks, 1):
            english = extract_english(block.lines)
            zh = extract_chinese(block.lines)
            if zh:
                zh_map[i] = zh
            elif (self.make_zh or self.make_bilingual) and english and self.translation_engine not in {"manual", "none"}:
                need_jobs.append((i, english))
            else:
                zh_map[i] = ""

        if need_jobs:
            workers = 1 if self.translation_engine == "opus_local" else self.max_translation_workers
            self.log.emit(f"Translation queue: {path.name} missing {len(need_jobs)}/{total}, workers={workers}, engine={self.translation_engine}")
            # V58 speed-up: batch API/Google translations first, then use threaded fallback only for misses.
            batchable = self.translation_engine not in {"opus_local", "manual", "none"}
            if batchable:
                done_i = 0
                for start in range(0, len(need_jobs), self.translation_batch_size):
                    if self._cancel:
                        break
                    group = need_jobs[start:start+self.translation_batch_size]
                    texts = [english for _i, english in group]
                    results = translate_many(texts, self.translation_engine, batch_size=self.translation_batch_size)
                    for (i, _english), zh in zip(group, results):
                        zh_map[i] = zh or ""
                    done_i += len(group)
                    self.progress.emit(done_i, len(need_jobs), f"Batch translate {path.name} {done_i}/{len(need_jobs)}")
            elif workers <= 1:
                for done_i, (i, english) in enumerate(need_jobs, 1):
                    if self._cancel:
                        break
                    self.progress.emit(done_i, len(need_jobs), f"Translate {path.name} {done_i}/{len(need_jobs)}")
                    zh_map[i] = translate_text(english, self.translation_engine) or ""
            else:
                with ThreadPoolExecutor(max_workers=workers) as ex:
                    futs = {ex.submit(translate_text, english, self.translation_engine): i for i, english in need_jobs}
                    done_i = 0
                    for fut in as_completed(futs):
                        if self._cancel:
                            break
                        i = futs[fut]
                        done_i += 1
                        try:
                            zh_map[i] = fut.result() or ""
                        except Exception as e:
                            zh_map[i] = ""
                            self.log.emit(f"Translate failed [{path.name} #{i}]: {e}")
                        self.progress.emit(done_i, len(need_jobs), f"Translate {path.name} {done_i}/{len(need_jobs)}")

        for i, block in enumerate(blocks, 1):
            translated.append((block, zh_map.get(i, "")))
        return translated

    def run(self):
        try:
            total_files = len(self.files)
            finished_files = 0
            for fp in self.files:
                if self._cancel:
                    self.done.emit("Canceled")
                    return
                path = Path(fp)
                self.log.emit(f"=== Start: {path.name} ===")
                blocks = parse_srt(path)
                if not blocks:
                    self.log.emit(f"Skip: failed to parse SRT: {path}")
                    finished_files += 1
                    continue

                zh_path = path.with_name(path.stem + ".zh.srt")
                bi_path = path.with_name(path.stem + ".bilingual.srt")
                subtitle_outputs_exist = ((not self.make_zh) or (zh_path.exists() and zh_path.stat().st_size > 100)) and ((not self.make_bilingual) or (bi_path.exists() and bi_path.stat().st_size > 100))
                need_subtitle_translation = (self.make_zh or self.make_bilingual) and not (self.skip_existing and subtitle_outputs_exist)

                if need_subtitle_translation:
                    translated = self._translate_blocks(path, blocks)
                else:
                    translated = [(block, extract_chinese(block.lines)) for block in blocks]
                    if self.make_zh or self.make_bilingual:
                        self.log.emit(f"Skip existing subtitles: {path.name}")
                if self._cancel:
                    self.done.emit("Canceled")
                    return

                if self.make_zh:
                    if self.skip_existing and zh_path.exists() and zh_path.stat().st_size > 100:
                        self.log.emit(f"ZH subtitle exists, skipped: {zh_path}")
                    else:
                        zh_path.write_text(format_srt(translated, "zh"), encoding="utf-8-sig")
                        self.log.emit(f"ZH subtitle: {zh_path}")

                if self.make_bilingual:
                    if self.skip_existing and bi_path.exists() and bi_path.stat().st_size > 100:
                        self.log.emit(f"Bilingual subtitle exists, skipped: {bi_path}")
                    else:
                        bi_path.write_text(format_srt(translated, "bilingual"), encoding="utf-8-sig")
                        self.log.emit(f"Bilingual subtitle: {bi_path}")

                cache_dir = path.with_name(path.stem + "_tts_cache")
                sent_dir = cache_dir / "sentence"
                chunk_dir = cache_dir / "chunk"
                word_dir = cache_dir / "word"
                manifest: list[dict] = []
                unique_words: dict[str, dict] = {}
                total = max(1, len(translated))

                for i, (block, zh) in enumerate(translated, 1):
                    if self._cancel:
                        self.done.emit("Canceled")
                        return
                    english = extract_english(block.lines)
                    if not english:
                        continue

                    entry = {
                        "index": i,
                        "timecode": block.timecode,
                        "english": english,
                        "chinese": zh,
                        "sentence_audio": "",
                        "chunks": [],
                    }

                    if self.make_sentence_tts:
                        out = sent_dir / f"{i:05d}.mp3"
                        self.progress.emit(i, total, f"Sentence TTS {path.name} {i}/{total}")
                        ok, used = self._tts(english, out)
                        if ok:
                            entry["sentence_audio"] = str(out)
                            entry["sentence_tts_engine"] = used
                        else:
                            self.log.emit(f"Sentence TTS failed [{i}]: {english[:80]}")

                    chunks = segment_chunks(english, "smart", self.max_words_per_chunk)
                    for ci, ch in enumerate(chunks, 1):
                        ch_text = ch.text
                        ch_item = {"index": ci, "text": ch_text, "audio": "", "words": ch.words}
                        if self.make_chunk_tts and ch_text:
                            out = chunk_dir / f"{i:05d}_{ci:03d}.mp3"
                            self.progress.emit(ci, max(1, len(chunks)), f"Chunk TTS {path.name} {i}/{total}.{ci}")
                            ok, used = self._tts(ch_text, out)
                            if ok:
                                ch_item["audio"] = str(out)
                                ch_item["tts_engine"] = used
                        entry["chunks"].append(ch_item)
                        for w in ch.words:
                            key = w.lower().replace("’", "'")
                            if key not in unique_words:
                                unique_words[key] = {"word": w, "audio": ""}
                    manifest.append(entry)

                if self.make_word_tts:
                    words = list(unique_words.values())
                    for wi, item in enumerate(words, 1):
                        if self._cancel:
                            self.done.emit("Canceled")
                            return
                        word = item["word"]
                        out = word_dir / (safe_name(word) + "_" + text_hash(word, self.tts_primary_engine, self.voice)[:8] + ".mp3")
                        self.progress.emit(wi, max(1, len(words)), f"Word TTS {path.name} {wi}/{len(words)}")
                        ok, used = self._tts(word, out)
                        if ok:
                            item["audio"] = str(out)
                            item["tts_engine"] = used

                if self.make_word_cache:
                    word_cache = {}
                    all_text = "\n".join(extract_english(b.lines) for b in blocks)
                    infos = lookup_sentence_words(all_text)
                    for w, info in infos.items():
                        word_cache[w.lower()] = {
                            "word": w,
                            "ipa_uk": getattr(info, "ipa_uk", "") if info else "",
                            "ipa_us": getattr(info, "ipa_us", "") if info else "",
                            "phonetic": getattr(info, "phonetic", "") if info else "",
                            "pos": getattr(info, "pos", "") if info else "",
                            "zh": getattr(info, "zh", "") if info else "",
                            "en_def": getattr(info, "en_def", "") if info else "",
                            "source": getattr(info, "source", "") if info else "",
                        }
                    (cache_dir / "word_cache.json").parent.mkdir(parents=True, exist_ok=True)
                    (cache_dir / "word_cache.json").write_text(json.dumps(word_cache, ensure_ascii=False, indent=2), encoding="utf-8")
                    self.log.emit(f"Word cache: {cache_dir / 'word_cache.json'}")

                cache_dir.mkdir(parents=True, exist_ok=True)
                (cache_dir / "manifest.json").write_text(json.dumps({
                    "source_srt": str(path),
                    "translation_engine": self.translation_engine,
                    "tts_primary_engine": self.tts_primary_engine,
                    "tts_fallback_engine": self.tts_fallback_engine,
                    "voice": self.voice,
                    "items": manifest,
                    "words": list(unique_words.values()),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
                self.log.emit(f"Manifest: {cache_dir / 'manifest.json'}")

                finished_files += 1
                self.progress.emit(finished_files, total_files, f"File done {finished_files}/{total_files}")

            self.done.emit(f"Done: {finished_files}/{total_files} files")
        except Exception as e:
            self.error.emit(str(e) + "\n" + traceback.format_exc())


class ManualTranslationDialog(QDialog):
    """V61: manual-translation input window with line-count validation and explicit result feedback."""
    def __init__(self, parent=None, src_name: str = "", initial_text: str = "", expected_count: int = 0):
        super().__init__(parent)
        self.setWindowTitle("手动翻译导入｜粘贴中文 / 导入 TXT-SRT-VTT")
        self.resize(980, 740)
        self.result_text = ""
        self.expected_count = int(expected_count or 0)
        root = QVBoxLayout(self)
        tip = QLabel(
            f"英文字幕：{src_name}\n"
            "把手动翻译好的中文逐行粘贴到下面；也可以导入 TXT / SRT / VTT。\n"
            "点击生成前，程序会先检查：识别到的中文行数 是否与 英文字幕条数一致；一致后按顺序插入到英文字幕时间轴里，生成 .zh.srt / .bilingual.srt。"
        )
        tip.setWordWrap(True); root.addWidget(tip)
        btns = QHBoxLayout()
        self.import_btn = QPushButton("导入字幕/纯文本文件")
        self.import_btn.clicked.connect(self.import_file)
        self.clip_btn = QPushButton("从剪贴板粘贴")
        self.clip_btn.clicked.connect(lambda: self.text_edit.setPlainText(QApplication.clipboard().text()))
        self.clear_btn = QPushButton("清空")
        self.clear_btn.clicked.connect(lambda: self.text_edit.clear())
        for b in [self.import_btn, self.clip_btn, self.clear_btn]: btns.addWidget(b)
        btns.addStretch(); root.addLayout(btns)
        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText(
            "在这里粘贴中文翻译：\n"
            "第 1 行中文翻译对应英文 SRT 第 1 条台词\n"
            "第 2 行对应第 2 条……\n"
            "也允许粘贴带序号/时间轴的 SRT/VTT 内容，程序会自动清洗。"
        )
        self.text_edit.setPlainText(initial_text or "")
        self.text_edit.textChanged.connect(self.update_preview)
        root.addWidget(self.text_edit, 1)
        self.preview = QLabel("")
        self.preview.setWordWrap(True); root.addWidget(self.preview)
        bottom = QHBoxLayout()
        self.ok_btn = QPushButton("检查数量并生成中文字幕/双语字幕")
        self.ok_btn.clicked.connect(self.accept_text)
        cancel = QPushButton("取消")
        cancel.clicked.connect(self.reject)
        bottom.addStretch(); bottom.addWidget(self.ok_btn); bottom.addWidget(cancel); root.addLayout(bottom)
        self.update_preview()

    def import_file(self):
        fn, _ = QFileDialog.getOpenFileName(self, "选择手动翻译文件", "", "Text/Subtitles (*.txt *.srt *.vtt);;All Files (*.*)")
        if fn:
            self.text_edit.setPlainText(read_text_auto(Path(fn)))

    def parsed_lines(self) -> list[str]:
        return extract_plain_translation_lines(self.text_edit.toPlainText())

    def update_preview(self):
        n = len(self.parsed_lines())
        if self.expected_count:
            ok = "匹配" if n == self.expected_count else "不匹配"
            self.preview.setText(f"数量校验：识别到中文 {n} 行 / 英文字幕 {self.expected_count} 条 → {ok}。")
        else:
            self.preview.setText(f"数量校验：识别到中文 {n} 行。")

    def accept_text(self):
        self.result_text = self.text_edit.toPlainText()
        zh_lines = self.parsed_lines()
        if not zh_lines:
            QMessageBox.warning(self, "手动翻译", "输入框为空，或者没有识别到中文翻译。请粘贴中文翻译或导入文件。")
            return
        if self.expected_count and len(zh_lines) != self.expected_count:
            ret = QMessageBox.question(
                self,
                "数量不匹配",
                f"英文字幕共有 {self.expected_count} 条，但当前识别到中文 {len(zh_lines)} 行。\n\n"
                "数量不一致时，后面的字幕可能错位。是否仍然生成？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if ret != QMessageBox.Yes:
                return
        self.accept()


class ProductionWorkbench(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("制作台：字幕翻译 / Kokoro-EdgeTTS 音频缓存")
        self.resize(1080, 800)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint)
        self.setModal(False)
        self._started_ts = 0.0
        self._last_cur = 0
        self._last_total = 1
        self.worker: ProductionWorker | None = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.root_edit = QLineEdit(str(app_settings.get("last_scan_root", "")))
        top.addWidget(QLabel("资源文件夹"))
        top.addWidget(self.root_edit, 1)
        browse = QPushButton("选择文件夹")
        browse.clicked.connect(self.choose_folder)
        top.addWidget(browse)
        scan = QPushButton("扫描 SRT")
        scan.clicked.connect(self.scan_srt)
        top.addWidget(scan)
        root.addLayout(top)

        self.file_list = QListWidget()
        self.file_list.setSelectionMode(QListWidget.ExtendedSelection)
        root.addWidget(self.file_list, 1)
        file_btns = QHBoxLayout()
        self.select_all_btn = QPushButton("全选SRT"); self.select_all_btn.clicked.connect(lambda: self.set_all_files(Qt.Checked))
        self.invert_btn = QPushButton("反选SRT"); self.invert_btn.clicked.connect(self.invert_files)
        self.clear_btn = QPushButton("清空选择"); self.clear_btn.clicked.connect(lambda: self.set_all_files(Qt.Unchecked))
        self.copy_en_btn = QPushButton("复制英文台词"); self.copy_en_btn.clicked.connect(self.copy_english_lines)
        self.paste_manual_btn = QPushButton("粘贴中文生成字幕"); self.paste_manual_btn.clicked.connect(self.paste_manual_translations)
        self.import_manual_btn = QPushButton("导入翻译TXT/SRT生成"); self.import_manual_btn.clicked.connect(self.import_manual_translation_file)
        for b in [self.select_all_btn, self.invert_btn, self.clear_btn, self.copy_en_btn, self.paste_manual_btn, self.import_manual_btn]:
            file_btns.addWidget(b)
        file_btns.addStretch(); root.addLayout(file_btns)

        self.toggle_opts_btn = QPushButton("折叠/展开制作选项")
        self.toggle_opts_btn.clicked.connect(self.toggle_options)
        root.addWidget(self.toggle_opts_btn)
        opts = QGroupBox("制作选项：慢任务在制作台处理，训练台只读缓存")
        grid = QGridLayout(opts)
        self.make_zh = QCheckBox("生成中文翻译字幕：原名.zh.srt")
        self.make_zh.setChecked(True)
        self.make_bi = QCheckBox("生成双语字幕：原名.bilingual.srt")
        self.make_bi.setChecked(True)
        self.make_sentence_tts = QCheckBox("生成整句 MP3：_tts_cache/sentence")
        self.make_sentence_tts.setChecked(bool(app_settings.get("production_make_sentence_tts", True)))
        self.make_chunk_tts = QCheckBox("生成语块 MP3：_tts_cache/chunk")
        self.make_chunk_tts.setChecked(bool(app_settings.get("production_make_chunk_tts", True)))
        self.make_word_tts = QCheckBox("生成单词 MP3：_tts_cache/word（量大，默认关闭）")
        self.make_word_tts.setChecked(bool(app_settings.get("production_make_word_tts", False)))
        self.make_word_cache = QCheckBox("生成 word_cache.json：音标/词性/释义缓存")
        self.make_word_cache.setChecked(bool(app_settings.get("production_make_word_cache", True)))
        self.skip_existing = QCheckBox("已存在音频/字幕则跳过")
        self.skip_existing.setChecked(bool(app_settings.get("production_skip_existing", True)))

        grid.addWidget(self.make_zh, 0, 0, 1, 2)
        grid.addWidget(self.make_bi, 1, 0, 1, 2)
        grid.addWidget(self.make_sentence_tts, 2, 0, 1, 2)
        grid.addWidget(self.make_chunk_tts, 3, 0, 1, 2)
        grid.addWidget(self.make_word_tts, 4, 0, 1, 2)
        grid.addWidget(self.make_word_cache, 5, 0, 1, 2)
        grid.addWidget(self.skip_existing, 6, 0, 1, 2)

        self.engine = QComboBox()
        self.engine.addItems(["auto_google_opus", "api_google_opus", "opus_google_api", "api_online", "google_online", "opus_local", "manual", "none"])
        self.engine.setCurrentText(str(app_settings.get("translation_engine", "auto_google_opus")))
        grid.addWidget(QLabel("翻译引擎"), 0, 2)
        grid.addWidget(self.engine, 0, 3)

        self.tts_engine = QComboBox()
        self.tts_engine.addItems(["kokoro", "melotts", "styletts2", "chattts", "edge_tts"])
        self.tts_engine.setCurrentText(str(app_settings.get("production_tts_primary_engine", "kokoro")))
        grid.addWidget(QLabel("TTS主引擎"), 1, 2)
        grid.addWidget(self.tts_engine, 1, 3)

        self.fallback_engine = QComboBox()
        self.fallback_engine.addItems(["edge_tts", "kokoro", "styletts2", "melotts", "chattts", "none"])
        self.fallback_engine.setCurrentText(str(app_settings.get("production_tts_fallback_engine", "edge_tts")))
        grid.addWidget(QLabel("TTS兜底引擎"), 2, 2)
        grid.addWidget(self.fallback_engine, 2, 3)

        self.voice = QLineEdit(str(app_settings.get("kokoro_voice", "af_heart") or app_settings.get("speech_voice", "en-US-AriaNeural")))
        grid.addWidget(QLabel("Voice / Speaker"), 3, 2)
        grid.addWidget(self.voice, 3, 3)

        self.rate = QSpinBox(); self.rate.setRange(-80, 80); self.rate.setValue(0); self.rate.setSuffix("%")
        grid.addWidget(QLabel("TTS速度修正"), 4, 2); grid.addWidget(self.rate, 4, 3)
        self.volume = QSpinBox(); self.volume.setRange(-80, 80); self.volume.setValue(0); self.volume.setSuffix("%")
        grid.addWidget(QLabel("TTS音量修正"), 5, 2); grid.addWidget(self.volume, 5, 3)
        self.max_words = QSpinBox(); self.max_words.setRange(1, 8); self.max_words.setValue(int(app_settings.get("max_words_per_chunk", 3)))
        grid.addWidget(QLabel("语块最多单词"), 6, 2); grid.addWidget(self.max_words, 6, 3)
        self.translation_workers = QSpinBox(); self.translation_workers.setRange(1, 32); self.translation_workers.setValue(int(app_settings.get("production_translation_workers", 8)))
        self.translation_workers.setToolTip("翻译字幕的并发数；在线/API 引擎可加速，OPUS 本地会自动单线程。")
        grid.addWidget(QLabel("翻译并发"), 7, 2); grid.addWidget(self.translation_workers, 7, 3)
        self.translation_batch = QSpinBox(); self.translation_batch.setRange(1, 100); self.translation_batch.setValue(int(app_settings.get("production_translation_batch_size", 24)))
        self.translation_batch.setToolTip("V58：API/Google 批量翻译每批台词数量。API 批量越大越快，但过大可能超时。")
        grid.addWidget(QLabel("批量翻译/批"), 8, 2); grid.addWidget(self.translation_batch, 8, 3)
        self.opts_box = opts
        root.addWidget(opts)

        buttons = QHBoxLayout()
        self.start_btn = QPushButton("开始制作")
        self.start_btn.clicked.connect(self.start_jobs)
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.clicked.connect(self.cancel_jobs)
        self.cancel_btn.setEnabled(False)
        buttons.addWidget(self.start_btn)
        buttons.addWidget(self.cancel_btn)
        buttons.addStretch()
        root.addLayout(buttons)

        self.progress = QProgressBar()
        root.addWidget(self.progress)
        self.eta_box = QGroupBox("彩色 ETA 面板")
        eta_layout = QGridLayout(self.eta_box)
        self.eta_phase = QLabel("阶段：等待开始"); self.eta_done = QLabel("进度：0/0")
        self.eta_elapsed = QLabel("已用：00:00"); self.eta_left = QLabel("预计剩余：--:--")
        for i,w in enumerate([self.eta_phase, self.eta_done, self.eta_elapsed, self.eta_left]):
            w.setMinimumHeight(30); w.setAlignment(Qt.AlignCenter); w.setStyleSheet("QLabel{border-radius:10px;padding:6px;background:#E0F2FE;color:#0F172A;font-weight:700;}")
            eta_layout.addWidget(w, i//2, i%2)
        root.addWidget(self.eta_box)
        self.log = QTextEdit(); self.log.setReadOnly(True)
        root.addWidget(self.log, 1)

        self.log.append("提示：Kokoro 若不可用会自动按兜底引擎生成。V60 已加入真实手动翻译输入框/导入框、批量翻译、32并发上限、已有字幕跳过；API翻译参数在设置中心填写。")
        if self.root_edit.text().strip():
            self.scan_srt()

    def toggle_options(self):
        self.opts_box.setVisible(not self.opts_box.isVisible())

    def set_all_files(self, state):
        for i in range(self.file_list.count()):
            self.file_list.item(i).setCheckState(state)

    def invert_files(self):
        for i in range(self.file_list.count()):
            it = self.file_list.item(i)
            it.setCheckState(Qt.Unchecked if it.checkState() == Qt.Checked else Qt.Checked)

    def _first_checked_file(self) -> Path | None:
        files = self.selected_files()
        return Path(files[0]) if files else None

    def copy_english_lines(self):
        path = self._first_checked_file()
        if not path:
            QMessageBox.warning(self, "制作台", "请先勾选一个英文 SRT。")
            return
        blocks = parse_srt(path)
        QApplication.clipboard().setText("\n".join(extract_english(b.lines) for b in blocks))
        self.log.append(f"已复制英文台词：{path.name}，{len(blocks)} 行，不含时间线。")

    def _generate_manual_for_path(self, src: Path, zh_text: str):
        zh_lines = extract_plain_translation_lines(zh_text)
        if not zh_lines:
            QMessageBox.warning(self, "制作台", "没有识别到中文翻译内容。")
            return
        blocks = parse_srt(src)
        if len(zh_lines) != len(blocks):
            ret = QMessageBox.question(
                self,
                "数量不匹配",
                f"英文字幕共有 {len(blocks)} 条，中文翻译识别到 {len(zh_lines)} 行。\n\n数量不一致时，字幕可能错位。是否仍然生成？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if ret != QMessageBox.Yes:
                self.log.append(f"已取消半自动生成：{src.name}，数量不匹配 {len(zh_lines)}/{len(blocks)}")
                return
        zh_path, bi_path, matched, total = write_manual_translation_outputs(src, zh_lines, self.make_zh.isChecked(), self.make_bi.isChecked())
        self.log.append(f"半自动字幕生成完成：{src.name} → 匹配 {matched}/{total} 行")
        if zh_path: self.log.append(f"ZH subtitle: {zh_path}")
        if bi_path: self.log.append(f"Bilingual subtitle: {bi_path}")
        self.log.ensureCursorVisible()
        QMessageBox.information(self, "半自动字幕生成完成", f"已生成字幕：\n{zh_path or ''}\n{bi_path or ''}\n\n匹配：{matched}/{total} 行")

    def paste_manual_translations(self):
        src = self._first_checked_file()
        if not src:
            QMessageBox.warning(self, "制作台", "请先勾选一个英文 SRT。")
            return
        dlg = ManualTranslationDialog(self, src.name, QApplication.clipboard().text(), expected_count=len(parse_srt(src)))
        if dlg.exec() == QDialog.Accepted:
            self._generate_manual_for_path(src, dlg.result_text)

    def import_manual_translation_file(self):
        src = self._first_checked_file()
        if not src:
            QMessageBox.warning(self, "制作台", "请先勾选一个英文 SRT。")
            return
        dlg = ManualTranslationDialog(self, src.name, "", expected_count=len(parse_srt(src)))
        dlg.import_file()
        if dlg.text_edit.toPlainText().strip() and dlg.exec() == QDialog.Accepted:
            self._generate_manual_for_path(src, dlg.result_text)

    def choose_folder(self):
        d = QFileDialog.getExistingDirectory(self, "选择包含 SRT 的资源文件夹", self.root_edit.text().strip() or "")
        if d:
            self.root_edit.setText(d)
            app_settings.set("last_scan_root", d)
            self.scan_srt()

    def scan_srt(self):
        root = Path(self.root_edit.text().strip())
        self.file_list.clear()
        if not root.exists():
            self.log.append("文件夹不存在。")
            return
        files = sorted([p for p in root.rglob("*.srt") if not p.name.endswith((".zh.srt", ".bilingual.srt"))], key=lambda p: str(p).lower())
        for p in files:
            item = QListWidgetItem(str(p))
            item.setCheckState(Qt.Checked)
            self.file_list.addItem(item)
        self.log.append(f"扫描完成：{len(files)} 个 SRT")

    def selected_files(self) -> list[str]:
        return [self.file_list.item(i).text() for i in range(self.file_list.count()) if self.file_list.item(i).checkState() == Qt.Checked]

    def start_jobs(self):
        files = self.selected_files()
        if not files:
            QMessageBox.warning(self, "制作台", "请至少勾选一个 SRT 文件。")
            return
        for key, val in {
            "production_tts_primary_engine": self.tts_engine.currentText(),
            "production_tts_fallback_engine": self.fallback_engine.currentText(),
            "production_make_sentence_tts": self.make_sentence_tts.isChecked(),
            "production_make_chunk_tts": self.make_chunk_tts.isChecked(),
            "production_make_word_tts": self.make_word_tts.isChecked(),
            "production_make_word_cache": self.make_word_cache.isChecked(),
            "production_skip_existing": self.skip_existing.isChecked(),
            "production_translation_workers": self.translation_workers.value(),
            "production_translation_batch_size": self.translation_batch.value(),
        }.items():
            app_settings.set(key, val)
        self.start_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self._started_ts = time.time(); self._last_cur = 0; self._last_total = max(1, len(files))
        self.progress.setValue(0)
        self.eta_phase.setText("阶段：启动制作任务")
        self.eta_done.setText(f"任务：0/{len(files)}")
        self.eta_elapsed.setText("已用：00:00")
        self.eta_left.setText("预计剩余：计算中")
        self.worker = ProductionWorker(
            files=files,
            make_zh=self.make_zh.isChecked(),
            make_bilingual=self.make_bi.isChecked(),
            make_sentence_tts=self.make_sentence_tts.isChecked(),
            make_chunk_tts=self.make_chunk_tts.isChecked(),
            make_word_tts=self.make_word_tts.isChecked(),
            make_word_cache=self.make_word_cache.isChecked(),
            translation_engine=self.engine.currentText(),
            tts_primary_engine=self.tts_engine.currentText(),
            tts_fallback_engine=self.fallback_engine.currentText(),
            voice=self.voice.text().strip() or "af_heart",
            rate_percent=self.rate.value(),
            volume_percent=self.volume.value(),
            skip_existing=self.skip_existing.isChecked(),
            max_words_per_chunk=self.max_words.value(),
            max_translation_workers=self.translation_workers.value(),
            translation_batch_size=self.translation_batch.value(),
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.log.connect(self.log.append)
        self.worker.done.connect(self.on_done)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def cancel_jobs(self):
        if self.worker:
            self.worker.cancel()
        self.log.append("正在取消，等待当前任务结束……")

    def on_progress(self, cur: int, total: int, msg: str):
        self.progress.setMaximum(max(1, total))
        self.progress.setValue(max(0, cur))
        self._last_cur, self._last_total = max(0, cur), max(1, total)
        elapsed = max(0.0, time.time() - float(self._started_ts or time.time()))
        left = 0.0 if cur <= 0 else max(0.0, elapsed * (total - cur) / max(1, cur))
        def fmt(sec):
            sec = int(sec); return f"{sec//60:02d}:{sec%60:02d}"
        self.eta_phase.setText("阶段：" + str(msg)[:80])
        self.eta_done.setText(f"进度：{cur}/{total}  |  {int(cur*100/max(1,total))}%")
        self.eta_elapsed.setText("已用：" + fmt(elapsed))
        self.eta_left.setText("预计剩余：" + (fmt(left) if cur > 0 else "计算中"))
        self.log.append(msg)

    def on_done(self, msg: str):
        self.log.append(msg)
        self.start_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)

    def on_error(self, msg: str):
        self.log.append("错误：\n" + msg)
        self.start_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
