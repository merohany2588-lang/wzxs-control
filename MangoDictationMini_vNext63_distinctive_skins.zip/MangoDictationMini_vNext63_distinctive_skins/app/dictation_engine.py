from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Iterable
from .models import Token, Chunk, WordInfo

WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?(?:-[A-Za-z]+)*|\d+(?:\.\d+)?(?::\d+)?")
TOKEN_RE = re.compile(r"([A-Za-z]+(?:'[A-Za-z]+)?(?:-[A-Za-z]+)*|\d+(?:\.\d+)?(?::\d+)?|[^\s\w])")

AUX = {"am","is","are","was","were","be","been","being","do","does","did","have","has","had","will","would","can","could","should","may","might","must"}
PREP = {"to","of","in","on","at","for","from","with","about","as","by","into","over","after","before","under","through","between","without","within","up","down","out","off"}
PRON = {"i","you","he","she","it","we","they","me","him","her","us","them","my","your","his","our","their","myself","yourself","herself","himself","itself","ourselves","themselves"}
DET = {"a","an","the","this","that","these","those","some","any","each","every","no","my","your","his","her","our","their"}
COMMON_VERBS = {"get","go","come","make","take","give","have","do","be","want","know","think","see","look","say","tell","need","help","play","work","try","feel","find","leave","let","hurry","wait","keep","show","tell","ask"}
WH_WORDS = {"what","who","when","where","why","how","which"}
LINKING = {"be","am","is","are","was","were","seem","look","feel","become","stay"}
PARTICLES = {"up","down","out","off","on","over","away","back","around","along","through"}


def tokenize_sentence(sentence: str) -> list[Token]:
    out: list[Token] = []
    for part in TOKEN_RE.findall(sentence or ""):
        out.append(Token(part, bool(WORD_RE.fullmatch(part))))
    return out


def normalize_word(text: str, ignore_case: bool = True, ignore_punctuation: bool = True) -> str:
    s = str(text or "").strip()
    s = s.replace("’", "'").replace("`", "'").replace("´", "'")
    if ignore_punctuation:
        s = re.sub(r"^[^\w']+|[^\w']+$", "", s)
    s = re.sub(r"\s+", " ", s)
    if ignore_case:
        s = s.lower()
    return s


def check_word(user_input: str, expected: str, ignore_case: bool = True, ignore_punctuation: bool = True) -> bool:
    return normalize_word(user_input, ignore_case, ignore_punctuation) == normalize_word(expected, ignore_case, ignore_punctuation)


def check_sentence(user_inputs: list[str], tokens: list[Token], ignore_case: bool = True, ignore_punctuation: bool = True) -> tuple[bool, list[bool]]:
    word_tokens = [t for t in tokens if t.is_word]
    results: list[bool] = []
    ok = True
    for i, token in enumerate(word_tokens):
        good = i < len(user_inputs) and check_word(user_inputs[i], token.text, ignore_case, ignore_punctuation)
        results.append(good)
        ok = ok and good
    return ok, results


def _pos_guess(word: str, info: WordInfo | None = None) -> str:
    if info and info.pos:
        p = info.pos.lower()
        if "verb" in p or p.startswith("v"):
            return "verb"
        if "noun" in p or p.startswith("n"):
            return "noun"
        if "adj" in p:
            return "adj"
        if "adv" in p:
            return "adv"
        if "prep" in p or "介" in p:
            return "prep"
        if "pron" in p or "代" in p:
            return "pron"
        if "det" in p:
            return "det"
        return info.pos
    w = word.lower()
    if w in PRON:
        return "pron"
    if w in DET:
        return "det"
    if w in PREP:
        return "prep"
    if w in AUX or w in COMMON_VERBS or w.endswith("ed") or w.endswith("ing"):
        return "verb"
    if w.endswith("ly"):
        return "adv"
    if w.endswith(("ous","ful","able","ive","al","ic","less")):
        return "adj"
    return "noun/other"


def _smart_chunk_indices(words: list[str], max_words_per_chunk: int = 3) -> list[tuple[int, int]]:
    lows = [w.lower() for w in words]
    n = len(words)
    maxn = max(2, int(max_words_per_chunk))
    out: list[tuple[int, int]] = []
    i = 0
    while i < n:
        start = i
        w = lows[i]
        end = min(i + maxn - 1, n - 1)

        # WH / pronoun / subject led chunks: try to keep short clause cores together.
        if w in WH_WORDS or w in PRON or w in DET:
            j = i + 1
            if j < n and lows[j] in AUX:
                j += 1
            if j < n and lows[j] in {"not", "n't"}:
                j += 1
            if j < n and (lows[j] in COMMON_VERBS or lows[j] in LINKING or lows[j].endswith(("ing", "ed", "s"))):
                j += 1
            if j < n and (j - start) < maxn and lows[j] in PARTICLES:
                j += 1
            end = min(max(j - 1, start), n - 1)

        # Preposition phrase: keep preposition + object together where possible.
        elif w in PREP:
            j = min(i + 1, n - 1)
            if j + 1 < n and lows[j] in DET and (j + 1 - start) < maxn:
                j += 1
            if j + 1 < n and (j + 1 - start) < maxn and lows[j + 1] not in PREP:
                j += 1
            end = j

        # Auxiliary / light verb chunks.
        elif w in AUX or w in COMMON_VERBS:
            j = i + 1
            if j < n and lows[j] in {"not", "n't"}:
                j += 1
            if j < n and (j - start) < maxn:
                j += 1
            if j < n and (j - start) < maxn and lows[j] in PARTICLES | PRON:
                j += 1
            end = min(max(j - 1, start), n - 1)

        # Noun phrase / leftovers.
        else:
            end = min(i + maxn - 1, n - 1)
            while end > start and lows[end] in DET | PREP | {"and", "or", "but"}:
                end -= 1

        # Do not leave trailing function words stranded.
        if end < n - 1 and lows[end] in DET | PREP:
            end += 1
        if out and start <= out[-1][1]:
            start = out[-1][1] + 1
        if start > end:
            end = start
        out.append((start, end))
        i = end + 1
    return out


def segment_chunks(sentence: str, mode: str = "smart", max_words_per_chunk: int = 3) -> list[Chunk]:
    tokens = tokenize_sentence(sentence)
    words: list[str] = [t.text for t in tokens if t.is_word]
    if not words:
        return []
    if mode == "word":
        chunks = [Chunk(text=w, words=[w], start_word_index=i, end_word_index=i) for i, w in enumerate(words)]
    else:
        spans = _smart_chunk_indices(words, max_words_per_chunk=max_words_per_chunk)
        chunks = [Chunk(text=" ".join(words[s:e+1]), words=words[s:e+1], start_word_index=s, end_word_index=e) for s, e in spans]
    # attach punctuation roughly to previous chunk
    word_seen = -1
    chunk_by_end = {c.end_word_index: c for c in chunks}
    for t in tokens:
        if t.is_word:
            word_seen += 1
        else:
            c = chunk_by_end.get(word_seen)
            if c:
                c.trailing_punct += t.text
    return chunks


def chunk_component_hint(chunk_words: list[str], lookup=None) -> str:
    if not chunk_words:
        return "句子成分提示：短语功能不确定，先按词性和上下文判断。"
    lows = [w.lower() for w in chunk_words]
    infos = [lookup(w) if lookup else None for w in chunk_words]
    pos = [_pos_guess(w, info) for w, info in zip(chunk_words, infos)]
    if any(p == "verb" for p in pos):
        if lows[0] in AUX or any(w in {"gonna", "going"} for w in lows):
            return "句子成分提示：谓语/动词短语。注意助动词、时态、三单和固定搭配。"
        return "句子成分提示：动词核心结构。优先检查动词形式、时态和主谓一致。"
    if pos and pos[0] in {"prep"}:
        return "句子成分提示：介词短语。常作地点、时间、方式或补充说明。"
    if pos and pos[0] in {"pron", "det"}:
        return "句子成分提示：名词性成分/主宾表语可能性高。注意代词、冠词和名词单复数。"
    if len(chunk_words) == 1:
        return f"句子成分提示：单词功能不确定，先看词性：{pos[0]}。"
    return "句子成分提示：短语功能不确定，先按词性和上下文判断。"


def _base_forms(word: str) -> set[str]:
    w = word.lower()
    forms = {w}
    if w.endswith("ies") and len(w) > 4:
        forms.add(w[:-3] + "y")
    if w.endswith("ves") and len(w) > 4:
        forms.add(w[:-3] + "f"); forms.add(w[:-3] + "fe")
    if w.endswith("es") and len(w) > 3:
        forms.add(w[:-2])
    if w.endswith("s") and len(w) > 3:
        forms.add(w[:-1])
    if w.endswith("ied") and len(w) > 4:
        forms.add(w[:-3] + "y")
    if w.endswith("ed") and len(w) > 4:
        forms.add(w[:-2]); forms.add(w[:-1])
    if w.endswith("ing") and len(w) > 5:
        forms.add(w[:-3]); forms.add(w[:-3] + "e")
    return forms


def diagnose_word_error(expected: str, user: str, expected_info: WordInfo | None = None, user_info: WordInfo | None = None) -> str:
    exp = normalize_word(expected)
    got = normalize_word(user)
    if not got:
        return "未输入"
    if got == exp:
        return "正确"
    exp_bases = _base_forms(exp)
    got_bases = _base_forms(got)
    if exp in got_bases or got in exp_bases or exp_bases & got_bases:
        # noun plural or verb forms
        p = _pos_guess(expected, expected_info)
        if p == "verb" or exp.endswith(("ed","ing")) or got.endswith(("ed","ing","s")):
            return "疑似动词形式错误：检查 V1/V2/V3、三单或 ing 形式。"
        return "疑似单复数错误：检查名词单复数或所有格。"
    if expected_info and user_info:
        ep = _pos_guess(expected, expected_info)
        up = _pos_guess(user, user_info)
        if ep != up:
            return f"疑似词性错误：目标可能是 {ep}，你输入像 {up}。"
    if abs(len(exp) - len(got)) <= 2 and (exp[:1] == got[:1] or exp[-1:] == got[-1:]):
        return "其他拼写错误：首尾或长度接近，请检查中间字母。"
    return "其他拼写错误。"
