from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from pathlib import Path


def _write(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except Exception:
        pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    args = parser.parse_args()

    req_path = Path(args.request)
    req = json.loads(req_path.read_text(encoding="utf-8"))
    data_dir = Path(str(req.get("data_dir") or Path.cwd() / "data"))
    report = data_dir / "styletts2_last_error.log"

    text = str(req.get("text") or "")
    output = Path(str(req.get("output") or ""))
    checkpoint = Path(str(req.get("checkpoint") or ""))
    config = Path(str(req.get("config") or ""))
    model_dir = Path(str(req.get("model_dir") or ""))
    diffusion_steps = int(req.get("diffusion_steps") or 20)
    alpha = float(req.get("alpha") or 0.3)
    beta = float(req.get("beta") or 0.7)

    lines: list[str] = []
    def log(x: str) -> None:
        lines.append(str(x))

    log("worker=styletts2_subprocess")
    log(f"python={sys.executable}")
    log("call_style=from styletts2 import tts; tts.StyleTTS2(model_checkpoint_path, config_path); inference(...)")
    log(f"model_dir={model_dir} exists={model_dir.exists()}")
    log(f"checkpoint={checkpoint} exists={checkpoint.exists()}")
    log(f"config={config} exists={config.exists()}")
    log(f"output={output}")
    log(f"diffusion_steps={diffusion_steps} alpha={alpha} beta={beta}")

    if not text.strip():
        log("FAIL: empty text")
        _write(report, "\n".join(lines))
        return 10
    if not checkpoint.exists():
        log("FAIL: checkpoint missing")
        _write(report, "\n".join(lines))
        return 11
    if not config.exists():
        log("FAIL: config missing")
        _write(report, "\n".join(lines))
        return 12

    try:
        from styletts2 import tts  # type: ignore
        import soundfile as sf

        my_tts = tts.StyleTTS2(
            model_checkpoint_path=str(checkpoint),
            config_path=str(config),
        )
        wav = my_tts.inference(
            text=text,
            diffusion_steps=diffusion_steps,
            alpha=alpha,
            beta=beta,
            output_wav_file=None,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        sf.write(str(output), wav, 24000)
        ok = output.exists() and output.stat().st_size > 100
        log(f"ok={ok} size={output.stat().st_size if output.exists() else 0}")
        _write(report, "\n".join(lines))
        return 0 if ok else 20
    except Exception as e:
        log("EXCEPTION: " + repr(e))
        log(traceback.format_exc())
        _write(report, "\n".join(lines))
        return 30


if __name__ == "__main__":
    raise SystemExit(main())
