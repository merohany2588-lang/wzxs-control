from __future__ import annotations
import asyncio, hashlib, os, shutil, subprocess, threading
from pathlib import Path
from typing import Optional, Callable
from PySide6.QtCore import QUrl, QTimer
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from .settings import app_settings

ROOT = Path(__file__).resolve().parents[1]
CACHE_DIR = ROOT / "cache" / "tts"

VOICE_PRESETS = {
    "edge_tts": {
        ("en-US", "female"): "en-US-AriaNeural",
        ("en-US", "male"): "en-US-GuyNeural",
        ("en-GB", "female"): "en-GB-SoniaNeural",
        ("en-GB", "male"): "en-GB-RyanNeural",
        ("en-AU", "female"): "en-AU-NatashaNeural",
        ("en-AU", "male"): "en-AU-WilliamNeural",
        ("en-CA", "female"): "en-CA-ClaraNeural",
        ("en-CA", "male"): "en-CA-LiamNeural",
    },
    "kokoro": {
        ("en-US", "female"): "af_heart",
        ("en-US", "male"): "am_adam",
        ("en-GB", "female"): "bf_emma",
        ("en-GB", "male"): "bm_george",
    },
}

def _voice_for_engine(engine: str) -> str:
    region = str(app_settings.get("speech_voice_region", "en-US") or "en-US")
    gender = str(app_settings.get("speech_voice_gender", "female") or "female")
    if engine == "edge_tts":
        explicit = str(app_settings.get("speech_voice", "") or "").strip()
        return explicit or VOICE_PRESETS["edge_tts"].get((region, gender), "en-US-AriaNeural")
    if engine == "kokoro":
        explicit = str(app_settings.get("kokoro_voice", "") or "").strip()
        return explicit or VOICE_PRESETS["kokoro"].get((region, gender), "af_heart")
    if engine == "melotts":
        return str(app_settings.get("melotts_speaker", "EN-US") or "EN-US")
    if engine == "styletts2":
        return "styletts2"
    return str(app_settings.get("speech_voice", "") or "")


def _ffmpeg_exe() -> str:
    """Resolve ffmpeg from settings, PATH, and common Windows install paths.

    The setting may be either the ffmpeg.exe path or the bin directory.
    """
    raw = str(app_settings.get("ffmpeg_path", "") or "").strip().strip('"')
    candidates: list[Path] = []
    if raw:
        p = Path(raw)
        if p.is_dir():
            candidates.append(p / "ffmpeg.exe")
            candidates.append(p / "ffmpeg")
        else:
            candidates.append(p)
    which = shutil.which("ffmpeg")
    if which:
        candidates.append(Path(which))
    for x in [
        Path(r"C:\ffmpeg\ffmpeg-2026-03-30-git-e54e117998-full_build\ffmpeg-2026-03-30-git-e54e117998-full_build\bin\ffmpeg.exe"),
        Path(r"C:\ffmpeg\bin\ffmpeg.exe"),
    ]:
        candidates.append(x)
    for c in candidates:
        try:
            if c.exists() and c.is_file():
                return str(c)
        except Exception:
            pass
    return "ffmpeg"


class SpeechEngine:
    def available(self) -> bool: return False
    def cache_ext(self) -> str: return "wav"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool: return False

class EdgeTTSEngine(SpeechEngine):
    def available(self) -> bool:
        try:
            import edge_tts  # noqa
            return True
        except Exception:
            return False
    def cache_ext(self) -> str: return "mp3"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool:
        try:
            import edge_tts
            async def run():
                pct = int((float(rate) - 1.0) * 100)
                rate_str = f"{pct:+d}%"
                communicate = edge_tts.Communicate(text, voice or "en-US-AriaNeural", rate=rate_str)
                await communicate.save(str(output_path))
            asyncio.run(run())
            return output_path.exists() and output_path.stat().st_size > 100
        except Exception:
            return False

class ChatTTSEngine(SpeechEngine):
    def available(self) -> bool:
        script = str(app_settings.get("chattts_script_path", "") or "").strip()
        model_dir = str(app_settings.get("chattts_model_dir", "") or "").strip()
        asset_dir = str(app_settings.get("chattts_asset_dir", "") or "").strip()
        if script and Path(script).exists():
            return True
        if model_dir and Path(model_dir).exists():
            return True
        if asset_dir and Path(asset_dir).exists():
            return True
        try:
            import ChatTTS  # noqa
            return True
        except Exception:
            return False
    def cache_ext(self) -> str: return "wav"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool:
        try:
            from .tts_cache_service import synthesize_chattts
            return synthesize_chattts(text, output_path, voice or str(app_settings.get("chattts_voice", "default")), rate, volume)
        except Exception:
            return False

class KokoroEngine(SpeechEngine):
    def available(self) -> bool:
        d = Path(str(app_settings.get("kokoro_model_dir", "") or ""))
        w = Path(str(app_settings.get("kokoro_weight_path", "") or ""))
        v = Path(str(app_settings.get("kokoro_voices_dir", "") or ""))
        voice = str(app_settings.get("kokoro_voice", "af_heart") or "af_heart")
        if not w.exists() and d.exists():
            w = d / "kokoro-v1_0.pth"
        if not v.exists() and d.exists():
            v = d / "voices"
        vf = v / (voice if voice.endswith(".pt") else voice + ".pt")
        if bool(app_settings.get("kokoro_local_only", True)):
            return w.exists() and vf.exists()
        if w.exists() and vf.exists():
            return True
        try:
            import kokoro  # noqa
            return True
        except Exception:
            return False
    def cache_ext(self) -> str: return "wav"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool:
        try:
            from .tts_cache_service import synthesize_kokoro
            return synthesize_kokoro(text, output_path, voice or _voice_for_engine("kokoro"), rate, volume)
        except Exception:
            return False

class MeloTTSEngine(SpeechEngine):
    def available(self) -> bool:
        return bool(str(app_settings.get("melotts_model_dir", "")) or str(app_settings.get("melotts_script_path", "")))
    def cache_ext(self) -> str: return "wav"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool:
        try:
            from .tts_cache_service import synthesize_melotts
            return synthesize_melotts(text, output_path, voice or _voice_for_engine("melotts"), rate, volume)
        except Exception:
            return False


class StyleTTS2Engine(SpeechEngine):
    def available(self) -> bool:
        py = str(app_settings.get("styletts2_python_path", "") or "").strip()
        checkpoint = str(app_settings.get("styletts2_checkpoint_path", "") or "").strip()
        config = str(app_settings.get("styletts2_config_path", "") or "").strip()
        return bool(py and Path(py).exists() and checkpoint and Path(checkpoint).exists() and config and Path(config).exists())
    def cache_ext(self) -> str: return "wav"
    def synthesize(self, text: str, output_path: Path, voice: str, rate: float, volume: float) -> bool:
        try:
            from .tts_cache_service import synthesize_styletts2
            return synthesize_styletts2(text, output_path, voice or "styletts2", rate, volume)
        except Exception:
            return False

class SpeechEngineManager:
    def __init__(self):
        self.player = QMediaPlayer(); self.audio = QAudioOutput(); self.player.setAudioOutput(self.audio)
        self._segment_timer = QTimer(); self._segment_timer.setSingleShot(True); self._segment_timer.timeout.connect(self.player.stop)
        self.on_ready: Optional[Callable[[str], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
        self.on_generating: Optional[Callable[[], None]] = None
        self._thread: Optional[threading.Thread] = None
        self._task_lock = threading.Lock()
        self._busy = False
        self._task_id = 0
        try:
            QTimer.singleShot(1600, self.maybe_prewarm_kokoro)
        except Exception:
            pass

    def _begin_task(self, label: str = "tts") -> int:
        """Allow only one active synth/extract job to prevent UI lockups."""
        with self._task_lock:
            if self._busy:
                if self.on_error:
                    self.on_error("上一段发音/本地音频仍在准备中，请稍等；已阻止重复启动，避免卡死。")
                return 0
            self._busy = True
            self._task_id += 1
            return self._task_id

    def _finish_task(self, task_id: int) -> None:
        with self._task_lock:
            if task_id == self._task_id:
                self._busy = False

    def _is_current_task(self, task_id: int) -> bool:
        with self._task_lock:
            return self._busy and task_id == self._task_id

    def set_callbacks(self, on_ready=None, on_error=None, on_generating=None):
        self.on_ready = on_ready; self.on_error = on_error; self.on_generating = on_generating

    def maybe_prewarm_kokoro(self):
        try:
            if str(app_settings.get("speech_engine", "")) == "kokoro" and bool(app_settings.get("kokoro_prewarm_on_start", True)):
                def work():
                    try:
                        from .tts_cache_service import prewarm_kokoro
                        prewarm_kokoro()
                    except Exception:
                        pass
                threading.Thread(target=work, daemon=True).start()
        except Exception:
            pass

    def _engine(self, name: str) -> Optional[SpeechEngine]:
        return {"edge_tts": EdgeTTSEngine(), "chattts": ChatTTSEngine(), "kokoro": KokoroEngine(), "melotts": MeloTTSEngine(), "styletts2": StyleTTS2Engine()}.get(name)

    def _cache_path(self, text: str, engine: str, voice: str, rate: float, volume: float, ext: str) -> Path:
        model = ""
        if engine == "chattts": model = str(app_settings.get("chattts_model_dir", ""))
        if engine == "kokoro": model = str(app_settings.get("kokoro_model_dir", ""))
        if engine == "melotts": model = str(app_settings.get("melotts_script_path", ""))
        if engine == "styletts2": model = str(app_settings.get("styletts2_checkpoint_path", ""))
        key = f"{text}|{engine}|{voice}|{rate}|{volume}|{model}"
        safe_voice = (voice or "default").replace("/", "_").replace("\\", "_").replace(":", "_")
        out_dir = CACHE_DIR / engine / safe_voice
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir / f"{hashlib.md5(key.encode('utf-8')).hexdigest()}.{ext}"

    def play_audio(self, path: str, speed: float | None = None, volume: float | None = None) -> bool:
        p = Path(path)
        if not p.exists():
            return False
        self._segment_timer.stop()
        # Fully reset the Qt player before switching source.  On Windows, simply
        # setSource() while the previous media is active may keep the old backend
        # alive, which looks like “切换后切不回来”.
        try:
            self.player.stop()
            self.player.setSource(QUrl())
        except Exception:
            pass
        self.audio.setVolume(float(volume if volume is not None else app_settings.get("speech_volume", 1.0)))
        self.player.setPlaybackRate(float(speed if speed is not None else app_settings.get("play_speed", 1.0)))
        self.player.setSource(QUrl.fromLocalFile(str(p.resolve())))
        self.player.play()
        return True

    def _media_segment_cache_path(self, media_path: str, start_ms: int, end_ms: int) -> Path:
        key = f"{Path(media_path).resolve()}|{start_ms}|{end_ms}|{Path(media_path).stat().st_mtime if Path(media_path).exists() else 0}"
        out_dir = ROOT / "cache" / "media_segments"
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir / f"{hashlib.md5(key.encode('utf-8')).hexdigest()}.mp3"

    def play_media_segment(self, media_path: str, start_ms: int, end_ms: int, volume: float | None = None) -> bool:
        """Play only current subtitle audio.

        Default mode extracts the audio segment to cache with ffmpeg in a background
        thread, then plays the small mp3. This avoids making QMediaPlayer load/seek
        the full episode on every line, which causes UI/input lag on Windows.
        """
        p = Path(media_path or "")
        if not p.exists() or start_ms < 0:
            return False

        mode = str(app_settings.get("local_media_mode", "cached_segment") or "cached_segment")
        if mode == "off":
            return False

        if mode == "direct":
            self._segment_timer.stop()
            self.audio.setVolume(float(volume if volume is not None else app_settings.get("speech_volume", 1.0)))
            self.player.setPlaybackRate(float(app_settings.get("play_speed", 1.0)))
            self.player.setSource(QUrl.fromLocalFile(str(p.resolve())))
            def seek_and_play():
                try:
                    self.player.setPosition(int(start_ms))
                    self.player.play()
                    if end_ms and end_ms > start_ms:
                        self._segment_timer.start(max(120, int((end_ms - start_ms) / max(0.1, float(app_settings.get("play_speed", 1.0)))) + 120))
                except Exception:
                    self.player.play()
            QTimer.singleShot(80, seek_and_play)
            return True

        cache_path = self._media_segment_cache_path(str(p), int(start_ms), int(end_ms))
        if cache_path.exists() and cache_path.stat().st_size > 100:
            return self.play_audio(str(cache_path), speed=float(app_settings.get("play_speed", 1.0)), volume=volume)

        task_id = self._begin_task("media_segment")
        if not task_id:
            return True
        if self.on_generating:
            self.on_generating()

        def work():
            try:
                dur_ms = max(300, int(end_ms - start_ms)) if end_ms and end_ms > start_ms else 2200
                ss = max(0.0, start_ms / 1000.0)
                dur = max(0.3, dur_ms / 1000.0)
                flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                cmd = [
                    _ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y",
                    "-ss", f"{ss:.3f}", "-t", f"{dur:.3f}",
                    "-i", str(p), "-vn", "-ac", "1", "-ar", "24000", "-b:a", "64k",
                    str(cache_path),
                ]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20, creationflags=flags)
                if proc.returncode == 0 and cache_path.exists() and cache_path.stat().st_size > 100:
                    if self._is_current_task(task_id) and self.on_ready:
                        self.on_ready(str(cache_path))
                else:
                    if self._is_current_task(task_id) and self.on_error:
                        detail = (proc.stderr or proc.stdout or "").strip()[:500]
                        self.on_error("本地媒体片段提取失败；请检查 FFMPEG 路径或切换 Edge-TTS。" + ("\n" + detail if detail else ""))
            except Exception as e:
                if self._is_current_task(task_id) and self.on_error:
                    self.on_error(f"本地媒体片段播放失败：{e}")
            finally:
                self._finish_task(task_id)

        self._thread = threading.Thread(target=work, daemon=True)
        self._thread.start()
        return True

    def play_text(self, text: str, local_audio_path: str = "") -> None:
        if local_audio_path and Path(local_audio_path).exists():
            self.play_audio(local_audio_path); return
        engine_name = str(app_settings.get("speech_engine", "edge_tts") or "edge_tts")
        fallback = str(app_settings.get("speech_fallback_engine", "edge_tts") or "edge_tts")
        if engine_name == "local_audio":
            if self.on_error: self.on_error("当前句未绑定本地音频；已尝试使用兜底发音引擎。")
            engine_name = fallback if fallback != "local_audio" else "edge_tts"
        engine = self._engine(engine_name)
        if not engine or not engine.available():
            if fallback and fallback != engine_name:
                engine_name = fallback
                engine = self._engine(engine_name)
        if not engine or not engine.available():
            if self.on_error: self.on_error(f"发音引擎不可用：{engine_name}。请在设置中配置或切换 Edge-TTS。")
            return
        voice = _voice_for_engine(engine_name)
        rate = float(app_settings.get("speech_rate", 1.0)) * float(app_settings.get("play_speed", 1.0))
        volume = float(app_settings.get("speech_volume", 1.0))
        path = self._cache_path(text, engine_name, voice, rate, volume, engine.cache_ext())
        if path.exists() and path.stat().st_size > 100:
            self.play_audio(str(path), speed=1.0, volume=volume); return
        task_id = self._begin_task("tts")
        if not task_id:
            return
        if self.on_generating: self.on_generating()
        def work():
            try:
                ok = engine.synthesize(text, path, voice, rate, volume)
            except Exception:
                ok = False
            used = engine_name
            report_path = ROOT / "data" / "last_tts_engine_report.log"
            def write_report(msg: str):
                try:
                    report_path.parent.mkdir(parents=True, exist_ok=True)
                    report_path.write_text(msg, encoding="utf-8")
                except Exception:
                    pass
            if not ok and fallback and fallback != engine_name:
                fb = self._engine(fallback)
                if fb and fb.available():
                    used = fallback
                    voice_fb = _voice_for_engine(fallback)
                    path_fb = self._cache_path(text, fallback, voice_fb, rate, volume, fb.cache_ext())
                    ok = fb.synthesize(text, path_fb, voice_fb, rate, volume)
                    if ok:
                        extra = ""
                        try:
                            kp = ROOT / "data" / "kokoro_last_error.log"
                            if kp.exists():
                                extra += "\n\n[kokoro_last_error]\n" + kp.read_text(encoding="utf-8", errors="replace")
                        except Exception:
                            pass
                        write_report(f"requested={engine_name}\nactual={used}\nreason=primary_failed_fallback_used\nvoice={voice_fb}\noutput={path_fb}\nkokoro_local_only={app_settings.get('kokoro_local_only', True)}" + extra)
                        if self._is_current_task(task_id) and self.on_ready: self.on_ready(str(path_fb))
                        self._finish_task(task_id)
                        return
            if ok:
                extra = ""
                if engine_name == "kokoro":
                    try:
                        kp = ROOT / "data" / "kokoro_last_error.log"
                        if kp.exists():
                            extra += "\n\n[kokoro_last_error]\n" + kp.read_text(encoding="utf-8", errors="replace")
                    except Exception:
                        pass
                write_report(f"requested={engine_name}\nactual={used}\nreason=primary_ok\nvoice={voice}\noutput={path}\nkokoro_local_only={app_settings.get('kokoro_local_only', True)}" + extra)
                if self._is_current_task(task_id) and self.on_ready: self.on_ready(str(path))
            else:
                extra = ""
                try:
                    kp = ROOT / "data" / "kokoro_last_error.log"
                    if kp.exists():
                        extra += "\n\n[kokoro_last_error]\n" + kp.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    pass
                write_report(f"requested={engine_name}\nactual=none\nreason=all_failed\nfallback={fallback}\nkokoro_local_only={app_settings.get('kokoro_local_only', True)}" + extra)
                if self._is_current_task(task_id) and self.on_error: self.on_error(f"发音生成失败：{engine_name}" + (f"，兜底 {fallback} 也失败" if fallback and fallback != engine_name else ""))
            self._finish_task(task_id)
        self._thread = threading.Thread(target=work, daemon=True); self._thread.start()

    def stop(self):
        self._segment_timer.stop()
        with self._task_lock:
            self._task_id += 1
            self._busy = False
        try:
            self.player.stop()
            self.player.setSource(QUrl())
        except Exception:
            pass
