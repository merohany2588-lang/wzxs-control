from __future__ import annotations

import argparse
import contextlib
import gc
import json
import os
import sys
import traceback
from pathlib import Path


def _lang_code(voice_name: str, region: str = "en-US") -> str:
    v = (voice_name or "af_heart").lower()
    if v.startswith(("bf_", "bm_")):
        return "b"
    if v.startswith(("af_", "am_")):
        return "a"
    return "b" if (region or "").lower() in {"en-gb", "gb", "uk", "british"} else "a"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    args = parser.parse_args()
    data_dir = Path(args.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    log_path = data_dir / "kokoro_daemon_worker.log"

    def log(msg: str) -> None:
        try:
            with log_path.open("a", encoding="utf-8") as f:
                f.write(str(msg) + "\n")
        except Exception:
            pass

    log("daemon_start")
    pipelines: dict[str, object] = {}

    try:
        # Import in worker only. Keep stdout clean for JSON protocol.
        with contextlib.redirect_stdout(sys.stderr):
            import numpy as np
            import soundfile as sf
            import torch
            from kokoro import KPipeline  # type: ignore
        log(f"torch={getattr(torch, '__version__', 'unknown')} cuda={torch.cuda.is_available()}")
    except Exception:
        log("IMPORT_FAIL\n" + traceback.format_exc())
        print(json.dumps({"ok": False, "error": "import_failed", "traceback": traceback.format_exc()}, ensure_ascii=False), flush=True)
        return 2

    for line in sys.stdin:
        try:
            req = json.loads(line)
            text = str(req.get("text") or "")
            output = Path(str(req.get("output") or ""))
            voice_name = str(req.get("voice_name") or "af_heart").replace(".pt", "")
            speed = float(req.get("rate") or 1.0)
            volume = float(req.get("volume") or 1.0)
            region = str(req.get("region") or "en-US")
            lang_code = str(req.get("lang_code") or _lang_code(voice_name, region))
            max_items = int(req.get("max_items") or 20)
            if not text.strip():
                print(json.dumps({"ok": False, "error": "empty_text"}, ensure_ascii=False), flush=True)
                continue
            if lang_code not in pipelines:
                log(f"load_pipeline lang={lang_code}")
                with contextlib.redirect_stdout(sys.stderr):
                    pipelines[lang_code] = KPipeline(lang_code=lang_code)
                log(f"pipeline_ready lang={lang_code}")
            if hasattr(torch, "cuda") and torch.cuda.is_available():
                try:
                    torch.cuda.empty_cache()
                except Exception:
                    pass
            gc.collect()
            pipeline = pipelines[lang_code]
            chunks = []
            sample_rate = 24000
            log(f"synth voice={voice_name} lang={lang_code} len={len(text)} output={output}")
            with contextlib.redirect_stdout(sys.stderr):
                generator = pipeline(text, voice=voice_name, speed=speed)
                for i, item in enumerate(generator):
                    audio = None
                    if isinstance(item, tuple) and len(item) >= 3:
                        audio = item[2]
                    elif hasattr(item, "audio"):
                        audio = item.audio
                    elif isinstance(item, dict):
                        audio = item.get("audio") or item.get("samples")
                        sample_rate = int(item.get("sample_rate") or item.get("sr") or sample_rate)
                    else:
                        audio = item
                    if audio is not None:
                        chunks.append(np.asarray(audio, dtype="float32") * float(volume))
                    if i >= max_items:
                        break
            if not chunks:
                print(json.dumps({"ok": False, "error": "no_audio"}, ensure_ascii=False), flush=True)
                continue
            output.parent.mkdir(parents=True, exist_ok=True)
            sf.write(str(output), np.concatenate(chunks) if len(chunks) > 1 else chunks[0], sample_rate)
            size = output.stat().st_size if output.exists() else 0
            print(json.dumps({"ok": bool(size > 100), "output": str(output), "size": size, "engine": "kokoro", "voice": voice_name}, ensure_ascii=False), flush=True)
        except Exception:
            tb = traceback.format_exc()
            log("REQUEST_FAIL\n" + tb)
            print(json.dumps({"ok": False, "error": "request_failed", "traceback": tb}, ensure_ascii=False), flush=True)
    log("daemon_stop")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
