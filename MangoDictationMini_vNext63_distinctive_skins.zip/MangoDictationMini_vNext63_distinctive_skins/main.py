from __future__ import annotations
import os
import sys
import traceback
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

# Suppress noisy Qt/FFmpeg mp3 logs where possible.
os.environ.setdefault("QT_LOGGING_RULES", "qt.multimedia.ffmpeg=false")
os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")

APP = None
MAIN_WINDOW = None


def ensure_dirs() -> None:
    for rel in [
        "data",
        "cache/tts",
        "cache/media_segments",
        "assets/sounds",
        "engines/piper",
        "engines/kokoro",
        "engines/melotts",
    ]:
        (ROOT / rel).mkdir(parents=True, exist_ok=True)


def _trace(message: str) -> None:
    """Always write a runtime trace so silent exits can be diagnosed."""
    try:
        ensure_dirs()
        path = ROOT / "data" / "runtime_trace.log"
        path.open("a", encoding="utf-8").write(
            f"[{datetime.now().isoformat(timespec='seconds')}] {message}\n"
        )
    except Exception:
        pass


def _write_crash(exc: BaseException) -> Path:
    ensure_dirs()
    path = ROOT / "data" / "startup_crash.log"
    path.write_text(
        "MangoDictationMini startup crash\n\n"
        + "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
        encoding="utf-8",
    )
    return path


def main() -> int:
    global APP, MAIN_WINDOW
    ensure_dirs()
    # reset trace each run
    try:
        (ROOT / "data" / "runtime_trace.log").write_text("", encoding="utf-8")
    except Exception:
        pass

    _trace("main() begin")

    try:
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtWidgets import QApplication, QMessageBox
    except Exception as e:
        log = _write_crash(e)
        _trace(f"import PySide6 failed: {e!r}; log={log}")
        print(f"[MangoDictationMini] PySide6 导入失败，日志：{log}", file=sys.stderr)
        print("".join(traceback.format_exception(type(e), e, e.__traceback__)), file=sys.stderr)
        return 1

    try:
        APP = QApplication(sys.argv)
        APP.setApplicationName("MangoDictationMini")
        # Important: v18 on some Windows machines returned immediately as if
        # the last window had closed.  Keep the event loop alive explicitly;
        # MainWindow is deleted on close and then calls app.quit().
        APP.setQuitOnLastWindowClosed(False)
        _trace("QApplication created")

        from app.main_window import MainWindow
        _trace("MainWindow imported")

        MAIN_WINDOW = MainWindow()
        MAIN_WINDOW.setAttribute(Qt.WA_DeleteOnClose, True)
        MAIN_WINDOW.destroyed.connect(APP.quit)
        _trace("MainWindow constructed")

        MAIN_WINDOW.show()
        MAIN_WINDOW.raise_()
        MAIN_WINDOW.activateWindow()
        _trace(f"MainWindow show called, visible={MAIN_WINDOW.isVisible()}")

        def _ensure_visible() -> None:
            try:
                if MAIN_WINDOW is not None and not MAIN_WINDOW.isVisible():
                    _trace("watchdog: window not visible, calling showNormal/show")
                    MAIN_WINDOW.showNormal()
                    MAIN_WINDOW.show()
                    MAIN_WINDOW.raise_()
                    MAIN_WINDOW.activateWindow()
                else:
                    _trace("watchdog: window visible")
            except Exception as e:
                _trace(f"watchdog error: {e!r}")

        QTimer.singleShot(350, _ensure_visible)
        _trace("entering app.exec()")
        code = APP.exec()
        _trace(f"app.exec() returned code={code}")
        return int(code or 0)

    except BaseException as e:
        log = _write_crash(e)
        _trace(f"startup exception: {e!r}; log={log}")
        try:
            QMessageBox.critical(
                None,
                "MangoDictationMini 启动失败",
                f"程序启动失败，错误已写入：\n{log}\n\n{e}",
            )
        except Exception:
            pass
        print(f"[MangoDictationMini] 启动失败，已写入日志：{log}", file=sys.stderr)
        print("".join(traceback.format_exception(type(e), e, e.__traceback__)), file=sys.stderr)
        return 1


if __name__ == "__main__":
    code = main()
    if code != 0 and os.environ.get("MANGO_NO_PAUSE") != "1" and os.name == "nt":
        os.system("pause")
    sys.exit(code)
