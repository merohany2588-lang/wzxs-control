@echo off
setlocal
cd /d "%~dp0"
echo Starting MangoDictationMini...
py main.py
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo Program exited with error code %ERR%.
  echo Please check data\startup_crash.log and data\runtime_trace.log
) else (
  echo Program exited normally.
)
pause
