@echo off
cd /d "%~dp0"
py tools\license_keygen_ui.py
pause
