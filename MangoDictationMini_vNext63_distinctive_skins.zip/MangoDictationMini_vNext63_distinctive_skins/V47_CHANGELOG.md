# MangoDictationMini vNext47

紧急修复：

1. 选词模式看不到/不明显
- 新增选词模式上方横线槽位：未选是横线，已选显示绿色词。
- 候选词按钮区域压缩到可见范围，不再掉到页面中部/底部。
- 选词模式候选词按钮变大、更清晰。

2. 样式解析报错
- 修复 ChunkInput 内部 QSS 的无效 color: palette(text) 写法。
- 避免出现 Could not parse application stylesheet。

3. 填空模式
- 候选词区域也限制高度，避免页面空白过大。

未动：
- Kokoro / TTS 链路
- 制作台
- Kaikki 音标主链路
- 播放防卡死逻辑
