@echo off
setlocal
cd /d "%~dp0"
echo Debug start...
echo Python:
py --version
echo.
echo Running main.py...
py main.py
echo.
echo Exit code: %ERRORLEVEL%
echo.
echo If the app did not open, send these files:
echo data\startup_crash.log
echo data\runtime_trace.log
pause
