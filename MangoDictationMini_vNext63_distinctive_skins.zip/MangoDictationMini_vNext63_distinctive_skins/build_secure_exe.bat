@echo off
cd /d "%~dp0"
set MANGO_NO_PAUSE=1
if exist build rmdir /s /q build
if exist dist\MangoDictationMini rmdir /s /q dist\MangoDictationMini
py -m PyInstaller --onefile --noconsole --clean --name MangoDictationMini main.py ^
  --add-data "data\sample_material.txt;data" ^
  --add-data "data\local_words.csv;data" ^
  --hidden-import PySide6.QtMultimedia ^
  --hidden-import PySide6.QtMultimediaWidgets
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Secure build finished: dist\MangoDictationMini.exe
echo Do NOT ship tools\license_keygen_ui.py or source .py files to users.
pause
