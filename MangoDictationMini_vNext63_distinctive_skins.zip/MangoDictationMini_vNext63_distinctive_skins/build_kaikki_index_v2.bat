@echo off
setlocal
echo Building Kaikki v2 multi-offset index...
py tools\build_kaikki_index_v2.py
if errorlevel 1 (
  echo FAILED.
  pause
  exit /b 1
)
echo DONE.
pause
