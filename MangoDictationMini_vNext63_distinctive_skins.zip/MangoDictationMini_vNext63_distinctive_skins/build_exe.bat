@echo off
cd /d "%~dp0"
py -m PyInstaller --onedir --noconsole --name MangoDictationMini main.py
pause
