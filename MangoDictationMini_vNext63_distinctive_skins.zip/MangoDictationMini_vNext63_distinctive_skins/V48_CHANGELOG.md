# MangoDictationMini vNext48

## 修复：彩色提示框可拖动拉伸

- 将练习主区域和下方提示/快捷状态区域放入垂直 QSplitter。
- 用户可以直接拖动中间分割条，上下调整下方提示框高度。
- 取消提示框内部滚动区最大高度限制，放大后内容区域会跟随变高。
- 分割条位置会保存到 data/settings.json 的 main_splitter_sizes，下次启动保留。
- 给分割条增加主题色 hover 样式，便于看见可拖动位置。

## 未改动

- Kokoro / TTS 调用链路未动。
- 选词模式和填空模式逻辑未动。
- Kaikki 音标主链路未动。
- 制作台未动。
