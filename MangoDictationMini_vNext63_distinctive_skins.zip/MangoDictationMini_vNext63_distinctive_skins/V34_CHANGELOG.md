# MangoDictationMini vNext34

本版按已确认的方向做最小范围修复：

- 修复横线区域文字/提示重叠：正确后的完整提示仍在下方大提示框，横线下方只保留短提示。
- 设置中心发音/翻译页按模型分区：总控、Edge-TTS、Kokoro、ChatTTS、MeloTTS、StyleTTS2、本地原声/词典/翻译。
- Edge-TTS 的口音/性别设置会同步到具体 voice；手动覆盖为空时按下拉 voice 生效。
- Kokoro voice 从 voices 目录自动扫描，支持 38 个 .pt voice。
- ChatTTS 不再自动下载 HuggingFace asset；必须填已跑通脚本或本地模型/asset。
- 新增 StyleTTS2 引擎，使用独立 Python 环境子进程，调用方式与用户测试成功脚本一致：from styletts2 import tts。
- MeloTTS 保留独立配置区，不再伪装成已跑通；失败写日志并走兜底。
- 未动：主训练界面风格、Kaikki v2 音标链路、中文后台翻译主链路。

重要日志：
- data/last_tts_engine_report.log
- data/kokoro_last_error.log
- data/chattts_last_error.log
- data/styletts2_last_error.log
- data/styletts2_last_error_summary.log
