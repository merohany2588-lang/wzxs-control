# MangoDictationMini vNext36 - TTS speed and tail-noise fix

## Scope kept intentionally narrow
- Did not change the main training UI style.
- Did not touch Kaikki v2 phonetic lookup logic.
- Did not change dictation input/judgement logic.

## Fixed / Added
1. **StyleTTS2 persistent daemon**
   - New `app/styletts2_daemon_worker.py`.
   - Live playback no longer starts StyleTTS2 Python + loads model for every short chunk when keep-alive is enabled.
   - First call is still slow; following calls should avoid the full cold start.

2. **Live vs production StyleTTS2 quality split**
   - Live chunk playback: `styletts2_realtime_diffusion_steps`, default `6`.
   - Production workbench: `styletts2_production_diffusion_steps`, default `20`.
   - Existing `alpha=0.3`, `beta=0.7` preserved.

3. **TTS audio post-processing**
   - Trims obvious leading/trailing silence.
   - Applies short fade-in/fade-out.
   - Peak normalizes WAV output.
   - Applied to Kokoro / StyleTTS2 / ChatTTS / MeloTTS WAV output.
   - Edge-TTS MP3 is left untouched to avoid slow conversion during live use.

4. **Settings UI additions**
   - StyleTTS2 keep-alive toggle.
   - Separate live and production diffusion steps.
   - Tail-noise post-processing controls.

## Key settings
- `styletts2_keep_alive=true`
- `styletts2_realtime_diffusion_steps=6`
- `styletts2_production_diffusion_steps=20`
- `tts_postprocess_enabled=true`
- `tts_fade_out_ms=60`
- `tts_normalize_peak=0.92`

## Expected behavior
- Kokoro: first generation may still be slow, follow-up cached/daemon use should be faster.
- StyleTTS2: first generation may still be slow, but live chunks should use fewer diffusion steps and daemon reuse.
- Tail clicks / noisy endings should be reduced by fade-out and trimming.
