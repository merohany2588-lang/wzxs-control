# MangoDictationMini Final

极简主界面 + 强后台功能的离线/在线兜底英语听写训练器。

## 运行

```bat
py -m pip install -r requirements.txt
py -m compileall .
py main.py
```

## 核心快捷键

- Ctrl+↑ 播放整句
- Ctrl+↓ 播放当前语块
- Space 当前横线有输入时跳转；空横线禁止跳过
- Enter 提交；有错误自动回第一处错误
- Ctrl+H 六步提示，1-5不暴露完整答案，第6步显示答案
- Ctrl+; 显示答案
- Ctrl+Shift+C 复制整句

## 发音

默认 Edge-TTS 在线兜底，缓存到 cache/tts。若素材第三列有本地音频路径，优先播放本地音频。

## 翻译

导入时中文为空：默认 Google 在线翻译，失败再 OPUS 本地模型兜底（需要在设置中填写 OPUS 模型目录）。


## vNext18 重点
- 修复 v17 启动黑框闪退无日志：启动失败会写入 `data/startup_crash.log`。
- 设置保存后统一走 `_apply_runtime_settings()`，停止旧播放、重绑快捷键、刷新主题/资源库/语块/音标/提示/中文显示。
- 修复切换本地媒体播放后切不回 Edge-TTS/Piper 的问题：设置应用时会停止播放器并清空旧 source。
- `run.bat` 启动失败会 pause，便于查看报错。

## v24 Production Workbench Notes

- Workbench path: menu `制作台 -> 字幕翻译 / Edge-TTS 缓存制作台`.
- Supports translation engines from settings: API / Google / OPUS / none.
- Supports TTS main engine + fallback: Kokoro / MeloTTS / Edge-TTS.
- Output is saved beside the source SRT:
  - `name.zh.srt`
  - `name.bilingual.srt`
  - `name_tts_cache/sentence/*.mp3`
  - `name_tts_cache/chunk/*.mp3`
  - `name_tts_cache/word/*.mp3` when enabled
  - `name_tts_cache/word_cache.json`
  - `name_tts_cache/manifest.json`
- Training should stay smooth: do slow translation/TTS work in the workbench first, then train from cached files.


## Kaikki v2 多 offset 索引

如果普通词仍然大量缺音标，运行：

```bat
build_kaikki_index_v2.bat
```

原因：旧索引是 `word -> offset`，同词多词条会被覆盖，可能刚好指向没有 sounds/ipa 的条目。v2 改成 `word -> offsets[]`，查询时合并多个 entry，优先找有 IPA 的条目。


## v28 notes
- Keeps current UI style.
- Restores missing-Chinese background translation; OPUS remains fallback.
- Kokoro is local-only by default; no hidden HF download.
- TTS test/report writes data/last_tts_engine_report.log.

## vNext54 更新

- 8 套皮肤改为真实运行时生效：不仅换名字，会改变边距、密度、面板高度、横线样式、按钮/标签页形态。
- 60 套主题配色重新设计，保留中文名但去除大量相似方案。
- 新增“全文浏览”标签页：像每日英语听力的剧集台词浏览，点击台词即可定位并播放。


## V55 精听播放页

V55 在 V54 基础上新增独立“精听播放页”：

- 点击台词即可播放对应句子。
- SRT/VTT 绑定同名本地视频/音频时，按字幕时间段播放。
- 支持视频小窗自由拖动、全屏/还原。
- 支持单句播放次数、播放速度。
- 支持隐藏/显示英文原文和中文翻译。
- 支持上一句/下一句切换与定时连播。
- 未绑定本地视频时自动回退到当前发音引擎。
